local ADDON, ns = ...

-- ============================================================
-- THE PRESETS: the Presets\ files' HUIPresets_Add lists (and, 0.1.1 only, an old Presets.lua's HUIPRESETS) read and
-- checked (the codec's Sanitize), this character's picked out, the ask, the apply, and what comes after.
--
--   MINE       the presets of this character's class; of those, the ones planned for its race when any is (the
--              layout's `race`, the ChrRaces file string UnitRace gives), else the ones that name no race.
--   ASK        (Harry, Oct 19: "on a new load (detected on new character) it should ask for permission first") a
--              character that never had a preset and was never told Never: P.DELAY after the first PLAYER_ENTERING_WORLD,
--              out of a fight (in one it waits for the end), the window opens asking - one match: its name and class;
--              several: the list, the first picked - Apply | Not now | Never. Not now (or Escape) asks again at the next
--              login; Never is this character's and stops the asking.
--   APPLY      out of a fight only (in one: "<name> waits for the fight to end.", applied at its end): the engine puts
--              the macros, slots and keys on (keys on whatever bars are drawn), then the settings it turns on; the store
--              starts afresh for each preset. One line in your own chat frame says what was done and where it stands
--              ("Train N", "Up to date", "All placed"). What was applied is kept: its name, class, race, hash (of its
--              text) and when.
--   LATER      (Harry: "can they delete the addon after the first /reload with it enabled?") while installed, the spells
--              learnt and the ranks bought are placed, a better mount or potion swapped in - SPELLS_CHANGED,
--              LEARNED_SPELL_IN_SKILL_LINE (this client's; it has no LEARNED_SPELL_IN_TAB), SPELL_TEXT_UPDATE,
--              NEW_MOUNT_ADDED, COMPANION_LEARNED, BAG_UPDATE_DELAYED - a second after the last, out of a fight (a fight's
--              end runs what waited). "All placed" once every slot holds what the preset plans: then the addon may go.
--              (0.1.5) A spell the game pushed onto the bars itself when it was learnt (SPELL_PUSHED_TO_ACTIONBAR) onto
--              a slot the preset keeps for something else, or while the preset has its own button for it, is taken off
--              first: "Inner Focus kept to its own button".
--   TRAIN N    (0.1.2; Harry, Oct 19: "i'm on a level 19 priest and it's saying 'Waiting on 18'. why?") of what is still
--              waited on, only what the character can have NOW counts: the spells and ranks to buy at the trainer at
--              its level (E.Trainable) - "Train N", the window's row listing them on hover; none now but more at later
--              levels: "Up to date"; nothing left: "All placed". Counted again on PLAYER_LEVEL_UP.
--   EXPORT     (0.1.2; Harry: "we also have no way of exporting a string from in-game") the bars now as a string.
--   UPDATED    the applied preset's text changed in its file (its hash): the window shows Updated with Apply, and one
--              line says so once per change. Never applied by itself.
--   AGAIN      (0.1.7; Harry, Oct 20: "it hasn't taken the new skills. it doesn't commit the changes. is it caching
--              somewhere which doesn't let me override?") the files are read once, when the addon loads: a file replaced
--              while playing counts from the next /reload. Apply on the preset applied with the same text applies it
--              again and says only "Same as applied - replaced the file? /reload first". Applying over an earlier preset
--              takes off what that one placed on slots the new one no longer names (Engine.lua E.Leftovers): a spell
--              moved, a button or macro dropped; a slot changed by hand is never touched.
--   MACROS     (0.1.8; Harry, Oct 20: "the website committed extra macros because i deleted some, but it kept them in the
--              lua") the macros an apply makes are this character's record (Engine.lua "THE MACROS IT MADE"): a changed
--              text edited in place, a dropped character macro deleted, a dropped account one kept and no longer placed;
--              "macros 2 updated, 1 removed" in the line. A macro the player made or changed is never touched.
--   TIDY       (0.1.8) /presets tidy: the twins made before that (the character set only, on no bar, the same name and
--              spell as another) listed in the window - Remove, then Yes - and deleted out of a fight; one line says how
--              many.
-- ============================================================

local Codec, E = ns.LayoutCodec, ns.LayoutEngine
local NAMES = ns.NAMES

local P = {}
ns.Presets = P
P.DELAY = 3
P.RECHECK_DELAY = 1
P.status = { applies = 0, waits = 0, asks = 0, rechecks = 0, recheckWaits = 0, refused = 0, read = 0, lastLine = nil }
local status = P.status

-- A preset's hash: of its checked text (Codec.Write is deterministic), as 8 hex digits.
function P.Hash(layout)
	local text = Codec.Write(layout) or ""
	local h = 5381.0                                       -- (a double: exact far past 2^32, as the game's numbers are)
	for i = 1, #text do h = (h * 33 + string.byte(text, i)) % 4294967296 end
	return string.format("%04x%04x", math.floor(h / 65536), math.floor(h % 65536))
end

-- ============================================================
-- The presets, read once a session: every Presets\ file's (in the .toc's order), then an old Presets.lua's (0.1.1
-- only); one per class and name, the first read kept (a race and class file is newer than the old single file)
-- ============================================================
local list
function P.All()
	if list then return list end
	list = {}
	status.read, status.refused = 0, 0
	local seen = {}
	local function Take(t)
		local l = Codec.Sanitize(t)
		if not l then
			status.refused = status.refused + 1
			return
		end
		local key = l.class .. "\n" .. l.name
		if seen[key] then return end
		seen[key] = true
		list[#list + 1] = { layout = l, hash = P.Hash(l) }
		status.read = status.read + 1
	end
	for _, t in ipairs(ns.added or {}) do Take(t) end
	local src = rawget(_G, "HUIPRESETS")
	if type(src) == "table" then
		for i = 1, 400 do
			local t = src[i]
			if t == nil then break end
			Take(t)
		end
	end
	return list
end
function P.Forget() list = nil end

function P.ForClass(class)
	local out = {}
	for _, e in ipairs(P.All()) do if e.layout.class == class then out[#out + 1] = e end end
	return out
end

-- This character's: its class; its race's when any preset names it, else the ones naming no race. (0.1.10; Harry, Oct
-- 21, a new priest of another race on the stress test: "my imports didn't work" - his only priest preset was the Human
-- Priest's) else every preset of its class, whatever race it was made for: a class's bars are the class's.
function P.Matches()
	local class, race = E.MyClass(), E.MyRace()
	local mine, raceless, any = {}, {}, {}
	for _, e in ipairs(P.ForClass(class)) do
		any[#any + 1] = e
		if e.layout.race == nil then raceless[#raceless + 1] = e
		elseif race and e.layout.race == race then mine[#mine + 1] = e end
	end
	if #mine > 0 then return mine end
	if #raceless > 0 then return raceless end
	return any
end

function P.Find(class, name)
	for _, e in ipairs(P.All()) do
		if e.layout.class == class and e.layout.name == name then return e end
	end
	return nil
end

-- ============================================================
-- What was applied, and where it stands
-- ============================================================
function P.Applied() return ns.db and ns.db.applied or nil end

function P.Store()
	ns.db.store = E.Store(ns.db.store)
	return ns.db.store
end

-- (0.1.2; Harry, Oct 19: "i'm on a level 19 priest and it's saying 'Waiting on 18'. why?") the character's level: the
-- game's, or the level PLAYER_LEVEL_UP just gave (the game may still answer the old one in that moment)
function P.Level()
	local level = E.MyLevel()
	local up = status.levelUp
	if type(up) == "number" and up > level then return up end
	return level
end

-- What to buy at the trainer now for the preset applied (E.Trainable: one per spell name), and the slots waiting at all.
function P.TrainList()
	local a = P.Applied()
	if not a or type(a.layout) ~= "table" then return {}, 0 end
	return E.Trainable(a.layout, P.Store(), P.Level())
end

-- "updated" | "train" (N to buy at the trainer now) | "uptodate" (nothing to buy now, more at later levels) | "placed"
-- (nothing left at all) | nil (nothing applied), and N.
function P.State()
	local a = P.Applied()
	if not a or type(a.layout) ~= "table" then return nil, 0 end
	local e = P.Find(a.class, a.name)
	if e and e.hash ~= a.hash then return "updated", 0 end
	local buy, waiting = P.TrainList()
	if #buy > 0 then return "train", #buy end
	if waiting > 0 then return "uptodate", 0 end
	return "placed", 0
end

function P.StateWords()
	local state, n = P.State()
	if state == "updated" then return NAMES.updated end
	if state == "train" then return string.format(NAMES.train, n) end
	if state == "uptodate" then return NAMES.upToDate end
	if state == "placed" then return NAMES.allPlaced end
	return ""
end

-- A trainable spell's words: "Lesser Heal (Rank 3)", a spell with no rank its name alone.
function P.TrainWords(buy)
	if type(buy.rank) == "number" and buy.rank > 0 then return string.format("%s (Rank %d)", buy.name, buy.rank) end
	return buy.name
end

-- ============================================================
-- Apply
-- ============================================================
local queued
function P.Apply(layout)
	if type(layout) ~= "table" then return nil, "no layout" end
	if InCombatLockdown() then
		status.waits = status.waits + 1
		if queued == nil then ns.Print(string.format(NAMES.waits, layout.name)) end
		queued = layout
		ns.OutOfCombat("apply", function()
			local l = queued
			queued = nil
			if l then P.Apply(l) end
		end)
		return nil, "waiting"
	end
	-- (0.1.7; Harry, Oct 20: "is it caching somewhere which doesn't let me override?") the Presets\ files are read when
	-- the addon loads, so a file replaced while playing is read only at the next /reload: Apply on the preset already
	-- applied, its text the same, says so (still applied: a way back to the preset after changes by hand)
	local before = P.Applied()
	local hash = P.Hash(layout)
	local fromFile = P.Find(layout.class, layout.name)
	local same = type(before) == "table" and before.hash == hash and before.class == layout.class and before.name == layout.name
		and fromFile ~= nil and fromFile.hash == hash
	-- (a fresh store: the last preset's waits are not this one's; 0.1.6: the keys an import made stay remembered - a
	-- later preset that no longer uses one gives it back to what it did before)
	-- (0.1.8: and the macros it made, the account ones it let go, and whether the old preset's macros were taken in)
	local old = type(ns.db.store) == "table" and ns.db.store or {}
	ns.db.store = E.Store({ keysTaken = old.keysTaken, macrosMade = old.macrosMade, macrosDropped = old.macrosDropped,
		macrosSeeded = old.macrosSeeded })
	-- (0.1.7) what the preset applied before placed on a slot this one no longer names is taken off (E.Leftovers)
	local previous = type(before) == "table" and type(before.layout) == "table" and before.layout or nil
	local s, why = E.Apply(layout, ns.db.store, { settings = true, previous = previous })
	if not s then return nil, why end
	ns.db.applied = { name = layout.name, class = layout.class, race = layout.race, hash = hash,
		at = ns.Num(ns.Call(time)) or 0, layout = Codec.Copy(layout) }
	ns.db.updatedSaid = nil
	status.applies = status.applies + 1
	E.Recheck(ns.db.store, { only = E.SpellSlots(layout), layout = ns.db.applied.layout })
	if same then
		status.sameAgain = (status.sameAgain or 0) + 1
		status.lastLine = NAMES.sameAgain
	else
		status.lastLine = E.Words(layout.name, s) .. " - " .. P.StateWords()
	end
	ns.Print(status.lastLine)
	if ns.Window then ns.Window.Refresh() end
	return s
end

-- (0.1.2; Harry, Oct 19: "we also have no way of exporting a string from in-game") Export: the character's bars now
-- (E.Capture: every slot, the macros they use, the keys on the game's commands, the class and race) under a name - the
-- character's own by default - as the export string the editor imports (Codec.Export, HUI Bars' LayoutCodec's encoder).
-- Returns the string and the layout, or nil and why.
function P.Export(name)
	if type(name) ~= "string" or not string.find(name, "%S") then
		name = ns.Str(ns.Call(UnitName, "player")) or "Layout"
	end
	name = Codec.Truncate((string.gsub(string.gsub(name, "^%s+", ""), "%s+$", "")), Codec.NAME_LETTERS)
	local layout, why = E.Capture(name, ns.db and P.Store() or nil)
	if not layout then return nil, why end
	local str, err = Codec.Export(layout)
	if not str then return nil, err end
	status.exports = (status.exports or 0) + 1
	return str, layout
end

-- A pasted export string: this class's preset applied; another class's refused (its spells would never come).
function P.Load(text)
	local layout, why = Codec.Import(text)
	if not layout then return nil, why or NAMES.badString end
	if layout.class ~= E.MyClass() then
		return nil, string.format(NAMES.otherClass, NAMES.classes[layout.class] or layout.class)
	end
	return P.Apply(layout)
end

-- ============================================================
-- (0.1.8) Tidy: the character macros that are twins of another and on no bar (Engine.lua E.TidyList), removed on the
-- window's Yes - out of a fight (in one: at its end). One line in your own chat frame says how many.
-- ============================================================
local function TidyArgs()
	local a = P.Applied()
	local layout = a and type(a.layout) == "table" and E.SlotMacros(a.layout) or nil
	return layout, ns.db and ns.db.store or nil
end

function P.TidyList()
	return (E.TidyList(TidyArgs()))
end

function P.Tidy()
	if InCombatLockdown() then
		status.tidyWaits = (status.tidyWaits or 0) + 1
		if not ns.Waiting("tidy") then ns.Print(string.format(NAMES.waits, NAMES.tidy)) end
		ns.OutOfCombat("tidy", function() P.Tidy() end)
		return nil, "waiting"
	end
	local n = E.Tidy(TidyArgs())
	status.tidied = (status.tidied or 0) + (n or 0)
	status.lastLine = string.format(n == 1 and NAMES.tidied1 or NAMES.tidied, n or 0)
	ns.Print(status.lastLine)
	if ns.Window then ns.Window.Refresh() end
	return n
end

-- ============================================================
-- The ask
-- ============================================================
function P.ShouldAsk()
	local db = ns.db
	if not db or db.applied or db.never then return false end
	return #P.Matches() > 0
end

function P.Ask()
	if not P.ShouldAsk() then return false end
	ns.OutOfCombat("ask", function()
		if not P.ShouldAsk() then return end
		status.asks = status.asks + 1
		if ns.Window then ns.Window.Open("ask") end
	end)
	return true
end

function P.NotNow()
	if ns.Window then ns.Window.Hide() end
end

function P.Never()
	ns.db.never = true
	if ns.Window then ns.Window.Hide() end
end

-- ============================================================
-- Later: learnt spells, ranks bought, mounts and potions
-- ============================================================
local dirty, pending = false, false
local Soon
function P.Recheck()
	local a = P.Applied()
	if not a or type(a.layout) ~= "table" then return nil end
	local placed, swaps, undone = E.Recheck(P.Store(), { only = E.SpellSlots(a.layout), layout = a.layout })
	if placed == nil then
		dirty = true
		status.recheckWaits = status.recheckWaits + 1
		-- (0.1.5) a push to take off while the player holds something: asked again in a moment (a fight: at its end)
		if E.PushesWaiting(P.Store()) and not InCombatLockdown() then Soon() end
		return nil
	end
	dirty = false
	if swaps == false then dirty = true end                 -- (the rank texts not loaded yet: again later)
	status.rechecks = status.rechecks + 1
	local line = E.PushLine(undone)
	if line then
		status.pushesUndone = (status.pushesUndone or 0) + #undone
		status.lastLine = line
		ns.Print(line)
	end
	if E.PushesWaiting(P.Store()) then Soon() end   -- (a pushed slot not filled yet)
	if ns.Window then ns.Window.Refresh() end
	return placed, swaps
end

function Soon()
	if pending or not ns.ready or not P.Applied() then return end
	pending = true
	C_Timer.After(P.RECHECK_DELAY, function()
		pending = false
		ns.Safe(P.Recheck)
	end)
end
for _, event in ipairs({ "SPELLS_CHANGED", "LEARNED_SPELL_IN_SKILL_LINE", "SPELL_TEXT_UPDATE", "NEW_MOUNT_ADDED",
	"COMPANION_LEARNED", "BAG_UPDATE_DELAYED" }) do
	ns.On(event, Soon)
end
ns.On("PLAYER_REGEN_ENABLED", function() if dirty then Soon() end end)
-- (0.1.5; Harry, Oct 19: "can you find out why inner focus is on E? i guess it took an empty slot when i talented it,
-- and then we assigned it to num1") a spell the game itself put on the bars when it was learnt (its second value the
-- absolute action slot: Engine.lua "THE GAME'S OWN PUSH"): against the preset applied, taken off at the next recheck
ns.On("SPELL_PUSHED_TO_ACTIONBAR", function(_, spell, slot)
	local a = P.Applied()
	if not ns.ready or not a or type(a.layout) ~= "table" then return end
	if E.NotePush(a.layout, P.Store(), spell, slot) then
		status.pushes = (status.pushes or 0) + 1
		Soon()
	end
end)
-- (0.1.2) a level gained: what can be bought now is counted again (the event's level: the game may still say the old)
ns.On("PLAYER_LEVEL_UP", function(_, level)
	level = ns.Num(level)
	if level then status.levelUp = level; E.levelUp = level end
	if ns.Window then ns.Window.Refresh() end
	-- (0.1.11) a food, drink, potion or bandage the new level allows takes its button (Engine.lua's Usable)
	Soon()
end)

-- ============================================================
-- Login
-- ============================================================
local entered = false
function P.LoginLine()
	local a = P.Applied()
	if not a then return nil end
	local state = P.State()
	if state == "updated" then
		local e = P.Find(a.class, a.name)
		if e and ns.db.updatedSaid ~= e.hash then
			ns.db.updatedSaid = e.hash
			return a.name .. " - " .. NAMES.updated
		end
		return nil
	end
	return a.name .. " - " .. P.StateWords()
end

function P.Login()
	P.Forget()
	P.All()
	P.Recheck()
	local line = P.LoginLine()
	if line then
		status.lastLine = line
		ns.Print(line)
	end
	P.Ask()
end

ns.On("PLAYER_ENTERING_WORLD", function()
	if entered or not ns.ready then return end
	entered = true
	status.loginWaiting = true
	C_Timer.After(P.DELAY, function()
		status.loginWaiting = nil
		ns.Safe(P.Login)
	end)
end)
