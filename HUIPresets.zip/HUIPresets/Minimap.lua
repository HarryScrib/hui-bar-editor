local ADDON, ns = ...

-- ============================================================
-- THE MINIMAP BUTTON (Harry: "give it a map icon"): our own, no library. A child of the Minimap named
-- HUIPresetsMinimapButton, dressed the way minimap buttons are - the game's round backing and gold ring
-- (UI-Minimap-Background, MiniMap-TrackingBorder) round the game's own book icon (INV_Misc_Book_09) - so HUI Minimap,
-- when it is there, takes it as any addon's button: on the frame's edge, in HUI's socket, its icon cut round. Left-click
-- opens or closes the window; drag it round the map's edge (its angle kept for this character). Nothing protected;
-- nothing runs per frame except while it is dragged.
-- ============================================================

local M = {}
ns.MinimapButton = M
M.ICON = "Interface\\Icons\\INV_Misc_Book_09"
M.RING, M.BACKING = 136430, 136467                         -- MiniMap-TrackingBorder, UI-Minimap-Background
M.status = { placed = 0, clicks = 0, drags = 0 }

local button

function M.Place()
	if not button then return end
	local mm = _G.Minimap
	local r = 80
	local w = mm and mm.GetWidth and ns.Num(mm:GetWidth())
	if w and w > 0 then r = w / 2 + 10 end
	local a = math.rad(ns.db and ns.db.minimapAngle or 200)
	button:ClearAllPoints()
	button:SetPoint("CENTER", mm, "CENTER", math.cos(a) * r, math.sin(a) * r)
	M.status.placed = M.status.placed + 1
end

local function DragUpdate()
	local mm = _G.Minimap
	local x, y = GetCursorPosition()
	local scale = mm:GetEffectiveScale()
	local cx, cy = mm:GetCenter()
	if not x or not cx or not scale or scale <= 0 then return end
	local angle = math.deg((math.atan2 or math.atan)(y / scale - cy, x / scale - cx)) % 360
	ns.db.minimapAngle = math.floor(angle + 0.5) % 360
	M.Place()
end

function M.Build()
	if button or not _G.Minimap then return button end
	local mm = _G.Minimap
	button = CreateFrame("Button", ns.NAMES.framePrefix .. "MinimapButton", mm)
	button:SetSize(31, 31)
	button:SetFrameStrata("MEDIUM")
	button:SetFrameLevel(mm:GetFrameLevel() + 8)
	button:RegisterForClicks("LeftButtonUp", "RightButtonUp")
	button:RegisterForDrag("LeftButton")
	button:SetHighlightTexture("Interface\\Minimap\\UI-Minimap-ZoomButton-Highlight")
	button.background = button:CreateTexture(nil, "BACKGROUND")
	button.background:SetTexture(M.BACKING)
	button.background:SetSize(20, 20)
	button.background:SetPoint("CENTER", button, "CENTER", 0, 1)
	button.icon = button:CreateTexture(nil, "ARTWORK")
	button.icon:SetTexture(M.ICON)
	button.icon:SetTexCoord(0.08, 0.92, 0.08, 0.92)
	button.icon:SetSize(17, 17)
	button.icon:SetPoint("CENTER", button, "CENTER", 0, 1)
	button.border = button:CreateTexture(nil, "OVERLAY")
	button.border:SetTexture(M.RING)
	button.border:SetSize(53, 53)
	button.border:SetPoint("TOPLEFT", button, "TOPLEFT", 0, 0)
	button:SetScript("OnEnter", function(self)
		GameTooltip:SetOwner(self, "ANCHOR_LEFT")
		GameTooltip:SetText(ns.NAMES.title, 1, 1, 1)
		GameTooltip:Show()
	end)
	button:SetScript("OnLeave", function(self)
		if GameTooltip:GetOwner() == self then GameTooltip:Hide() end
	end)
	button:SetScript("OnClick", ns.Wrap(function()
		M.status.clicks = M.status.clicks + 1
		ns.Window.Toggle()
	end))
	button:SetScript("OnDragStart", function(self)
		M.status.drags = M.status.drags + 1
		self:SetScript("OnUpdate", function() ns.Safe(DragUpdate) end)
	end)
	button:SetScript("OnDragStop", function(self) self:SetScript("OnUpdate", nil) end)
	M.button = button
	M.Place()
	return button
end

ns.OnLogin(function() M.Build() end)
