-- HUI kit (kit/ at the repo root; its change log is kit/KIT.md). Every addon's Kit\ holds a byte-identical copy made
-- by _tools/sync_kit.py: change kit/ and run the sync, never a copy in place.
local ADDON, ns = ...

-- The look: neutral black at 86% opacity, a whisper of light on the top edge,
-- a big soft shadow, no outlines anywhere. Reference: ui-test-space/mockups/
-- polish.css (.fin-op). Surfaces are separated by tone only.

local Skin = {}
ns.Skin = Skin

local MEDIA = "Interface\\AddOns\\" .. ADDON .. "\\Kit\\media\\"

Skin.TEX = {
	panel = MEDIA .. "panel.tga",
	litedge = MEDIA .. "litedge.tga",
	shadow = MEDIA .. "shadow.tga",
	shadow_s = MEDIA .. "shadow_s.tga",      -- KIT.md 16: the window shadow in miniature, for a small panel
	round = MEDIA .. "round.tga",
	slotedge = MEDIA .. "slotedge.tga",
	dot = MEDIA .. "dot.tga",
	close = MEDIA .. "close.tga",
	search = MEDIA .. "search.tga",
	gear = MEDIA .. "gear.tga",
	tick = MEDIA .. "tick.tga",
	check_well = MEDIA .. "check_well.tga",
	check_tick = MEDIA .. "check_tick.tga",
	swatchchip = MEDIA .. "swatchchip.tga",
	chevron = MEDIA .. "chevron.tga",
	grip = MEDIA .. "grip.tga",
	ctlshadow = MEDIA .. "ctlshadow.tga",
	inset = MEDIA .. "inset.tga",
	fade_v = MEDIA .. "fade_v.tga",
	fade_h = MEDIA .. "fade_h.tga",
	rulefade = MEDIA .. "rulefade.tga",
	beam = MEDIA .. "beam.tga",
	bloom_tr = MEDIA .. "bloom_tr.tga",
	bloom_bl = MEDIA .. "bloom_bl.tga",
	logo = MEDIA .. "logo.tga",
	rulelit = MEDIA .. "rulelit.tga",       -- KIT.md 13: a compartment's rule, purple into pearl
	ruleglow = MEDIA .. "ruleglow.tga",     -- its soft glow, white, tinted by the code
}

-- 9-slice margins in texture pixels. Must match tools/make_textures.py (MARGINS).
Skin.SLICE = { panel = 12, litedge = 12, shadow = 112, shadow_s = 44, round = 6, slotedge = 2, ctlshadow = 24, inset = 6 }
Skin.SHADOW_ROOM = 96      -- how far shadow.tga reaches past the window on every side
Skin.SMALL_SHADOW_ROOM = 32 -- and shadow_s.tga (KIT.md 16, kit/tools/make_small_shadow.py)
Skin.CTL_SHADOW_ROOM = 16  -- how far ctlshadow.tga reaches past a control
Skin.PANEL_ALPHA = 0.86    -- default; the live value is Skin.panelAlpha (Skin.SetPanelAlpha)
Skin.panelAlpha = 0.86
Skin.panels = {}           -- every frame skinned with Skin.Panel, so opacity can be changed live
Skin.LIT_EDGE_ALPHA = 0.17 -- litedge.tga stores its fade relative to this peak

Skin.C = {
	text = { 240 / 255, 240 / 255, 240 / 255 },
	body = { 210 / 255, 210 / 255, 210 / 255 },
	mut = { 140 / 255, 140 / 255, 140 / 255 },
	faint = { 94 / 255, 94 / 255, 94 / 255 },
	panel = { 9 / 255, 9 / 255, 10 / 255 },
	panelTop = { 13 / 255, 13 / 255, 14 / 255 },
	panelBottom = { 6 / 255, 6 / 255, 7 / 255 },
	gold = { 0xd9 / 255, 0xb2 / 255, 0x4a / 255 },
	silver = { 0xb9 / 255, 0xbe / 255, 0xc7 / 255 },
	copper = { 0xb0 / 255, 0x70 / 255, 0x3c / 255 },
}

-- White fills, as alpha over the panel.
Skin.A = {
	field = 0.07, fieldHover = 0.10,
	button = 0.08, buttonHover = 0.13, buttonDown = 0.06,
	plate = 0.16,
	rule = 0.05,
	slot = 0.05, slotEmpty = 0.025,
}

-- ============================================================
-- Fonts. Roboto Condensed ships in media/. The client indexes new files only
-- at launch, so after a first install (or if the file is missing) SetFont
-- returns false and we fall back to the game's Arial Narrow, then to a
-- GameFont object. A FontString must never be left without a font: SetText on
-- one throws.
-- ============================================================
-- FACES: the typeface is a choice (0.4.2, the Presentation page's "Font"). Each face names
-- a file per weight and a size scale, because the same point size reads very differently
-- in a condensed face and in a wide one. The game's own fonts (Arial Narrow, Friz Quadrata)
-- are addressed by their path in the client; the bundled ones sit in media/.
local ARIALN, FRIZ = "Fonts\\ARIALN.TTF", "Fonts\\FRIZQT__.TTF"
Skin.FACES = {
	roboto = { name = "Roboto Condensed", scale = 1.00,
		regular = MEDIA .. "RobotoCondensed-Regular.ttf", medium = MEDIA .. "RobotoCondensed-Medium.ttf" },
	barlow = { name = "Barlow Semi Condensed", scale = 0.96,
		regular = MEDIA .. "BarlowSemiCondensed-Medium.ttf", medium = MEDIA .. "BarlowSemiCondensed-SemiBold.ttf" },
	arialn = { name = "Arial Narrow", scale = 1.04, regular = ARIALN, medium = ARIALN },
	friz = { name = "Friz Quadrata", scale = 0.90, regular = FRIZ, medium = FRIZ },
	-- 0.4.3: four more, picked from a side-by-side at game size (ui-test-space/mockups/out/00-fonts.png).
	-- All SIL Open Font License, bundled with their licence texts. Left out on purpose: Barlow
	-- Condensed (too tight at chat sizes), Cabin Condensed (reads informal), and faces that only
	-- ship as variable fonts (Archivo Narrow, Sofia Sans).
	fira = { name = "Fira Sans Condensed", scale = 0.96,
		regular = MEDIA .. "FiraSansCondensed-Regular.ttf", medium = MEDIA .. "FiraSansCondensed-Medium.ttf" },
	plex = { name = "IBM Plex Sans Condensed", scale = 0.96,
		regular = MEDIA .. "IBMPlexSansCondensed-Regular.ttf", medium = MEDIA .. "IBMPlexSansCondensed-Medium.ttf" },
	saira = { name = "Saira Semi Condensed", scale = 0.95,
		regular = MEDIA .. "SairaSemiCondensed-Regular.ttf", medium = MEDIA .. "SairaSemiCondensed-Medium.ttf" },
	encode = { name = "Encode Sans Semi Condensed", scale = 0.93,
		regular = MEDIA .. "EncodeSansSemiCondensed-Regular.ttf", medium = MEDIA .. "EncodeSansSemiCondensed-Medium.ttf" },
	-- 0.4.4: three with more character (Harry: "a bit more creative"), picked from
	-- ui-test-space/mockups/out/00-fonts-creative.png. Also OFL. Marcellus has one weight.
	-- Left out: Almendra (fantasy calligraphy, costume), Rajdhani (thin and grey when small),
	-- Tenor Sans (too widely spaced for chat).
	marcellus = { name = "Marcellus", scale = 0.92,
		regular = MEDIA .. "Marcellus-Regular.ttf", medium = MEDIA .. "Marcellus-Regular.ttf" },
	philosopher = { name = "Philosopher", scale = 0.96,
		regular = MEDIA .. "Philosopher-Regular.ttf", medium = MEDIA .. "Philosopher-Bold.ttf" },
	chakra = { name = "Chakra Petch", scale = 0.92,
		regular = MEDIA .. "ChakraPetch-Regular.ttf", medium = MEDIA .. "ChakraPetch-Medium.ttf" },
}
Skin.FACE_ORDER = { "arialn", "roboto", "barlow", "fira", "plex", "saira", "encode", "friz", "marcellus", "philosopher", "chakra" }
Skin.face = "arialn" -- Harry's pick after trying them in game (0.4.3); Core sets the saved choice at load

Skin.fontStatus = {} -- [path] = did the last SetFont with it succeed (read by /bags debug)

-- (kit/KIT.md 39) Every font the kit sets goes through Kit\Fonts.lua: the same file, size and flags, drawn by a font
-- family so a Korean, Chinese or Russian name in it is drawn by the game's file for its alphabet, not as boxes.
local function SetFont(target, path, size, flags)
	local Fonts = ns.Fonts
	if Fonts then return Fonts.Set(target, path, size, flags) end
	return target:SetFont(path, size, flags)
end
Skin.SetFont = SetFont

-- Every font string and font object the kit has dressed, with what it asked for, so a new
-- face can be laid on all of them at once. Weak keys: a region that goes away is forgotten.
-- One small table per target, made once; re-dressing reuses it.
local dressed = setmetatable({}, { __mode = "k" })

-- WHOLE PIXELS (Sep 25, kit/KIT.md 10). A face's size factor makes fractional sizes (Arial Narrow 12 x 1.04 = 12.48,
-- Chakra 12 x 0.92 = 11.04) and the client draws a fractional height soft: Harry, "too small as it looks
-- blurry ... almost pixelated". The size is rounded to a whole number of SCREEN pixels at the target's
-- effective scale (the UI scale and any window scale), never below 6.
local function PixelSize(target, size)
	if type(size) ~= "number" then return size end
	local scale
	local ok, s = pcall(target.GetEffectiveScale, target)
	if ok and type(s) == "number" and s > 0 then scale = s end
	if not scale and UIParent and UIParent.GetEffectiveScale then scale = UIParent:GetEffectiveScale() end
	if type(scale) ~= "number" or scale <= 0 then return size end
	local px = math.max(6, math.floor(size * scale + 0.5))
	return px / scale
end
Skin.PixelSize = PixelSize

local function Dress(target, spec)
	-- spec.face pins one target to a face of its own (a font list shows each name in its own
	-- face); nil follows the chosen one.
	local face = Skin.FACES[spec.face or Skin.face] or Skin.FACES.arialn
	local size = PixelSize(target, spec.size * face.scale)
	local first = face[spec.weight] or face.regular
	for i = 1, 2 do
		local path = i == 1 and first or ARIALN
		local ok, result = pcall(SetFont, target, path, size, spec.flags)
		-- FontString:SetFont returns a boolean. If a widget type returns nothing, trust GetFont.
		local loaded = ok and (result or (result == nil and target:GetFont() ~= nil)) and true or false
		Skin.fontStatus[path] = loaded
		if loaded then return true end
	end
	target:SetFontObject(GameFontHighlightSmall)
	return false
end

-- face (optional): a FACES key this target keeps whatever the chosen face is.
function Skin.ApplyFont(target, weight, size, flags, face)
	local spec = dressed[target]
	if not spec then
		spec = {}
		dressed[target] = spec
	end
	spec.weight, spec.size, spec.flags, spec.face = weight or "regular", size, flags or "", face
	return Dress(target, spec)
end

-- (kit/KIT.md 29) Every target dressed so far under `frame` (frame itself and its descendants) forgotten: the kit
-- never dresses them again - font strings handed to the game (a CustomAuraContainer's button, which the game restricts
-- right after its initializeFrame: a new face laid on them later would be refused). Returns how many.
function Skin.ForgetUnder(frame)
	local n = 0
	for target in pairs(dressed) do
		local p, depth = target, 0
		while p and depth < 20 do
			if p == frame then
				dressed[target] = nil
				n = n + 1
				break
			end
			local ok, parent = pcall(p.GetParent, p)
			p = ok and parent or nil
			depth = depth + 1
		end
	end
	return n
end

-- A new face on everything already dressed. Returns how many were changed. A layout that
-- measured its text when it was built (tracked caps, tab widths) is only exact again after
-- a /reload; everything else follows at once.
local trackedAll = setmetatable({}, { __mode = "k" }) -- every Skin.Tracked word, for a new face (below)

function Skin.SetFontFace(key)
	if not Skin.FACES[key] then key = "arialn" end
	if key == Skin.face then return 0 end
	Skin.face = key
	local n = 0
	for target, spec in pairs(dressed) do
		Dress(target, spec)
		n = n + 1
	end
	for word in pairs(trackedAll) do word:Relayout() end -- (KIT.md 14: tracked words measured again)
	return n
end

-- (kit/KIT.md 9) A face the client had not drawn yet loads a moment AFTER SetFont: until then every string in it
-- draws empty and measures 0 wide, and setting the same text again does not redraw it (Harry, Sep 25:
-- "if i change the font then quests disappear"). This sets every dressed string's text afresh; called
-- once the face has had time to load (Core: ns.ApplyFont). Returns how many were redrawn.
function Skin.Redraw()
	local n = 0
	for target in pairs(dressed) do
		if target.GetObjectType and target:GetObjectType() == "FontString" then
			local text = target:GetText()
			-- issecretvalue FIRST: comparing a secret (an NPC's name, a meter's number in combat) errors in addon code
			-- (kit/KIT.md 12). A secret text is left as it is.
			local secret = issecretvalue and issecretvalue(text)
			if not secret and text ~= nil and text ~= "" then
				target:SetText("")
				target:SetText(text)
				n = n + 1
			end
		end
	end
	for word in pairs(trackedAll) do word:Relayout() end -- (KIT.md 14: the face has loaded; measure again)
	return n
end

-- Every face loaded ahead of time, so picking one in HUI Menus finds it ready and nothing blanks
-- (Harry, Sep 25: "when i click a new font - it flashes invisible for like a second and then settles").
-- One tiny string per file, drawn off screen (a face loads when it is first drawn) and left there: they
-- never change, so they cost nothing after the first frame. Called once, at login.
function Skin.Preload()
	if Skin.preloaded then return 0 end
	Skin.preloaded = true
	local host = CreateFrame("Frame", nil, UIParent)
	host:SetSize(1, 1)
	host:SetPoint("TOPLEFT", UIParent, "TOPLEFT", -4000, 4000)
	host:SetAlpha(0.01)
	local seen, n = {}, 0
	for _, key in ipairs(Skin.FACE_ORDER) do
		local face = Skin.FACES[key]
		for _, weight in ipairs({ "regular", "medium" }) do
			local path = face and face[weight]
			if path and not seen[path] then
				seen[path] = true
				local fs = host:CreateFontString(nil, "OVERLAY")
				if pcall(SetFont, fs, path, 12, "") then
					fs:SetPoint("TOPLEFT", host, "TOPLEFT", 0, 0)
					fs:SetText("Aa 0123")
					n = n + 1
				end
			end
		end
	end
	host:Show()
	Skin.preloadedCount = n
	return n
end

function Skin.Text(parent, weight, size, color, justify, layer)
	local fs = parent:CreateFontString(nil, layer or "OVERLAY")
	Skin.ApplyFont(fs, weight, size)
	fs:SetTextColor(color[1], color[2], color[3], color[4] or 1)
	fs:SetJustifyH(justify or "LEFT")
	fs:SetWordWrap(false)
	return fs
end

-- ============================================================
-- TRACKED CAPITALS (kit/KIT.md 14, the HUI settings hub's headings; the same code in HUI Menus' Kit\Skin.lua). The client has no
-- letter spacing, so a tracked word is one FontString per letter, laid out by measured widths with every
-- letter and the word's width on whole units (GameMenu.lua's title, made shared). It is measured again when
-- it is shown, when its text changes and when the face changes, so a new face never leaves uneven gaps.
--   local word = Skin.Tracked(parent, text, weight, size, colour, tracking)   a Frame, sized to its letters
--   word:SetText(text)   word:GetText()   word:SetTextColor(r, g, b[, a])   word:Relayout()   word.width
-- ============================================================
local function TrackedRelayout(word)
	local x, n = 0, 0
	local step = word.tracking
	for i = 1, word.count do
		local fs = word.letters[i]
		fs:ClearAllPoints()
		fs:SetPoint("LEFT", word, "LEFT", x, 0)
		local w = fs:GetStringWidth() or 0
		if w <= 0 then w = word.size * 0.35 end -- a space measures nothing
		x = x + math.floor(w + step + 0.5)
		n = n + 1
	end
	local width = n > 0 and math.max(1, x - math.floor(step + 0.5)) or 1
	word.width = width
	word:SetSize(width, math.ceil(word.size) + 4)
end

local function TrackedSetText(word, text)
	text = tostring(text or "")
	if text == word.text then return end
	word.text = text
	local n = 0
	for ch in string.gmatch(text, "[^\128-\191][\128-\191]*") do
		n = n + 1
		local fs = word.letters[n]
		if not fs then
			fs = Skin.Text(word, word.weight, word.size, word.colour)
			word.letters[n] = fs
		end
		fs:SetText(ch)
		fs:Show()
	end
	for i = n + 1, #word.letters do
		word.letters[i]:SetText("")
		word.letters[i]:Hide()
	end
	word.count = n
	TrackedRelayout(word)
end

local function TrackedSetTextColor(word, r, g, b, a)
	word.colour = { r, g, b, a or 1 }
	for i = 1, #word.letters do word.letters[i]:SetTextColor(r, g, b, a or 1) end
end

function Skin.Tracked(parent, text, weight, size, colour, tracking)
	local word = CreateFrame("Frame", nil, parent)
	word.weight, word.size, word.colour, word.tracking = weight or "medium", size, colour, tracking or 2
	word.letters, word.count, word.text = {}, 0, nil
	word.SetText, word.GetText, word.SetTextColor, word.Relayout =
		TrackedSetText, function(self) return self.text end, TrackedSetTextColor, TrackedRelayout
	word:SetScript("OnShow", TrackedRelayout)
	trackedAll[word] = true
	word:SetText(text)
	return word
end

-- ============================================================
-- Textures
-- ============================================================
-- A 9-sliced texture. Slice mode is left at the client default (Stretched).
function Skin.Slice(parent, key, layer, sublevel)
	local t = parent:CreateTexture(nil, layer or "BACKGROUND", nil, sublevel or 0)
	t:SetTexture(Skin.TEX[key])
	local m = Skin.SLICE[key]
	t:SetTextureSliceMargins(m, m, m, m)
	return t
end

-- Rounded white fill covering a control.
function Skin.Fill(frame, alpha, layer, sublevel)
	local t = Skin.Slice(frame, "round", layer or "BACKGROUND", sublevel)
	t:SetAllPoints(frame)
	t:SetVertexColor(1, 1, 1, alpha)
	return t
end

function Skin.Icon(parent, key, size, color, layer)
	local t = parent:CreateTexture(nil, layer or "ARTWORK")
	t:SetTexture(Skin.TEX[key])
	t:SetSize(size, size)
	t:SetVertexColor(color[1], color[2], color[3], color[4] or 1)
	return t
end

-- ============================================================
-- THE PURPLE EDGE lives in Edge.lua since KIT.md 18: one edge engine, the same file in HUI Menus' kit, every glow
-- named by its element (Skin.Glow, Skin.EdgeGlow, Skin.SetGlow, Skin.SetGlowColour, Skin.GlowTexture, the suite's
-- edge followed). Each .toc loads Kit\Edge.lua right after this file.
-- ============================================================
-- ForeverQuests 0.1.0 (kit/KIT.md 5): THE STATUS PALETTE, copied from ForeverMenus' Kit\Skin.lua
-- (Harry, Sep 23 2026, after the Warcraft Logs parse colours): the suite's colours for "how good /
-- how likely / how hard". Never green: cyan and blue take green's place.
Skin.PALETTE = {
	pink   = { 226 / 255, 104 / 255, 168 / 255 },
	purple = { 163 / 255, 53 / 255, 238 / 255 },
	orange = { 255 / 255, 128 / 255, 0 / 255 },
	gold   = { 229 / 255, 204 / 255, 128 / 255 },
	blue   = { 0 / 255, 112 / 255, 221 / 255 },
	cyan   = { 64 / 255, 200 / 255, 230 / 255 },
	grey   = { 150 / 255, 150 / 255, 158 / 255 },
}

-- The window surface: shadow underneath, black fill, lit top edge. No outline.
-- opts (optional): glowKey = the element its edge is (KIT.md 18: kit/DESIGN-edges.md 2); glowReach = a shorter reach
-- for small popups; smallShadow = true for a small surface (KIT.md 16): the window shadow in miniature; glow = false for
-- a surface with no edge of its own, which then says why: glowBy = the element that draws its edge, or glowWhy = a
-- reason (KIT.md 18); stone = true (KIT.md 21) for a glass whose owner draws its own fill on it (below).
--
-- (KIT.md 21) A STONE PANEL: the kit's glass on its own layer frame, its fill the owner's (HUI Quests' smoked stone,
-- TrackerList.StoneOn; HUI Journal's window). The kit's own fill is hidden and the Elune overlays move up three, to
-- -2..0 (frame.skinLayerBase), so the owner's three layers sit at Skin.STONE_LAYERS - fill -6, lift -5, grain -4 -
-- above the edge (-7) and the shadow (-8) and under the beam and blooms, in the order the stone always had:
--   BACKGROUND -8 shadow, -7 the edge, -6 the stone's fill, -5 its lift, -4 its grain, -2..0 the beam and blooms
--   BORDER 0 the lit edge
Skin.STONE_LAYERS = { fill = -6, lift = -5, grain = -4 }
local STONE_LAYER_BASE = -3 -- (the overlays at base + 1..3; without it -6: -5..-3, just above the kit's fill)

function Skin.Panel(frame, opts)
	local room = Skin.SHADOW_ROOM
	local stone = opts and opts.stone and true or false
	if stone then frame.skinLayerBase = STONE_LAYER_BASE end
	if opts and opts.glow == false then
		frame.skinGlowBy, frame.skinGlowWhy = opts.glowBy, opts.glowWhy
		ns.Edge.Unlit(frame)
	else
		frame.skinGlow = Skin.Glow(frame, opts and opts.glowReach, nil, nil, opts and opts.glowKey) -- edge: through
	end

	-- The shadow texture has the window's own rectangle cut out of it and the
	-- downward offset baked in, so it is anchored symmetrically.
	-- (KIT.md 16) Its 9-slice corners are 112 texels, 96 of them past the window, so it only
	-- fits a window 32 units tall or more; a smaller one (a small pane's row, a hover card)
	-- takes shadow_s.tga, the same shadow drawn at a quarter (its drops and blurs), its cut-out
	-- still the panel's own rounded corner, 32 units of room and 12 inside (fits 24 or more).
	local key = "shadow"
	if opts and opts.smallShadow then key, room = "shadow_s", Skin.SMALL_SHADOW_ROOM end
	local shadow = Skin.Slice(frame, key, "BACKGROUND", -8)
	shadow:SetPoint("TOPLEFT", frame, "TOPLEFT", -room, room)
	shadow:SetPoint("BOTTOMRIGHT", frame, "BOTTOMRIGHT", room, -room)
	shadow:SetVertexColor(0, 0, 0, 1)

	local fill = Skin.Slice(frame, "panel", "BACKGROUND", -6)
	fill:SetAllPoints(frame)
	if stone then fill:Hide() end -- (KIT.md 21: the owner's own fill takes its place)

	local edge = Skin.Slice(frame, "litedge", "BORDER", 0)
	edge:SetAllPoints(frame)
	edge:SetVertexColor(1, 1, 1, Skin.LIT_EDGE_ALPHA)

	frame.skinShadow, frame.skinFill, frame.skinEdge = shadow, fill, edge
	Skin.panels[#Skin.panels + 1] = frame
	Skin.PaintPanel(frame)
end

-- ============================================================
-- THE THEME IS INTENTIONALLY NOT USER-CONFIGURABLE IN THIS ADDON. The base look
-- is the "elune" skin at fixed strengths (Skin.BASE_SKIN / Skin.BASE_OPTIONS,
-- applied at login). Choosing a theme will belong to the suite layer shared by
-- all of the owner's addons; it will drive this through Skin.SetSkin(name,
-- options), which is why the skin table, the "default" skin and the strength
-- parameters are all kept here even though nothing in ForeverBags exposes them.
--
-- Skins. A skin is only light and hue on the same glass: a base tint for the
-- fill, a tint for the lit edge, and a list of overlay layers. Shape, shadow,
-- fonts, text colours and controls never change with the skin.
--
--   Skin.skins[id] = {
--     name  = "Shown to the player",
--     base  = { r, g, b }, baseTop = {...}, baseBottom = {...},   -- fill (flat / gradient ends)
--     edge  = { r, g, b, a },                                     -- lit edge colour and peak alpha
--     layers = { { key, texture (a Skin.TEX key), blend, color = { r, g, b },
--                  alpha = function(options) return 0..1 end }, ... },
--   }
--
-- A layer is one texture stretched over the panel, above the fill and below
-- everything else (BACKGROUND sublevels -5 and up; a window's own textures and
-- all child frames draw over it). Its alpha function receives the options table
-- given to Skin.SetSkin (for ForeverBags that is the saved-variables table);
-- 0 hides the layer. Layer textures are created the first time a skin that has
-- them is applied to a panel, so the default skin costs nothing. They are only
-- touched again when Skin.SetSkin or Skin.SetPanelAlpha is called: nothing per frame.
--
-- Clipping. The panel has 7px rounded corners, the overlays are rectangles. A
-- rectangle inset by R * (1 - 1/sqrt(2)) = 2.05px has its corners exactly on
-- the arc, so insetting every layer by 2px keeps all of it inside the glass and
-- off the shadow, with no mask. What it costs is a 2px unlit rim, under light
-- this faint (at most 6%) not something the eye finds. A MaskTexture would be
-- exact, but the mask would itself have to be 9-sliced to follow the panel at
-- any size, and nothing in Blizzard's source shows a sliced mask, so that is
-- only an experiment: Skin.SetSkin(name, options) with options.skinMask = true.
-- ============================================================
Skin.OVERLAY_INSET = 2
Skin.textureStatus = {} -- [Skin.TEX key] = what SetTexture returned for an overlay (read by /bags debug)

local WHITE_EDGE = { 1, 1, 1, Skin.LIT_EDGE_ALPHA }

Skin.skins = {
	default = {
		name = "Default",
		base = Skin.C.panel, baseTop = Skin.C.panelTop, baseBottom = Skin.C.panelBottom,
		edge = WHITE_EDGE,
		layers = {},
	},

	-- "Elune": a broad fall of pale lavender light from the top-right corner and a
	-- trace of royal purple in the glass. Reference: polish.css .el-beam.r3.
	--   beamStrength   50 = the approved beam (peak alpha 0.06), 100 = twice that.
	--   purpleStrength 25 = the approved "royal purple 25%" (0.052 top right, 0.03
	--                  bottom left), 100 = four times that (0.208 / 0.12).
	elune = {
		name = "Elune",
		base = { 9 / 255, 9 / 255, 11 / 255 },
		baseTop = { 13 / 255, 13 / 255, 15 / 255 }, baseBottom = { 6 / 255, 6 / 255, 7 / 255 },
		-- ForeverBars 0.2.0 (kit/KIT.md 3): the suite colours. Lit edge and beam in the lunar
		-- pearl L2 (were lavender 216,208,255 / 206,196,255); the blooms in D1 and its darker end
		-- (were 116,58,178 / 78,36,132).
		edge = { 239 / 255, 237 / 255, 248 / 255, 0.20 },
		layers = {
			{ key = "beam", texture = "beam", blend = "ADD", color = { 239 / 255, 237 / 255, 248 / 255 },
				alpha = function(o) return 0.06 * (o.beamStrength or 50) / 50 end },
			{ key = "bloomTop", texture = "bloom_tr", blend = "ADD", color = { 103 / 255, 53 / 255, 167 / 255 },
				alpha = function(o) return 0.052 * (o.purpleStrength or 25) / 25 end },
			{ key = "bloomBottom", texture = "bloom_bl", blend = "ADD", color = { 80 / 255, 40 / 255, 132 / 255 },
				alpha = function(o) return 0.03 * (o.purpleStrength or 25) / 25 end },
		},
	},
}
Skin.skinOrder = { "default", "elune" }

-- The one look this addon ships with. Panels painted before login already get it.
Skin.BASE_SKIN = "elune"
Skin.BASE_OPTIONS = { beamStrength = 50, purpleStrength = 25 }
Skin.skinName = Skin.BASE_SKIN
Skin.skinOptions = Skin.BASE_OPTIONS

function Skin.GetSkin()
	return Skin.skins[Skin.skinName] or Skin.skins.default
end

-- The experimental exact clip: a 9-sliced MaskTexture in the panel's shape.
local function GetMask(frame)
	if frame.skinMask == nil then
		frame.skinMask = false
		local ok, mask = pcall(function()
			local m = frame:CreateMaskTexture()
			m:SetTexture(Skin.TEX.panel, "CLAMPTOBLACKADDITIVE", "CLAMPTOBLACKADDITIVE")
			local margin = Skin.SLICE.panel
			m:SetTextureSliceMargins(margin, margin, margin, margin)
			m:SetAllPoints(frame)
			return m
		end)
		if ok and mask then frame.skinMask = mask end
	end
	return frame.skinMask or nil
end

local function ApplyLayers(frame, skin, options)
	local made = frame.skinLayers
	local useMask = options.skinMask and true or false

	if made then
		for _, tex in pairs(made) do tex:Hide() end
	end

	for index, layer in ipairs(skin.layers) do
		local alpha = layer.alpha(options) or 0
		if alpha > 0 then
			if not made then
				made = {}
				frame.skinLayers = made
			end
			local id = Skin.skinName .. ":" .. layer.key
			local tex = made[id]
			if not tex then
				-- -5, -4, -3: just above the fill; (KIT.md 21) a stone panel's at -2, -1, 0, over the owner's own layers
				tex = frame:CreateTexture(nil, "BACKGROUND", nil, (frame.skinLayerBase or -6) + index)
				Skin.textureStatus[layer.texture] = tex:SetTexture(Skin.TEX[layer.texture])
				tex:SetBlendMode(layer.blend or "BLEND")
				made[id] = tex
			end

			if frame.skinMasked ~= useMask or not tex.skinPlaced then
				local inset = Skin.OVERLAY_INSET
				local mask = useMask and GetMask(frame) or nil
				if mask then inset = 0 end
				tex:ClearAllPoints()
				tex:SetPoint("TOPLEFT", frame, "TOPLEFT", inset, -inset)
				tex:SetPoint("BOTTOMRIGHT", frame, "BOTTOMRIGHT", -inset, inset)
				if mask and not tex.skinHasMask then
					tex.skinHasMask = pcall(tex.AddMaskTexture, tex, mask)
				elseif not mask and tex.skinHasMask then
					pcall(tex.RemoveMaskTexture, tex, frame.skinMask)
					tex.skinHasMask = false
				end
				tex.skinPlaced = true
			end

			tex:SetVertexColor(layer.color[1], layer.color[2], layer.color[3], alpha)
			tex:Show()
		end
	end
	frame.skinMasked = useMask
end

-- name: a key of Skin.skins. options: the table the layers' alpha functions read.
-- Repaints every panel at once.
function Skin.SetSkin(name, options)
	Skin.skinName = Skin.skins[name] and name or "default"
	Skin.skinOptions = options or Skin.skinOptions
	for i = 1, #Skin.panels do
		Skin.PaintPanel(Skin.panels[i])
	end
end

-- alpha 0..1. Repaints every panel. A frame may set frame.skinMinAlpha to stay
-- more opaque than the setting (popup lists, which must stay readable).
function Skin.SetPanelAlpha(alpha)
	Skin.panelAlpha = alpha
	for i = 1, #Skin.panels do
		Skin.PaintPanel(Skin.panels[i])
	end
end

-- Flat 9,9,10 by default. Whether SetGradient cooperates with a 9-sliced
-- texture could not be checked from the source, so the gradient (13,13,14 down
-- to 6,6,7) is behind "/bags gradient on" until it has been seen in game.
function Skin.PaintPanel(frame)
	local fill = frame.skinFill
	if not fill then return end
	local skin, a = Skin.GetSkin(), Skin.panelAlpha
	if frame.skinMinAlpha and a < frame.skinMinAlpha then a = frame.skinMinAlpha end
	local done = false
	if ns.db and ns.db.gradient and CreateColor then
		local top, bottom = skin.baseTop, skin.baseBottom
		fill:SetVertexColor(1, 1, 1, 1)
		done = pcall(fill.SetGradient, fill, "VERTICAL",
			CreateColor(bottom[1], bottom[2], bottom[3], a),
			CreateColor(top[1], top[2], top[3], a))
	end
	if not done then
		-- A uniform vertex colour replaces any gradient set earlier. SetGradient is
		-- never called on the default path.
		fill:SetVertexColor(skin.base[1], skin.base[2], skin.base[3], a)
	end

	local edge = skin.edge
	frame.skinEdge:SetVertexColor(edge[1], edge[2], edge[3], edge[4])

	-- Nothing to do, and nothing created, for a skin without layers on a panel that never had any.
	if frame.skinLayers or #skin.layers > 0 then
		ApplyLayers(frame, skin, Skin.skinOptions)
	end
end

-- ============================================================
-- Controls. No outlines: a control is a slightly lighter rounded fill.
-- ============================================================
local function SetFillAlpha(tex, alpha)
	tex:SetVertexColor(1, 1, 1, alpha)
end

-- Text button. onClick runs through ns.Safe.
function Skin.Button(parent, label, onClick)
	local b = CreateFrame("Button", nil, parent)
	b:SetHeight(24)
	b.fill = Skin.Fill(b, Skin.A.button)
	b.text = Skin.Text(b, "regular", 12, Skin.C.body, "CENTER")
	b.text:SetPoint("CENTER", 0, 0)
	b.text:SetText(label)
	b:SetWidth(math.max(36, math.ceil(b.text:GetStringWidth() or 30) + 22))

	b:SetScript("OnEnter", function(self)
		SetFillAlpha(self.fill, Skin.A.buttonHover)
		self.text:SetTextColor(Skin.C.text[1], Skin.C.text[2], Skin.C.text[3])
		if self.tooltip then
			-- The host's tooltip placement rule when it has one (ForeverMenus: Tooltips\Anchor.lua).
			if ns.Tooltip and ns.Tooltip.SetOwner then
				ns.Tooltip.SetOwner(self, "ANCHOR_TOP")
			else
				GameTooltip:SetOwner(self, "ANCHOR_TOP")
			end
			GameTooltip:SetText(self.tooltip, 1, 1, 1)
			GameTooltip:Show()
		end
	end)
	b:SetScript("OnLeave", function(self)
		SetFillAlpha(self.fill, Skin.A.button)
		self.text:SetTextColor(Skin.C.body[1], Skin.C.body[2], Skin.C.body[3])
		GameTooltip:Hide()
	end)
	b:SetScript("OnMouseDown", function(self) SetFillAlpha(self.fill, Skin.A.buttonDown) end)
	b:SetScript("OnMouseUp", function(self)
		SetFillAlpha(self.fill, self:IsMouseOver() and Skin.A.buttonHover or Skin.A.button)
	end)
	b:SetScript("OnClick", function() ns.Safe(onClick) end)
	return b
end

-- Square button holding one of the small icon textures (the close cross).
function Skin.IconButton(parent, key, size, onClick)
	local b = CreateFrame("Button", nil, parent)
	b:SetSize(size, size)
	b.fill = Skin.Fill(b, Skin.A.button)
	b.icon = Skin.Icon(b, key, 12, Skin.C.body)
	b.icon:SetPoint("CENTER", 0, 0)

	b:SetScript("OnEnter", function(self)
		SetFillAlpha(self.fill, Skin.A.buttonHover)
		self.icon:SetVertexColor(1, 1, 1, 1)
	end)
	b:SetScript("OnLeave", function(self)
		SetFillAlpha(self.fill, Skin.A.button)
		self.icon:SetVertexColor(Skin.C.body[1], Skin.C.body[2], Skin.C.body[3], 1)
	end)
	b:SetScript("OnClick", function() ns.Safe(onClick) end)
	return b
end

-- Segmented control. items = { { value, label }, ... }. onSelect(value) runs through ns.Safe.
function Skin.Segmented(parent, items, onSelect)
	local PAD, SEG_HEIGHT, SEG_PAD = 3, 20, 10
	local seg = CreateFrame("Frame", nil, parent)
	seg.fill = Skin.Fill(seg, Skin.A.field)
	seg.buttons = {}

	local x = PAD
	for i, item in ipairs(items) do
		local b = CreateFrame("Button", nil, seg)
		b.value = item[1]
		b.plate = Skin.Fill(b, Skin.A.plate)
		b.plate:Hide()
		b.text = Skin.Text(b, "regular", 12, Skin.C.mut, "CENTER")
		b.text:SetPoint("CENTER", 0, 0)
		b.text:SetText(item[2])
		local width = math.ceil(b.text:GetStringWidth() or 30) + SEG_PAD * 2
		b:SetSize(width, SEG_HEIGHT)
		b:SetPoint("LEFT", seg, "LEFT", x, 0)
		x = x + width

		b:SetScript("OnEnter", function(self)
			if not self.selected then self.text:SetTextColor(Skin.C.body[1], Skin.C.body[2], Skin.C.body[3]) end
		end)
		b:SetScript("OnLeave", function(self)
			if not self.selected then self.text:SetTextColor(Skin.C.mut[1], Skin.C.mut[2], Skin.C.mut[3]) end
		end)
		b:SetScript("OnClick", function(self) ns.Safe(onSelect, self.value) end)
		seg.buttons[i] = b
	end
	seg:SetSize(x + PAD, SEG_HEIGHT + PAD * 2)

	function seg:SetValue(value)
		for _, b in ipairs(self.buttons) do
			local on = b.value == value
			b.selected = on
			b.plate:SetShown(on)
			if on then
				b.text:SetTextColor(1, 1, 1)
			else
				b.text:SetTextColor(Skin.C.mut[1], Skin.C.mut[2], Skin.C.mut[3])
			end
		end
	end
	return seg
end

-- Search field: rounded fill, magnifier, placeholder. onChanged(text) runs through ns.Safe.
-- (kit/KIT.md 28) opts, optional: { hint = "ID or name" (the placeholder's words; "Search" without it), icon = false (the
-- magnifier left out, the text starting where it was) }. Without opts, exactly as before.
local SEARCH_ICON_X, SEARCH_TEXT_X = 8, 26   -- the magnifier's left, and the text's after it
function Skin.SearchBox(parent, onChanged, opts)
	local hint = type(opts) == "table" and type(opts.hint) == "string" and opts.hint or "Search"
	local icon = not (type(opts) == "table" and opts.icon == false)
	local box = CreateFrame("Frame", nil, parent)
	box:SetHeight(24)
	box.fill = Skin.Fill(box, Skin.A.field)
	if icon then
		box.icon = Skin.Icon(box, "search", 12, Skin.C.mut)
		box.icon:SetPoint("LEFT", SEARCH_ICON_X, 0)
	end

	local edit = CreateFrame("EditBox", nil, box)
	Skin.ApplyFont(edit, "regular", 12)
	edit:SetTextColor(Skin.C.text[1], Skin.C.text[2], Skin.C.text[3])
	edit:SetAutoFocus(false)
	edit:SetMaxLetters(30)
	edit:SetPoint("TOPLEFT", box, "TOPLEFT", icon and SEARCH_TEXT_X or SEARCH_ICON_X, 0)
	edit:SetPoint("BOTTOMRIGHT", box, "BOTTOMRIGHT", -8, 0)
	box.edit = edit

	box.hint = Skin.Text(box, "regular", 12, Skin.C.faint)
	box.hint:SetPoint("LEFT", edit, "LEFT", 0, 0)
	box.hint:SetText(hint)

	local function UpdateHint()
		box.hint:SetShown(edit:GetText() == "" and not edit:HasFocus())
	end
	edit:SetScript("OnTextChanged", function(self)
		UpdateHint()
		ns.Safe(onChanged, self:GetText() or "")
	end)
	edit:SetScript("OnEditFocusGained", function()
		SetFillAlpha(box.fill, Skin.A.fieldHover)
		UpdateHint()
	end)
	edit:SetScript("OnEditFocusLost", function()
		SetFillAlpha(box.fill, Skin.A.field)
		UpdateHint()
	end)
	edit:SetScript("OnEnterPressed", function(self) self:ClearFocus() end)
	edit:SetScript("OnEscapePressed", function(self)
		self:SetText("")
		self:ClearFocus()
	end)

	-- Clicking the icon or padding focuses the field too.
	box:EnableMouse(true)
	box:SetScript("OnMouseDown", function() edit:SetFocus() end)

	function box:Clear()
		if edit:GetText() ~= "" then edit:SetText("") end
		edit:ClearFocus()
	end
	return box
end
