local ADDON, ns = ...

-- ============================================================
-- (HUI Presets 0.1.0: COPIED from HUI Bars' LayoutCodec.lua 0.16.1 and grown here - Sanitize also keeps `race`,
-- `settings` and the slot kinds mount, family and slot. HUI Bars' own copy is not changed by this one.) It needs
-- nothing of its host: it publishes ns.LayoutCodec and touches no game state.
-- (0.15.0, actionbars/LAYOUT-FORMAT.md, actionbars/BUILD-layouts-ingame.md 6) THE LAYOUT'S TEXT AND ITS EXPORT STRING.
-- One format for the game and the offline editor (actionbars/editor). The byte rules are written down in
-- actionbars/layout-fixtures/README.md and proved both ways by the fixtures there; in short:
--   Write(t)   a deterministic Lua table text of our own: no spaces, "," between fields, the array part (1..n) first,
--              then integer keys ascending as [n]=, then string keys in byte order as name= (["..."]= when not a plain
--              name); strings in double quotes, \\ \" \n \r \t escaped, every other byte under 32 and 127 as \ddd, the
--              rest as they are (UTF-8 passes through); integers only (a non-integer number is refused); true / false.
--   Read(s)    a small reader of Lua table text (never loadstring: an imported string is data, never code).
--   Export(l)  "HUI1!" .. base64(raw DEFLATE(Write(l))) through the game's own C_EncodingUtil (1.60.1 has it:
--              CompressString / DecompressString, EncodeBase64 / DecodeBase64); a client without it: "HUI0!" ..
--              base64(Write(l)), no compression. Base64 is RFC 4648's standard alphabet with "=" padding.
--   Import(s)  either prefix (whitespace anywhere is dropped first), then Read, then Sanitize.
--   Sanitize   a layout checked and made whole: every field the format names, of its type, within its limits; what
--              is not the format's is left out. Nothing here touches the game: pure functions.
-- ============================================================

local C = {}
ns.LayoutCodec = C

C.VERSION = 1
C.PREFIX1, C.PREFIX0 = "HUI1!", "HUI0!"
C.MAX_SLOT = 180
C.NAME_LETTERS = 24
C.MACRO_LETTERS = 16                          -- the game's own (Blizzard_MacroUI: the name box takes 16)
C.MACRO_BODY = 255
C.QUESTION_MARK = 134400
C.MAX_DEPTH = 12
C.MAX_TEXT = 262144
-- the settings a layout may turn on (Engine.lua E.SETTINGS says how)
C.SETTINGS = { "autoLoot", "damageMeter" }   -- (Harry, Oct 19: only the two he asked for)
C.MAX_MOUNTS = 400                           -- a mount slot's list, each of spells and items

local byte, char, sub, format, floor = string.byte, string.char, string.sub, string.format, math.floor

local function Plain(v)
	if issecretvalue and issecretvalue(v) then return nil end
	return v
end

-- ------------------------------------------------------------
-- UTF-8: letters, not bytes (a name's limit is the game's letters)
-- ------------------------------------------------------------
function C.Letters(s)
	local n = 0
	for i = 1, #s do
		local b = byte(s, i)
		if b < 0x80 or b >= 0xC0 then n = n + 1 end
	end
	return n
end

function C.Truncate(s, letters)
	local n, i = 0, 1
	while i <= #s do
		local b = byte(s, i)
		if b < 0x80 or b >= 0xC0 then
			n = n + 1
			if n > letters then return sub(s, 1, i - 1) end
		end
		i = i + 1
	end
	return s
end

-- ------------------------------------------------------------
-- The writer
-- ------------------------------------------------------------
local KEYWORDS = {}
for w in string.gmatch("and break do else elseif end false for function goto if in local nil not or repeat return then "
	.. "true until while", "%a+") do KEYWORDS[w] = true end

local ESC = { ['"'] = '\\"', ["\\"] = "\\\\", ["\n"] = "\\n", ["\r"] = "\\r", ["\t"] = "\\t" }
local function Escape(c)
	return ESC[c] or format("\\%03d", byte(c))
end

local function Quote(s)
	return '"' .. string.gsub(s, '[%c"\\]', Escape) .. '"'
end

-- byte order, whatever the client's locale (Lua's own < on strings may follow it)
local function ByteLess(a, b)
	local la, lb = #a, #b
	for i = 1, math.min(la, lb) do
		local x, y = byte(a, i), byte(b, i)
		if x ~= y then return x < y end
	end
	return la < lb
end

local function IsInteger(v)
	return type(v) == "number" and v == v and v ~= math.huge and v ~= -math.huge and v == floor(v)
		and v >= -9007199254740991 and v <= 9007199254740991
end

local WriteValue
local function WriteTable(t, out, depth)
	if depth > C.MAX_DEPTH then error("too deep", 0) end
	out[#out + 1] = "{"
	local first = true
	local function Sep() if first then first = false else out[#out + 1] = "," end end
	local n = 0
	while t[n + 1] ~= nil do n = n + 1 end
	for i = 1, n do
		Sep()
		WriteValue(t[i], out, depth + 1)
	end
	local nums, strs = {}, {}
	for k, v in pairs(t) do
		if type(k) == "number" then
			if not (IsInteger(k) and k >= 1 and k <= n) then
				if not IsInteger(k) then error("a key that is not an integer", 0) end
				nums[#nums + 1] = k
			end
		elseif type(k) == "string" then
			strs[#strs + 1] = k
		else
			error("a key of type " .. type(k), 0)
		end
	end
	table.sort(nums)
	table.sort(strs, ByteLess)
	for _, k in ipairs(nums) do
		Sep()
		out[#out + 1] = format("[%d]=", k)
		WriteValue(t[k], out, depth + 1)
	end
	for _, k in ipairs(strs) do
		Sep()
		if string.find(k, "^[%a_][%w_]*$") and not KEYWORDS[k] then
			out[#out + 1] = k .. "="
		else
			out[#out + 1] = "[" .. Quote(k) .. "]="
		end
		WriteValue(t[k], out, depth + 1)
	end
	out[#out + 1] = "}"
end

WriteValue = function(v, out, depth)
	local kind = type(v)
	if kind == "string" then
		out[#out + 1] = Quote(v)
	elseif kind == "number" then
		if not IsInteger(v) then error("a number that is not an integer", 0) end
		-- (the game's Lua 5.1 formats %d through a 32-bit long on Windows: past it, %.0f writes the same digits)
		out[#out + 1] = (v > -2147483648 and v < 2147483648) and format("%d", v) or format("%.0f", v)
	elseif kind == "boolean" then
		out[#out + 1] = v and "true" or "false"
	elseif kind == "table" then
		WriteTable(v, out, depth)
	else
		error("a value of type " .. kind, 0)
	end
end

-- The text of a table, or nil and why.
function C.Write(t)
	if type(t) ~= "table" then return nil, "not a table" end
	local out = {}
	local ok, err = pcall(WriteTable, t, out, 1)
	if not ok then return nil, err end
	return table.concat(out)
end

-- ------------------------------------------------------------
-- The reader: Lua table text, nothing else (a table at the top, its values strings, numbers, booleans, tables)
-- ------------------------------------------------------------
local SIMPLE = { n = "\n", r = "\r", t = "\t", a = "\a", b = "\b", f = "\f", v = "\v", ["\\"] = "\\", ['"'] = '"',
	["'"] = "'", ["\n"] = "\n" }

local function Reader(s)
	local pos, len = 1, #s
	local R = {}
	local function Fail(why) error({ why = why .. " at " .. pos }, 0) end
	local function Skip()
		while pos <= len do
			local c = byte(s, pos)
			if c == 32 or (c >= 9 and c <= 13) then
				pos = pos + 1
			elseif c == 45 and byte(s, pos + 1) == 45 then        -- a "--" comment, to the line's end
				local e = string.find(s, "\n", pos, true)
				pos = e and e + 1 or len + 1
			else
				return
			end
		end
	end
	local function String()
		local q = sub(s, pos, pos)
		pos = pos + 1
		local parts = {}
		while true do
			if pos > len then Fail("an open string") end
			local c = sub(s, pos, pos)
			if c == q then pos = pos + 1; break end
			if c == "\n" then Fail("a line break in a string") end
			if c == "\\" then
				local e = sub(s, pos + 1, pos + 1)
				if SIMPLE[e] then
					parts[#parts + 1] = SIMPLE[e]
					pos = pos + 2
				elseif string.find(e, "^%d$") then
					local digits = string.match(s, "^%d%d?%d?", pos + 1)
					local code = tonumber(digits)
					if code > 255 then Fail("a byte over 255") end
					parts[#parts + 1] = char(code)
					pos = pos + 1 + #digits
				elseif e == "x" then
					local hex = string.match(s, "^%x%x", pos + 2)
					if not hex then Fail("a bad \\x") end
					parts[#parts + 1] = char(tonumber(hex, 16))
					pos = pos + 4
				else
					Fail("an unknown escape")
				end
			else
				local e = string.find(s, "[\\\n" .. (q == '"' and '"' or "'") .. "]", pos)
				if not e then Fail("an open string") end
				parts[#parts + 1] = sub(s, pos, e - 1)
				pos = e
			end
		end
		return table.concat(parts)
	end
	local function Number()
		local text = string.match(s, "^%-?0[xX]%x+", pos) or string.match(s, "^%-?%d+%.?%d*[eE][%+%-]?%d+", pos)
			or string.match(s, "^%-?%d+%.?%d*", pos) or string.match(s, "^%-?%.%d+", pos)
		if not text then Fail("a bad number") end
		pos = pos + #text
		local v = tonumber(text)
		if not v then Fail("a bad number") end
		return v
	end
	local Value
	local function Table(depth)
		if depth > C.MAX_DEPTH then Fail("too deep") end
		pos = pos + 1                                              -- the "{"
		local t, n = {}, 0
		while true do
			Skip()
			local c = sub(s, pos, pos)
			if c == "}" then pos = pos + 1; return t end
			if c == "" then Fail("an open table") end
			local key, value
			if c == "[" and sub(s, pos + 1, pos + 1) ~= "[" then
				pos = pos + 1
				Skip()
				key = Value(depth)
				Skip()
				if sub(s, pos, pos) ~= "]" then Fail("a missing ]") end
				pos = pos + 1
				Skip()
				if sub(s, pos, pos) ~= "=" then Fail("a missing =") end
				pos = pos + 1
				Skip()
				value = Value(depth)
				if key == nil or key ~= key then Fail("a bad key") end
			else
				local name = string.match(s, "^[%a_][%w_]*", pos)
				local after = name and string.match(s, "^%s*=", pos + #name)
				if name and after and not KEYWORDS[name] then
					key = name
					pos = pos + #name + #after
					Skip()
					value = Value(depth)
				else
					n = n + 1
					key = n
					value = Value(depth)
				end
			end
			if value ~= nil then t[key] = value end
			Skip()
			c = sub(s, pos, pos)
			if c == "," or c == ";" then
				pos = pos + 1
			elseif c ~= "}" then
				Fail("a missing ,")
			end
		end
	end
	Value = function(depth)
		Skip()
		local c = sub(s, pos, pos)
		if c == "{" then return Table(depth + 1) end
		if c == '"' or c == "'" then return String() end
		if string.find(c, "^[%d%-%.]$") then return Number() end
		if sub(s, pos, pos + 3) == "true" then pos = pos + 4; return true end
		if sub(s, pos, pos + 4) == "false" then pos = pos + 5; return false end
		if sub(s, pos, pos + 2) == "nil" then pos = pos + 3; return nil end
		Fail("a value expected")
	end
	function R.Top()
		Skip()
		-- the companion file's shape too: "return { ... }" or "NAME = { ... }"
		local lead = string.match(s, "^return%s+", pos) or string.match(s, "^[%a_][%w_]*%s*=%s*", pos)
		if lead then pos = pos + #lead end
		Skip()
		if sub(s, pos, pos) ~= "{" then Fail("no table") end
		local t = Table(0)
		Skip()
		if pos <= len then Fail("text after the table") end
		return t
	end
	return R
end

-- The table a text holds, or nil and why.
function C.Read(s)
	if type(s) ~= "string" then return nil, "not text" end
	if #s > C.MAX_TEXT then return nil, "too long" end
	local ok, t = pcall(Reader(s).Top)
	if not ok then
		return nil, type(t) == "table" and t.why or tostring(t)
	end
	return t
end

-- ------------------------------------------------------------
-- Base64 (RFC 4648, the standard alphabet, "=" padding): our own, for HUI0 and a client without C_EncodingUtil
-- ------------------------------------------------------------
local ALPHABET = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/"
local B64, B64INDEX = {}, {}
for i = 1, 64 do
	local c = sub(ALPHABET, i, i)
	B64[i - 1] = c
	B64INDEX[byte(c)] = i - 1
end

function C.Base64(s)
	local out = {}
	for i = 1, #s, 3 do
		local a, b, c = byte(s, i, i + 2)
		local n = a * 65536 + (b or 0) * 256 + (c or 0)
		local c1, c2 = floor(n / 262144) % 64, floor(n / 4096) % 64
		local c3, c4 = floor(n / 64) % 64, n % 64
		out[#out + 1] = B64[c1] .. B64[c2] .. (b and B64[c3] or "=") .. (c and B64[c4] or "=")
	end
	return table.concat(out)
end

function C.Unbase64(s)
	s = string.gsub(s, "%s", "")
	if #s % 4 ~= 0 then return nil end
	local out = {}
	for i = 1, #s, 4 do
		local n, pad = 0, 0
		for j = 0, 3 do
			local c = byte(s, i + j)
			local v = B64INDEX[c]
			if c == 61 then                                        -- "="
				if i + 4 <= #s or j < 2 then return nil end
				pad = pad + 1
				v = 0
			elseif v == nil or pad > 0 then
				return nil
			end
			n = n * 64 + v
		end
		local a, b, c = floor(n / 65536) % 256, floor(n / 256) % 256, n % 256
		if pad == 0 then out[#out + 1] = char(a, b, c)
		elseif pad == 1 then out[#out + 1] = char(a, b)
		else out[#out + 1] = char(a) end
	end
	return table.concat(out)
end

-- ------------------------------------------------------------
-- The game's encoder (C_EncodingUtil, 1.60.1): raw DEFLATE and base64
-- ------------------------------------------------------------
local function EnumValue(group, name, fallback)
	local e = Enum and Enum[group]
	local v = type(e) == "table" and e[name]
	if type(v) == "number" then return v end
	return fallback
end

local function Encoder()
	local E = C_EncodingUtil
	if type(E) ~= "table" then return nil end
	if type(E.CompressString) ~= "function" or type(E.DecompressString) ~= "function"
		or type(E.EncodeBase64) ~= "function" or type(E.DecodeBase64) ~= "function" then return nil end
	return E
end
C.Encoder = Encoder

-- The export string of a layout (already sanitized), or nil and why.
function C.Export(layout)
	local text, why = C.Write(layout)
	if not text then return nil, why end
	local E = Encoder()
	if E then
		local deflate, standard = EnumValue("CompressionMethod", "Deflate", 0), EnumValue("Base64Variant", "Standard", 0)
		local okC, packed = pcall(E.CompressString, text, deflate)
		packed = okC and Plain(packed)
		if type(packed) == "string" then
			local okB, out = pcall(E.EncodeBase64, packed, standard)
			out = okB and Plain(out)
			if type(out) == "string" then return C.PREFIX1 .. out end
		end
	end
	return C.PREFIX0 .. C.Base64(text)
end

-- The text an export string holds, or nil and why.
function C.Unpack(str)
	if type(str) ~= "string" then return nil, "not text" end
	str = string.gsub(str, "%s", "")
	if sub(str, 1, 5) == C.PREFIX0 then
		local text = C.Unbase64(sub(str, 6))
		if not text then return nil, "bad base64" end
		return text
	end
	if sub(str, 1, 5) ~= C.PREFIX1 then return nil, "not a HUI layout" end
	local E = Encoder()
	if not E then return nil, "this client cannot unpack it" end
	local standard = EnumValue("Base64Variant", "Standard", 0)
	local okB, packed = pcall(E.DecodeBase64, sub(str, 6), standard)
	packed = okB and Plain(packed)
	if type(packed) ~= "string" or packed == "" then return nil, "bad base64" end
	-- raw DEFLATE (the format's); a zlib-wrapped stream read too, in case a writer wrapped it
	for _, method in ipairs({ EnumValue("CompressionMethod", "Deflate", 0), EnumValue("CompressionMethod", "Zlib", 1) }) do
		local okD, text = pcall(E.DecompressString, packed, method)
		text = okD and Plain(text)
		if type(text) == "string" and text ~= "" then return text end
	end
	return nil, "could not unpack"
end

-- A layout from an export string, or nil and why.
function C.Import(str)
	local text, why = C.Unpack(str)
	if not text then return nil, why end
	local t, err = C.Read(text)
	if not t then return nil, err end
	return C.Sanitize(t)
end

-- ------------------------------------------------------------
-- Sanitize: the format's fields only, each checked (LAYOUT-FORMAT.md)
-- ------------------------------------------------------------
-- The binding commands a layout may set: the ones HUI Bars routes (its eight bars, the stance, pet and extra buttons).
function C.IsCommand(cmd)
	if type(cmd) ~= "string" then return false end
	local n = tonumber(string.match(cmd, "^ACTIONBUTTON(%d+)$"))
	if n then return n >= 1 and n <= 12 end
	local bar, i = string.match(cmd, "^MULTIACTIONBAR(%d)BUTTON(%d+)$")
	if bar then
		bar, i = tonumber(bar), tonumber(i)
		return bar >= 1 and bar <= 7 and i >= 1 and i <= 12
	end
	n = tonumber(string.match(cmd, "^SHAPESHIFTBUTTON(%d+)$") or string.match(cmd, "^BONUSACTIONBUTTON(%d+)$"))
	if n then return n >= 1 and n <= 10 end
	return cmd == "EXTRAACTIONBUTTON1"
end

-- A key as the game writes it: "1", "SHIFT-1", "CTRL-Q", "BUTTON4", "MOUSEWHEELUP", "=", "["
local function IsKey(k)
	return type(k) == "string" and #k >= 1 and #k <= 40 and not string.find(k, "[%c%s]")
end

local function PosInt(v, max)
	return IsInteger(v) and v >= 1 and (not max or v <= max)
end

local function Trim(s)
	return (string.gsub(string.gsub(s, "^%s+", ""), "%s+$", ""))
end

local function CleanMacro(m, seen)
	if type(m) ~= "table" then return nil end
	local key, name, body = Plain(m.key), Plain(m.name), Plain(m.body)
	if type(key) ~= "string" or not string.find(key, "^[%w_]+$") or #key > 16 or seen[key] then return nil end
	if type(name) ~= "string" then return nil end
	-- (0.15.1) a macro may have no name: the editor and the macro window never fill one in (Harry, Oct 18: "i often
	-- leave my macros with no name")
	name = C.Truncate(Trim(name), C.MACRO_LETTERS)
	if type(body) ~= "string" then body = "" end
	if #body > C.MACRO_BODY then body = sub(body, 1, C.MACRO_BODY) end
	local icon = Plain(m.icon)
	if not PosInt(icon) then icon = C.QUESTION_MARK end
	local scope = m.scope == "character" and "character" or "account"
	seen[key] = true
	return { key = key, name = name, icon = icon, body = body, scope = scope }
end

local function CleanSlot(e, macroKeys)
	if type(e) ~= "table" then return nil end
	local kind = e[1]
	if kind == "spell" then
		if not PosInt(e[2]) then return nil end
		local out = { "spell", e[2] }
		if type(e.name) == "string" and e.name ~= "" then out.name = sub(e.name, 1, 64) end
		if PosInt(e.rank, 99) then out.rank = e.rank end
		if type(e.auto) == "boolean" then out.auto = e.auto end
		return out
	elseif kind == "macro" then
		if type(e[2]) ~= "string" or not macroKeys[e[2]] then return nil end
		return { "macro", e[2] }
	elseif kind == "item" then
		if not PosInt(e[2]) then return nil end
		return { "item", e[2] }
	elseif kind == "empty" then
		return { "empty" }
	elseif kind == "slot" then
		-- (LAYOUT-FORMAT.md "Utility buttons") the item equipped in an inventory slot (1-19)
		if not PosInt(e[2], 19) then return nil end
		return { "slot", e[2] }
	elseif kind == "family" then
		-- the best item of a family the character carries, best-first
		if type(e[2]) ~= "string" or not string.find(e[2], "^[%w_]+$") or #e[2] > 32 then return nil end
		local out = { "family", e[2] }
		local keep = {}
		if type(e.items) == "table" then
			for i = 1, C.MAX_MOUNTS do
				local v = e.items[i]
				if v == nil then break end
				if PosInt(v) then keep[#keep + 1] = v end
			end
		end
		if #keep == 0 then return nil end
		out.items = keep
		return out
	elseif kind == "mount" then
		-- (LAYOUT-FORMAT.md "Utility buttons") Mount up: the mounts best-first (the editor writes every mount of
		-- the game's table, fastest first); the first one the character owns goes in
		local out = { "mount" }
		for _, field in ipairs({ "spells", "items" }) do
			local list = e[field]
			if type(list) == "table" then
				local keep = {}
				for i = 1, C.MAX_MOUNTS do
					local v = list[i]
					if v == nil then break end
					if PosInt(v) then keep[#keep + 1] = v end
				end
				if #keep > 0 then out[field] = keep end
			end
		end
		return out
	end
	return nil
end

local function CleanSpec(s, macroKeys)
	local out = { slots = {}, keys = {} }
	if type(s) ~= "table" then return out end
	if type(s.slots) == "table" then
		for slot, e in pairs(s.slots) do
			if PosInt(slot, C.MAX_SLOT) then out.slots[slot] = CleanSlot(e, macroKeys) end
		end
	end
	if type(s.keys) == "table" then
		for cmd, list in pairs(s.keys) do
			if C.IsCommand(cmd) and type(list) == "table" then   -- (a game command's keys, 0.6.9's Game keys: dropped)
				local keys = {}
				for i = 1, 4 do
					if IsKey(list[i]) then keys[#keys + 1] = list[i] end
				end
				out.keys[cmd] = keys
			end
		end
	end
	return out
end

-- ------------------------------------------------------------
-- (LAYOUT-FORMAT.md "Bars") the bars: HUI Bars' own per-bar settings (Core.lua ns.BAR_FIELDS, their limits and words -
-- written here again so the codec stands alone; the mock checks the two agree) and its `bars` group
-- ------------------------------------------------------------
local BOOL, NUM, CHOICE = 1, 2, 3
C.BAR_RULES = {
	{ "enabled", BOOL }, { "cols", CHOICE, { 12, 6, 4, 3, 2, 1 } }, { "size", NUM, 12, 64 }, { "across", NUM, 0, 24 },
	{ "down", NUM, 0, 24 }, { "downOwn", BOOL }, { "scale", NUM, 50, 200 }, { "anchor", CHOICE, { "BOTTOM", "RIGHT" } },
	{ "x", NUM, -5000, 5000 }, { "y", NUM, -5000, 5000 }, { "vis", CHOICE, { "always", "combat", "mouseover", "hidden" } },
	{ "fade", NUM, 0, 100 }, { "joinTo", NUM, 0, 8 }, { "joinSide", CHOICE, { "above", "below", "left", "right" } },
	{ "joinAlign", CHOICE, { "left", "center", "right", "top", "middle", "bottom" } },
}
C.GROUP_RULES = {
	{ "template", CHOICE, { "stack", "twohalf", "wings", "split", "classic", "levelling" } }, { "size", NUM, 28, 56 },
	{ "gap", NUM, 0, 12 }, { "showEmpty", BOOL },
}
C.NUM_BARS = 8

local function CleanField(rule, v)
	local kind = rule[2]
	if kind == BOOL then
		if type(v) == "boolean" then return v end
	elseif kind == NUM then
		if type(v) == "number" and v == v and v ~= math.huge and v ~= -math.huge then
			v = floor(v + 0.5)                                     -- whole UI units (a drag may leave a fraction)
			if v < rule[3] then v = rule[3] elseif v > rule[4] then v = rule[4] end
			return v
		end
	else
		for _, c in ipairs(rule[3]) do if v == c then return v end end
	end
	return nil
end

function C.CleanBars(b)
	local out = {}
	for _, rule in ipairs(C.GROUP_RULES) do out[rule[1]] = CleanField(rule, b[rule[1]]) end
	for n = 1, C.NUM_BARS do
		local bar = b[n]
		if type(bar) == "table" then
			local o = {}
			for _, rule in ipairs(C.BAR_RULES) do o[rule[1]] = CleanField(rule, bar[rule[1]]) end
			if o.joinTo == n then o.joinTo = 0 end
			if next(o) then out[n] = o end
		end
	end
	return out
end

-- A whole layout, or nil and why.
function C.Sanitize(t)
	if type(t) ~= "table" then return nil, "not a layout" end
	local v = t.v
	if not PosInt(v) then return nil, "not a layout" end
	if v > C.VERSION then return nil, "made by a newer HUI" end
	local name = type(t.name) == "string" and C.Truncate(Trim(t.name), C.NAME_LETTERS) or ""
	if name == "" then return nil, "no name" end
	if type(t.class) ~= "string" or not string.find(t.class, "^%u+$") then return nil, "no class" end
	local out = {
		v = C.VERSION,
		name = name,
		class = t.class,
		firstLogin = t.firstLogin == true,
		autoRankDefault = t.autoRankDefault ~= false,
		macros = {},
		specs = {},
	}
	-- (Harry, Oct 19: "automatically turn on auto loot if disabled, automatically turn on dps meter if
	-- disabled, etc") the game settings the layout turns ON (a key absent: left alone; nothing is ever turned off)
	if type(t.settings) == "table" then
		local set = {}
		for _, key in ipairs(C.SETTINGS) do
			if t.settings[key] == true then set[key] = true end
		end
		if next(set) then out.settings = set end
	end
	-- the race it was planned for (the ChrRaces file string, "Human", "Scourge"): HUI Presets prefers it
	if type(t.race) == "string" and string.find(t.race, "^%a+$") and #t.race <= 32 then out.race = t.race end
	-- (the format's "Ranks and levels": a layout is planned at level 60 - no level kept; an older one's is dropped)
	if type(t.bars) == "table" then out.bars = C.CleanBars(t.bars) end
	if type(t.options) == "table" then
		out.options = { prowlBar = t.options.prowlBar == true, moonkinBar = t.options.moonkinBar == true }
	end
	local seen = {}
	if type(t.macros) == "table" then
		for i = 1, 150 do
			local m = t.macros[i]
			if m == nil then break end
			out.macros[#out.macros + 1] = CleanMacro(m, seen)
		end
	end
	local specs = type(t.specs) == "table" and t.specs or {}
	out.specs[1] = CleanSpec(specs[1], seen)
	if type(specs[2]) == "table" then out.specs[2] = CleanSpec(specs[2], seen) end
	return out
end

-- A deep copy (the saved list never shares a table with a layout being applied or shown).
function C.Copy(t)
	if type(t) ~= "table" then return t end
	local out = {}
	for k, v in pairs(t) do out[k] = C.Copy(v) end
	return out
end

-- Two tables the same, deeply (the tests and the "already saved" check).
function C.Same(a, b)
	if type(a) ~= type(b) then return false end
	if type(a) ~= "table" then return a == b end
	for k, v in pairs(a) do if not C.Same(v, b[k]) then return false end end
	for k in pairs(b) do if a[k] == nil then return false end end
	return true
end
