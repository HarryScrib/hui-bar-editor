local ADDON, ns = ...

-- ============================================================
-- (HUI Presets 0.1.0; Harry, Oct 19: "everything needs to work if we assume no addons are in play, or elvui, or hui, or
-- dominos, or bartender. they all need to work") THE LAYOUT ENGINE: a layout (dev/docs/actionbars/LAYOUT-FORMAT.md v1)
-- put on the character - its macros, its action slots, its keys and its settings. COPIED from HUI Bars' Layouts.lua
-- (0.15.0 - 0.16.1: macros, slots, Auto rank, the remembered spells; HUI Bars' own copy unchanged) and grown here. It
-- needs nothing of its host but ns.LayoutCodec (Codec.lua, loaded before it); it publishes ns.LayoutEngine and keeps no
-- state of its own except what the host hands it.
--
--   THE STORE   the host's per-character table (HUI Bars: its character record; HUI Presets: its own saved table):
--               layoutPins[slot] (true pinned, false Auto rank, nil the layout-wide autoRankDefault), layoutWaiting[slot]
--               (a spell not known yet, placed when learnt), layoutMounts[slot] (a Mount up slot, kept to its best
--               owned mount), layoutPinsSeeded, autoRankDefault, keysTaken (0.1.6: every key an import bound and what it
--               did before, given back when no layout uses it - "THE PLAYER'S OWN KEYS" below), layoutPushed (0.1.5: a
--               spell the game pushed onto a slot against the layout, to take off - "THE GAME'S OWN PUSH" below).
--               E.Store(t) makes the tables.
--   E.Apply     out of a fight only (the host queues it): macros first (made once, "<name> 2" on a clash, nameless ones
--               found by their text), then the slots (PickupSpell / PickupItem / PickupMacro + PlaceAction; Auto rank at
--               the highest rank known, a pinned one at exactly its rank; Mount up the first mount of its list owned),
--               then the keys (below), saved the way the game saves them (SaveBindings with the current set, or the
--               host's own save). Returns the counts. (0.1.8) The macros it made are its own (store.macrosMade): a
--               preset's macro whose text changed is edited in place, one the preset dropped deleted (character) or let go
--               (account) - "THE MACROS IT MADE" below; E.TidyList / E.Tidy the duplicates made before that.
--   E.Recheck   after SPELLS_CHANGED / LEARNED_SPELL_IN_SKILL_LINE / NEW_MOUNT_ADDED / BAG_UPDATE_DELAYED /
--               SPELL_PUSHED_TO_ACTIONBAR, out of a fight: the game's pushes against the layout taken off (0.1.5), the
--               waiting spells placed, the mount slots' best owned mount, then Auto rank.
--   E.Pending   how many slots of a layout do not hold what they should yet ("All placed" at none).
--   E.Trainable (0.1.2) of those, the spells to buy at the trainer now ("Train N"; none: "Up to date").
--   E.Capture   (0.1.2, COPIED from HUI Bars' Layouts.lua L.Capture) the character's own bars as a layout: every slot,
--               the macros they use, the keys read back from the buttons that show each slot (Export).
--
-- THE KEYS ON ANY BAR ADDON. A layout's keys are written under the game's own commands (ACTIONBUTTONi = bar 1's
-- button i, its form pages too; MULTIACTIONBARnBUTTONi = the multi bar on page 6, 5, 3, 4, 13, 14, 15). At apply time
-- each command's action slot is worked out (bar 1: the page it shows now) and the key goes to the button that SHOWS
-- that slot on the screen now, through that button's own binding command:
--   * HUI Bars (the host says so, or it is loaded): its buttons answer the game's commands (its Bindings.lua routes
--     them), so the commands are kept exactly as written.
--   * the game's own bars, Bartender4, ElvUI, Dominos, any other: every visible action button is asked which slot it
--     shows now (LibActionButton's _state_action, the "action" attribute, the game's .action) and which binding it
--     answers (Dominos' commandName attribute; LibActionButton's keyBoundTarget, else "CLICK <name>:<its click
--     button>"; .GetBindingAction; the game's .commandName; else "CLICK <name>:LeftButton"). Bartender4's bars on pages
--     1, 3, 4, 5, 6, 13-15 and ElvUI's bars 1, 3-6, 13-15 answer the game's commands themselves; their other bars and
--     Dominos' own buttons take CLICK bindings.
--   * a button its addon keeps hidden for now (a bar shown only in a fight) still counts when that addon says the bar is
--     on (Bartender4's bar not disabled, ElvUI's bar enabled, Dominos' frame not hidden).
--   * no button shows that slot: with the game's own bars the command is still bound (the bar takes it when it is
--     turned on); with a bar addon the key is left alone. Either way it is counted: "3 keys on hidden bars".
-- Only the keys the layout names change, and keys an earlier import made that it no longer uses go back to what they did
-- before (0.1.6); a key the player bound himself is never unbound, every other binding is left as it is.
-- Nothing here is protected in a fight; every secret value is dropped before it is compared or used as a key.
-- ============================================================

local E = {}
ns.LayoutEngine = E
local Codec = ns.LayoutCodec

E.MAX_ACCOUNT, E.MAX_CHARACTER = 120, 30
do
	local k = Constants and Constants.MacroConsts
	if type(k) == "table" then
		E.MAX_ACCOUNT = type(k.MAX_ACCOUNT_MACROS) == "number" and k.MAX_ACCOUNT_MACROS or E.MAX_ACCOUNT
		E.MAX_CHARACTER = type(k.MAX_CHARACTER_MACROS) == "number" and k.MAX_CHARACTER_MACROS or E.MAX_CHARACTER
	end
end

local function Plain(v)
	if issecretvalue and issecretvalue(v) then return nil end
	return v
end
E.Plain = Plain

local function Call(fn, ...)
	if type(fn) ~= "function" then return nil end
	local ok, a, b, c, d, e, f, g, h, i, j, k, l = pcall(fn, ...)
	if not ok then return nil end
	return a, b, c, d, e, f, g, h, i, j, k, l
end
E.Call = Call

function E.MyClass()
	local _, class = Call(UnitClass, "player")
	class = Plain(class)
	return type(class) == "string" and class or nil
end

function E.MyRace()
	local _, race = Call(UnitRace, "player")
	race = Plain(race)
	return type(race) == "string" and race or nil
end

function E.Store(t)
	if type(t) ~= "table" then t = {} end
	if type(t.layoutPins) ~= "table" then t.layoutPins = {} end
	if type(t.layoutWaiting) ~= "table" then t.layoutWaiting = {} end
	if type(t.layoutMounts) ~= "table" then t.layoutMounts = {} end
	if type(t.keysTaken) ~= "table" then t.keysTaken = {} end   -- (0.1.6) key -> { cmd = before, to = made }
	if type(t.layoutPushed) ~= "table" then t.layoutPushed = {} end   -- (0.1.5) slot -> { id, at }: the game's push
	-- (0.1.8) the macros an apply made: key -> { scope, name, body, icon, preset } ("THE MACROS IT MADE" below), and the
	-- account ones a later preset dropped (kept, never deleted)
	if type(t.macrosMade) ~= "table" then t.macrosMade = {} end
	if type(t.macrosDropped) ~= "table" then t.macrosDropped = {} end
	return t
end

-- ============================================================
-- The game's answers, each guarded (a client without one simply has nothing there)
-- ============================================================
-- (kind, id, subtype: a macro showing a spell is "macro", that SPELL's ID, "spell" on the retail client)
function E.ActionInfo(slot)
	local kind, id, sub = Call(GetActionInfo, slot)
	return Plain(kind), Plain(id), Plain(sub)
end

function E.HasActionAt(slot)
	local has = C_ActionBar and C_ActionBar.HasAction and Call(C_ActionBar.HasAction, slot)
	if has == nil then has = Call(HasAction, slot) end
	return Plain(has) and true or false
end

function E.SpellName(id)
	if type(id) ~= "number" then return nil end
	local name = C_Spell and Call(C_Spell.GetSpellName, id)
	name = Plain(name)
	return type(name) == "string" and name ~= "" and name or nil
end

local RANK_PATTERNS = { "^Rank (%d+)$" }
if type(_G.RANK) == "string" and _G.RANK ~= "Rank" then RANK_PATTERNS[2] = "^" .. _G.RANK .. " (%d+)$" end

local function RankIn(text)
	text = Plain(text)
	if type(text) ~= "string" then return nil end
	for _, p in ipairs(RANK_PATTERNS) do
		local n = tonumber(string.match(text, p))
		if n then return n end
	end
	return nil
end

-- A spell's rank ("Rank 3" -> 3), nil for a spell with no rank
function E.RankOf(id)
	if type(id) ~= "number" then return nil end
	return RankIn(C_Spell and Call(C_Spell.GetSpellSubtext, id))
end

-- A mount's journal ID for its spell (nil: not a mount, or a client without the journal).
local function MountOf(spell)
	local J = C_MountJournal
	if type(J) ~= "table" or type(spell) ~= "number" then return nil end
	local id = Plain(Call(J.GetMountFromSpell, spell))
	return type(id) == "number" and id or nil
end
E.MountOf = MountOf

-- A collected mount (the journal's isCollected: the spellbook may not know a mount's spell on this client).
local function MountCollected(spell)
	local mount = MountOf(spell)
	if not mount then return false end
	local collected = select(11, Call(C_MountJournal.GetMountInfoByID, mount))
	return Plain(collected) == true
end

function E.Known(id)
	if type(id) ~= "number" then return false end
	local k = C_SpellBook and Call(C_SpellBook.IsSpellKnown, id)
	if Plain(k) == true then return true end
	k = Call(IsPlayerSpell, id)
	if Plain(k) == true then return true end
	k = Call(IsSpellKnown, id)
	if Plain(k) == true then return true end
	return MountCollected(id)
end

-- ------------------------------------------------------------
-- The spellbook by name: each spell's highest rank known (a spell with no rank: rank 0). Made again after
-- SPELLS_CHANGED / LEARNED_SPELL_IN_SKILL_LINE (E.ForgetBook).
-- ------------------------------------------------------------
local book
local function EnumValue(group, name, fallback)
	local e = Enum and Enum[group]
	local v = type(e) == "table" and e[name]
	if v ~= nil then return v end
	return fallback
end

function E.Book()
	if book then return book end
	book = {}
	local B = C_SpellBook
	if type(B) ~= "table" or type(B.GetNumSpellBookSkillLines) ~= "function" then return book end
	local bank = EnumValue("SpellBookSpellBank", "Player", 0)
	local spellType = EnumValue("SpellBookItemType", "Spell", nil)
	local lines = Plain(Call(B.GetNumSpellBookSkillLines)) or 0
	-- the spellbook's skill lines, then (on this client) the professions' own spells at GetProfessionInfo's offsets
	local ranges = {}
	for line = 1, lines do
		local li = Call(B.GetSpellBookSkillLineInfo, line)
		ranges[#ranges + 1] = { type(li) == "table" and Plain(li.itemIndexOffset) or nil,
			type(li) == "table" and Plain(li.numSpellBookItems) or nil }
	end
	for _, index in ipairs({ Call(GetProfessions) }) do
		index = Plain(index)
		if type(index) == "number" then
			local _, _, _, _, count, offset = Call(GetProfessionInfo, index)
			ranges[#ranges + 1] = { Plain(offset), Plain(count) }
		end
	end
	for _, range in ipairs(ranges) do
		local offset, count = range[1], range[2]
		if type(offset) == "number" and type(count) == "number" then
			for i = offset + 1, offset + count do
				local info = Call(B.GetSpellBookItemInfo, i, bank)
				if type(info) == "table" then
					local id, kind = Plain(info.spellID), Plain(info.itemType)
					if type(id) == "number" and (spellType == nil or kind == spellType) then
						local name = Plain(info.name)
						if type(name) ~= "string" or name == "" then name = E.SpellName(id) end
						local rank = RankIn(info.subName) or E.RankOf(id) or 0
						if name then
							local best = book[name]
							-- (a rank's text not loaded yet reads 0: then the higher ID, a later rank as a rule)
							if not best or rank > best.rank or (rank == best.rank and id > best.id) then
								book[name] = { id = id, rank = rank }
							end
						end
					end
				end
			end
		end
	end
	return book
end
function E.ForgetBook() book = nil end

-- The best known spell of a name: the spellbook's, else the game's own answer for the name.
local function BestOf(name)
	if not name then return nil end
	local best = E.Book()[name]
	if best and E.Known(best.id) then return best.id, best.rank end
	local info = C_Spell and Call(C_Spell.GetSpellInfo, name)
	local id = type(info) == "table" and Plain(info.spellID) or nil
	if E.Known(id) then return id, E.RankOf(id) or 0 end
	return nil
end

-- The spell to put in for a layout's spell entry, or nil (not known yet).
function E.SpellFor(want)
	local id = want[2]
	if want.auto == false then return E.Known(id) and id or nil end
	local name = want.name or E.SpellName(id)
	local best = BestOf(name)
	if best then return best end
	if E.Known(id) then return id end
	return nil
end

function E.IsPinned(store, slot)
	local p = store.layoutPins[slot]
	if p == nil then return store.autoRankDefault == false end
	return p == true
end

-- Every macro index named exactly `name` (account set, then character set).
function E.MacrosNamed(name)
	local out = {}
	local acc, chr = Call(GetNumMacros)
	acc, chr = Plain(acc) or 0, Plain(chr) or 0
	local function Look(i)
		local n = Plain(Call(GetMacroInfo, i))
		if n == name then out[#out + 1] = i end
	end
	for i = 1, acc do Look(i) end
	for i = E.MAX_ACCOUNT + 1, E.MAX_ACCOUNT + chr do Look(i) end
	return out
end

-- The macro in a slot: its index, and true when that is only a guess. The game's answer is the macro's index on older
-- clients, the spell it shows (subtype "spell") on the retail one - then the macro is found by the slot's own macro name.
-- (0.1.7) Several macros may share that name - every nameless one is " " (Harry, Oct 18: "i often leave my macros with
-- no name"): then the one whose spell (GetMacroSpell) is the slot's; still several or none: the first, a guess. A guess is
-- never taken for "already there" (E.PlaceSlots places the macro again) nor for "the old preset's" (E.Leftovers).
function E.MacroInSlot(slot, id, sub)
	local text = Plain(C_ActionBar and C_ActionBar.GetActionText and Call(C_ActionBar.GetActionText, slot))
	local byIndex = type(id) == "number" and sub ~= "spell" and Plain(Call(GetMacroInfo, id)) or nil
	if type(text) ~= "string" or text == "" then
		if type(byIndex) == "string" then return id, #E.MacrosNamed(byIndex) > 1 end
		return nil
	end
	local list = E.MacrosNamed(text)
	if #list == 0 then
		local index = Plain(Call(GetMacroIndexByName, text))
		if type(index) == "number" and index > 0 then return index end
		return nil
	end
	if #list == 1 then return list[1], false end
	if byIndex == text then return id, false end           -- (the index answer, its name agreeing)
	if type(id) == "number" then
		local hit
		for _, i in ipairs(list) do
			if Plain(Call(GetMacroSpell, i)) == id then
				if hit then hit = false break end
				hit = i
			end
		end
		if hit then return hit, false end
	end
	return list[1], true
end

-- ============================================================
-- Macros (LAYOUT-FORMAT.md "Macros")
-- ============================================================
local function Body(b)
	b = type(b) == "string" and b or ""
	b = string.gsub(b, "\r", "")
	return (string.gsub(b, "%s+$", ""))
end

local function Counts()
	local a, c = Call(GetNumMacros)
	return Plain(a) or 0, Plain(c) or 0
end

local function Trim(s) return (string.match(type(s) == "string" and s or "", "^%s*(.-)%s*$")) end

-- The macro of that name in a set: (any index with the name, the index whose text is the same). (0.1.8) except: an index
-- passed over (the macro about to be edited).
function E.FindMacro(scope, name, body, except)
	local acc, chr = Counts()
	local first, last = 1, acc
	if scope == "character" then first, last = E.MAX_ACCOUNT + 1, E.MAX_ACCOUNT + chr end
	local any, same
	body = Body(body)
	for i = first, last do
		local n, _, b
		if i ~= except then n, _, b = Call(GetMacroInfo, i) end
		n, b = Plain(n), Plain(b)
		if type(n) == "string" and (string.match(n, "^%s*(.-)%s*$")) == (string.match(name or "", "^%s*(.-)%s*$")) then   -- " " = nameless
			any = any or i
			if Body(b) == body then same = i; break end
		end
	end
	return any, same
end

-- ============================================================
-- (0.1.8; Harry, Oct 20: "the website committed extra macros because i deleted some, but it kept them in the lua")
-- THE MACROS IT MADE. A macro is found by its name and text, so a preset whose macro text changed on the website (the
-- #showtooltip naming its spell; every nameless one is " ") made a NEW macro beside the old one, and a macro dropped on
-- the website stayed in the game: the character set filled up with twins (30/30). Now:
--   * every macro an apply MAKES is recorded (store.macrosMade[key] = { scope, name, body, icon, preset }): the layout's
--     key (m1, m2 ... slot13), as made. A macro found already there (the player's own, or one made before 0.1.8) is
--     never recorded - except, once (store.macrosSeeded), the macros of the preset applied before 0.1.8 (opts.previous),
--     found exactly as that preset has them: those an older version made.
--   * a key whose recorded macro is still exactly as made (its name and text in its set) and whose text changed:
--     EditMacro in place (new name, icon and text, the same macro - its buttons keep it). Changed by the player since: his,
--     forgotten; a new one made as before. The new text already in the set (an older twin): that one used, ours goes.
--   * a recorded macro whose key the preset no longer has (or one of another preset), still exactly as made: a
--     character one taken off the bars and deleted; an account one never deleted (another character's preset may use
--     it: this one cannot see) - kept, no longer placed, recorded in store.macrosDropped (taken back if a preset names
--     it again).
-- Every macro is found again by name and text before each change (EditMacro re-sorts, DeleteMacro moves the rest up).
-- Out of a fight only, as all of E.Apply (the host queues it).
-- ============================================================
local function SameText(r, name, body)
	return Trim(r.name) == Trim(name) and Body(r.body) == Body(body)
end

-- The name a layout's macro takes in its set ("<name> 2" on a clash) and the index already holding that exact text:
-- (name, same), (name, nil) to make it, or nil (no free name).
local function NameFor(scope, m, except)
	for n = 1, 9 do
		local name = m.name or ""
		if n > 1 then
			local tail = " " .. n
			name = Codec.Truncate(name, Codec.MACRO_LETTERS - #tail) .. tail
		end
		local any, same = E.FindMacro(scope, name, m.body, except)
		if same then return name, same end
		if not any or name == "" then return name, nil end   -- a nameless one is never renamed: made beside the others
	end
	return nil
end

-- A recorded macro's index, still exactly as made, or nil.
function E.MadeIndex(r)
	if type(r) ~= "table" then return nil end
	local _, same = E.FindMacro(r.scope == "character" and "character" or "account", r.name, r.body)
	return same
end

-- A macro deleted: true when the set is one smaller after it.
function E.DeleteMacro(index)
	local acc, chr = Counts()
	Call(DeleteMacro, index)
	local acc2, chr2 = Counts()
	return acc2 + chr2 < acc + chr
end

-- Every action slot certainly holding that macro, emptied. Returns how many.
function E.TakeOffBars(index)
	local n = 0
	Call(ClearCursor)
	for slot = 1, Codec.MAX_SLOT do
		local kind, id, sub = E.ActionInfo(slot)
		if kind == "macro" then
			local at, guess = E.MacroInSlot(slot, id, sub)
			if at == index and not guess then
				Call(PickupAction, slot)
				Call(ClearCursor)
				n = n + 1
			end
		end
	end
	return n
end

-- (once) the macros of the preset applied before records were kept, found exactly as it has them, taken for its own.
function E.SeedMacros(store, previous)
	local made = store.macrosMade
	if type(previous) ~= "table" or next(made) ~= nil then return 0 end
	previous = E.SlotMacros(previous)
	local n = 0
	for _, m in ipairs(previous.macros or {}) do
		local scope = m.scope == "character" and "character" or "account"
		local name, same = NameFor(scope, m)
		if same and type(m.key) == "string" and not made[m.key] then
			made[m.key] = { scope = scope, name = name, body = m.body, icon = m.icon, preset = previous.name }
			n = n + 1
		end
	end
	return n
end

-- (0.1.9; Harry, Oct 20: "C2 on website = Divine Grace. C1 in game = Divine Grace") A full set (30/30, the older texts
-- of the same buttons made before records were kept) left a macro that "did not fit" unmade and its slot untouched - the
-- old macro stayed on it. With no room, an OLDER VERSION of the macro is edited in place instead: the same set, the
-- same name, the same spell after /cast (E.CastOf), its text no macro of this layout's and no recorded one's. With
-- room, a new one is made as before (a player's own macro is never rewritten while it need not be).
local function OlderVersion(scope, name, m, taken)
	local spell = E.CastOf(m.body)
	if not spell then return nil end
	local acc, chr = Counts()
	local first, last = 1, acc
	if scope == "character" then first, last = E.MAX_ACCOUNT + 1, E.MAX_ACCOUNT + chr end
	for i = first, last do
		local n, _, b = Call(GetMacroInfo, i)
		n, b = Plain(n), Plain(b)
		if type(n) == "string" and Trim(n) == Trim(name) and type(b) == "string" and not taken[scope .. "\n" .. Body(b)]
			and E.CastOf(b) == spell then
			return i
		end
	end
	return nil
end

-- Every macro of a layout made, edited or found: [key] = { scope, name, body }, and the counts (made, there, noRoom,
-- updated, removed). store: the character's (its macrosMade / macrosDropped); nil: nothing recorded (as before 0.1.8).
function E.Macros(layout, store)
	local map, made, there, noRoom, updated, removed = {}, 0, 0, 0, 0, 0
	local rec, dropped = {}, {}
	if type(store) == "table" then
		E.Store(store)
		rec, dropped = store.macrosMade, store.macrosDropped
	end
	local preset = layout.name
	local keep, gone = {}, {}
	local function Record(key, scope, name, m)
		rec[key] = { scope = scope, name = name, body = m.body, icon = m.icon, preset = preset }
	end
	-- (0.1.9) the texts never taken as an older version: this layout's own, and every recorded one
	local taken = {}
	for _, m in ipairs(layout.macros or {}) do
		taken[(m.scope == "character" and "character" or "account") .. "\n" .. Body(m.body)] = true
	end
	for _, r in pairs(rec) do
		if type(r) == "table" then taken[(r.scope == "character" and "character" or "account") .. "\n" .. Body(r.body)] = true end
	end
	for _, m in ipairs(layout.macros or {}) do
		local scope = m.scope == "character" and "character" or "account"
		keep[m.key] = true
		local r = rec[m.key]
		if type(r) ~= "table" then r = nil end
		if r and (r.scope ~= scope or r.preset ~= preset) then   -- another preset's key of that name: not this macro
			gone[#gone + 1] = r
			rec[m.key], r = nil, nil
		end
		local mine = r and E.MadeIndex(r) or nil
		if r and not mine then rec[m.key], r = nil, nil end       -- changed (or deleted) by the player since: his
		if mine and SameText(r, m.name, m.body) then
			there = there + 1
			map[m.key] = { scope = scope, name = r.name, body = r.body }
		elseif mine then
			local name, same = NameFor(scope, m, mine)
			if same then
				-- the new text already in the set (a twin made before records were kept): that one, and ours goes
				there = there + 1
				map[m.key] = { scope = scope, name = name, body = m.body }
				gone[#gone + 1] = r
				rec[m.key] = nil
			elseif name then
				local index = Plain(Call(EditMacro, mine, name ~= "" and name or " ", m.icon or Codec.QUESTION_MARK, m.body))
				if type(index) == "number" and index > 0 then
					updated = updated + 1
					Record(m.key, scope, name, m)
					map[m.key] = { scope = scope, name = name, body = m.body }
				else
					noRoom = noRoom + 1
				end
			else
				noRoom = noRoom + 1
			end
		else
			local name, same = NameFor(scope, m)
			if same then
				there = there + 1
				map[m.key] = { scope = scope, name = name, body = m.body }
				-- an account macro a preset dropped, named again: its own once more
				for i = #dropped, 1, -1 do
					local d = dropped[i]
					if type(d) == "table" and d.scope == scope and SameText(d, name, m.body) then
						table.remove(dropped, i)
						if not rec[m.key] then Record(m.key, scope, name, m) end
						break
					end
				end
			elseif name then
				local acc, chr = Counts()
				local room = scope == "character" and (E.MAX_CHARACTER - chr) or (E.MAX_ACCOUNT - acc)
				local older = room <= 0 and OlderVersion(scope, name, m, taken) or nil
				if older then
					local index = Plain(Call(EditMacro, older, name ~= "" and name or " ", m.icon or Codec.QUESTION_MARK, m.body))
					if type(index) == "number" and index > 0 then
						updated = updated + 1
						Record(m.key, scope, name, m)
						map[m.key] = { scope = scope, name = name, body = m.body }
					else
						noRoom = noRoom + 1
					end
				else
					local index = room > 0 and Plain(Call(CreateMacro, name ~= "" and name or " ", m.icon or Codec.QUESTION_MARK, m.body,   -- the game's " " for no name
						scope == "character")) or nil
					if type(index) == "number" and index > 0 then
						made = made + 1
						Record(m.key, scope, name, m)
						map[m.key] = { scope = scope, name = name, body = m.body }
					else
						noRoom = noRoom + 1
					end
				end
			else
				noRoom = noRoom + 1
			end
		end
	end
	-- the ones the preset no longer has
	for key, r in pairs(rec) do
		if not keep[key] then
			gone[#gone + 1] = r
			rec[key] = nil
		end
	end
	for _, r in ipairs(gone) do
		local scope = r.scope == "character" and "character" or "account"
		local used                                         -- (the very text a key of this layout uses: never deleted)
		for key, m in pairs(map) do
			if m.scope == scope and SameText(r, m.name, m.body) then used = key end
		end
		if used then
			if not rec[used] then rec[used] = { scope = scope, name = r.name, body = r.body, icon = r.icon, preset = preset } end
		elseif scope == "character" then
			local index = E.MadeIndex(r)
			if index then
				E.TakeOffBars(index)
				index = E.MadeIndex(r)                         -- (found again: nothing moved, but never trusted)
				if index and E.DeleteMacro(index) then removed = removed + 1 end
			end
		elseif E.MadeIndex(r) then
			dropped[#dropped + 1] = { scope = scope, name = r.name, body = r.body, icon = r.icon, preset = r.preset }
		end
	end
	-- the dropped ones no longer there as made: forgotten
	for i = #dropped, 1, -1 do
		if not E.MadeIndex(dropped[i]) then table.remove(dropped, i) end
	end
	return map, made, there, noRoom, updated, removed
end

-- ============================================================
-- (0.1.8) /presets tidy: the twins made before records were kept. In the CHARACTER set only, the macros that are on no
-- action slot and the twin of another macro in the set - the same name, and the same spell after /cast (else the same
-- text). Of each group of twins at least one is always kept, and every one on a bar, and the first of each text the
-- preset applied uses or this addon made. A slot whose macro cannot be told from its twins (nameless macros showing the
-- same spell: the retail client answers the spell, not the macro) counts every one of them as on a bar - unless all of
-- them are twins of one group: then that group keeps one more per such slot, and its best kept one (the preset's text
-- first) is put on those slots before the others go, so every button keeps its macro.
-- Account macros, and any macro on a bar, are never touched.
-- ============================================================
-- The spell after a macro's first /cast (its conditions and a leading "!" dropped): lower case, and as written; or nil.
function E.CastOf(body)
	if type(body) ~= "string" then return nil end
	for line in string.gmatch(body .. "\n", "([^\n]*)\n") do
		local rest = string.match(line, "^%s*/cast%s+(.*)$")
		if rest then
			rest = string.gsub(rest, "%b[]", "")
			rest = Trim(string.match(rest, "^([^;]*)") or "")
			rest = string.gsub(rest, "^!", "")
			if rest ~= "" then return string.lower(rest), rest end
		end
	end
	return nil
end

local function TwinKey(name, body)
	local cast = E.CastOf(body)
	return Trim(name) .. "\n" .. (cast and ("cast:" .. cast) or ("text:" .. Body(body)))
end

-- The macros a slot may hold: ({ index }, true) when certain, (every candidate, false) when it cannot be told.
function E.SlotMacrosNow(slot)
	local kind, id, sub = E.ActionInfo(slot)
	if kind ~= "macro" then return nil end
	if sub ~= "spell" and type(id) == "number" and Plain(Call(GetMacroInfo, id)) ~= nil then return { id }, true end
	local index, guess = E.MacroInSlot(slot, id, sub)
	if index and not guess then return { index }, true end
	local text = Plain(C_ActionBar and C_ActionBar.GetActionText and Call(C_ActionBar.GetActionText, slot))
	local named = type(text) == "string" and text ~= "" and E.MacrosNamed(text) or {}
	local out = {}
	for _, i in ipairs(named) do
		if sub ~= "spell" or Plain(Call(GetMacroSpell, i)) == id then out[#out + 1] = i end
	end
	if #out == 0 then out = named end
	if #out == 0 and index then out = { index } end
	return out, false
end

-- The twins to remove: a list of { index, name, body, spell }, and the plan (the slots to give the kept one first).
-- layout: the preset applied (its macros are kept first); store: its records.
function E.TidyList(layout, store)
	local _, chr = Counts()
	local base = E.MAX_ACCOUNT
	local macros, groups = {}, {}
	for i = base + 1, base + chr do
		local name, icon, body = Call(GetMacroInfo, i)
		name, body = Plain(name), Plain(body)
		if type(name) == "string" then
			local m = { index = i, name = name, body = type(body) == "string" and body or "" }
			m.spell, m.spellWord = E.CastOf(body)
			m.key = TwinKey(m.name, m.body)
			macros[i] = m
			groups[m.key] = groups[m.key] or {}
			table.insert(groups[m.key], m)
		end
	end
	-- what is on the bars: certain, or a slot's candidates
	local onBar, shared = {}, {}
	for slot = 1, Codec.MAX_SLOT do
		local list, certain = E.SlotMacrosNow(slot)
		if list then
			if certain then
				onBar[list[1]] = true
			else
				local key, one = nil, true
				for _, i in ipairs(list) do
					local m = macros[i]
					if not m or (key and m.key ~= key) then one = false end
					key = key or (m and m.key)
				end
				if one and key and #list > 1 then
					shared[key] = shared[key] or {}
					table.insert(shared[key], slot)
				else
					for _, i in ipairs(list) do onBar[i] = true end
				end
			end
		end
	end
	-- the preset's own texts, and the macros recorded as made
	local wanted, recorded = {}, {}
	for _, m in ipairs(type(layout) == "table" and layout.macros or {}) do
		if m.scope == "character" then wanted[Trim(m.name) .. "\n" .. Body(m.body)] = true end
	end
	for _, r in pairs(type(store) == "table" and type(store.macrosMade) == "table" and store.macrosMade or {}) do
		if type(r) == "table" and r.scope == "character" then recorded[Trim(r.name) .. "\n" .. Body(r.body)] = true end
	end
	local out, plan = {}, {}
	local keys = {}
	for key in pairs(groups) do keys[#keys + 1] = key end
	table.sort(keys)
	for _, key in ipairs(keys) do
		local g = groups[key]
		if #g > 1 then
			local function Text(m) return Trim(m.name) .. "\n" .. Body(m.body) end
			local function Score(m)
				return (onBar[m.index] and 8 or 0) + (wanted[Text(m)] and 4 or 0) + (recorded[Text(m)] and 2 or 0)
			end
			-- kept: every one certainly on a bar; the first of each text the preset uses or this addon made; and of
			-- the rest, best first, one per slot that holds a twin it cannot tell beyond those (at least one kept in all)
			local kept, keptN, loose, texts, rest = {}, 0, 0, {}, {}
			for _, m in ipairs(g) do
				local t = Text(m)
				if onBar[m.index] then kept[m], keptN = true, keptN + 1
				elseif (wanted[t] or recorded[t]) and not texts[t] then kept[m], keptN, loose, texts[t] = true, keptN + 1, loose + 1, true
				else rest[#rest + 1] = m end
			end
			table.sort(rest, function(a, b)
				if Score(a) ~= Score(b) then return Score(a) > Score(b) end
				return a.index < b.index
			end)
			local more = math.max((shared[key] and #shared[key] or 0) - loose, keptN > 0 and 0 or 1)
			local drop = {}
			for i, m in ipairs(rest) do
				if i <= more then kept[m] = true else drop[#drop + 1] = m end
			end
			local keeper
			for _, m in ipairs(g) do
				if kept[m] and (not keeper or Score(m) > Score(keeper)) then keeper = m end
			end
			if #drop > 0 then
				for _, m in ipairs(drop) do out[#out + 1] = m end
				if shared[key] and keeper then plan[#plan + 1] = { keeper = keeper, slots = shared[key] } end
			end
		end
	end
	table.sort(out, function(a, b) return a.index < b.index end)
	return out, plan
end

-- The twins removed (out of a fight: nil, "combat" in one). Returns how many.
function E.Tidy(layout, store)
	if InCombatLockdown() then return nil, "combat" end
	local list, plan = E.TidyList(layout, store)
	Call(ClearCursor)
	-- the kept twin first on the slots that cannot tell it from the others (placing moves no macro)
	for _, p in ipairs(plan) do
		for _, slot in ipairs(p.slots) do
			Call(PickupMacro, p.keeper.index)
			if E.Holding() then Call(PlaceAction, slot) end
			Call(ClearCursor)
		end
	end
	-- then the twins, last first: each delete moves only the macros after it up
	local n = 0
	for i = #list, 1, -1 do
		local m = list[i]
		local name, _, body = Call(GetMacroInfo, m.index)
		if Plain(name) == m.name and Body(Plain(body)) == Body(m.body) and E.DeleteMacro(m.index) then
			n = n + 1
		end
	end
	return n
end

-- ============================================================
-- (LAYOUT-FORMAT.md "Utility buttons") LISTS: Mount up and a family (potions, food, runes ...), each a list best-first;
-- the first one the character owns goes in, a better one replacing it when it comes. A mount is owned when the game's
-- mount journal says it is collected (C_MountJournal.GetMountFromSpell + GetMountInfoByID's isCollected), or its spell
-- is known (IsPlayerSpell / IsSpellKnown); an item (a mount item, a family's) when it is in the bags.
-- ============================================================
local function OwnsMountSpell(spell)
	return E.Known(spell)                                  -- (the journal's isCollected first, then the spellbook)
end

local function ItemCount(id)
	local n = C_Item and C_Item.GetItemCount and Call(C_Item.GetItemCount, id)
	if n == nil then n = Call(GetItemCount, id) end
	n = Plain(n)
	return type(n) == "number" and n or 0
end

-- (0.1.11; Harry, Oct 25: "let's say we have a level 25 food but we are level 22, and we have level 15 food also - will
-- it try to use the 25 food or will it know to use the 15 food because we're only 22?") an item the character is too
-- low to use - its required level (the game's item info, its fifth value) over the character's - is passed over as if
-- not carried, so the 15 food goes in; at the level-up that allows it (Apply.lua's PLAYER_LEVEL_UP, E.levelUp: the game
-- may still answer the old level in that moment) the 25 one takes the button. An item the game has no info for yet is
-- taken as usable (a carried one always has it).
E.levelUp = nil
local function MinLevel(id)
	local get = (C_Item and C_Item.GetItemInfo) or rawget(_G, "GetItemInfo")
	if not get then return nil end
	local min = Plain(select(5, Call(get, id)))
	return type(min) == "number" and min or nil
end
local function Usable(id)
	if ItemCount(id) <= 0 then return false end
	local min = MinLevel(id)
	if not min then return true end
	local level = E.MyLevel()
	if type(E.levelUp) == "number" and E.levelUp > level then level = E.levelUp end
	return min <= level
end

-- (0.1.3; Harry, Oct 19: "use conjured before real even if our real one is higher level") a conjured item - its
-- tooltip's own "Conjured Item" line (ITEM_CONJURED), asked once per item - goes before any other the family carries,
-- whatever order a preset saved before this listed them in
local conjured = {}
function E.IsConjured(id)
	if conjured[id] ~= nil then return conjured[id] end
	local word = rawget(_G, "ITEM_CONJURED")
	local get = C_TooltipInfo and C_TooltipInfo.GetItemByID
	if type(word) ~= "string" or not get then return false end
	local data = Call(get, id)
	if type(data) ~= "table" or type(data.lines) ~= "table" then return false end   -- not cached yet: asked again later
	local yes = false
	for _, line in ipairs(data.lines) do
		local text = line.leftText
		if not (issecretvalue and issecretvalue(text)) and text == word then yes = true break end
	end
	conjured[id] = yes
	return yes
end

-- A family's list (a placed one: want[1]; a remembered one: want.kind). Its places: a conjured item's its own, any
-- other one's pushed past every conjured one, so the comparisons below keep conjured first.
local function IsFamily(want) return want[1] == "family" or want.kind == "family" end
local function ItemWeight(want, item)
	return (IsFamily(want) and not E.IsConjured(item)) and 10000 or 0
end

-- The best owned: ("spell" | "item", id, its place in the list), or nil.
function E.BestMount(want)
	local n = 0
	for _, spell in ipairs(want.spells or {}) do
		n = n + 1
		if OwnsMountSpell(spell) then return "spell", spell, n end
	end
	local items = want.items or {}
	if IsFamily(want) then
		for i, item in ipairs(items) do
			if Usable(item) and E.IsConjured(item) then return "item", item, n + i end
		end
	end
	for _, item in ipairs(items) do
		n = n + 1
		if Usable(item) then return "item", item, n + ItemWeight(want, item) end
	end
	return nil
end

-- Where a slot's mount stands in the list (its place), "none" for an empty slot, nil for something not on the list.
function E.MountRank(want, slot)
	local kind, id = E.ActionInfo(slot)
	if kind == nil then return E.HasActionAt(slot) and nil or "none" end
	local spell
	if kind == "summonmount" and type(id) == "number" then
		local _, s = Call(C_MountJournal and C_MountJournal.GetMountInfoByID, id)
		spell = Plain(s)
	elseif kind == "spell" then
		spell = id
	end
	local n = 0
	for _, s in ipairs(want.spells or {}) do
		n = n + 1
		if spell ~= nil and s == spell then return n end
	end
	for _, item in ipairs(want.items or {}) do
		n = n + 1
		if kind == "item" and id == item then
			-- (0.1.3) used up: the next one carried takes the button; (0.1.11) too high a level for the character: the same
			if not Usable(item) then return "none" end
			return n + ItemWeight(want, item)
		end
	end
	return nil
end

local function Holding()
	return Plain(Call(GetCursorInfo)) ~= nil
end
E.Holding = Holding

-- A spell on the cursor; a mount's spell the spellbook will not give up through the journal's own pickup (its
-- displayed list: C_MountJournal.Pickup takes the list's index).
function E.PickupSpellID(id)
	if C_Spell and C_Spell.PickupSpell then Call(C_Spell.PickupSpell, id) else Call(PickupSpell, id) end
	if Holding() then return true end
	local J, mount = C_MountJournal, MountOf(id)
	if type(J) ~= "table" or not mount then return false end
	local n = Plain(Call(J.GetNumDisplayedMounts)) or 0
	for i = 1, n do
		local mid = select(12, Call(J.GetDisplayedMountInfo, i))
		if Plain(mid) == mount then
			Call(J.Pickup, i)
			return Holding()
		end
	end
	return false
end

local function PickupItemID(id)
	if C_Item and C_Item.PickupItem then Call(C_Item.PickupItem, id) else Call(PickupItem, id) end
end

-- A list's pick on the cursor.
local function PickupMount(kind, id)
	if kind == "item" then PickupItemID(id); return Holding() end
	return E.PickupSpellID(id)
end

-- The slot's mount made the best owned one. Returns true when it placed one.
function E.PlaceMount(slot, want)
	local kind, id, n = E.BestMount(want)
	if not kind then return false end
	local now = E.MountRank(want, slot)
	if now == nil then return false end                   -- something not on the list: the player's
	if now ~= "none" and now <= n then return false end   -- already the best owned (or a better one)
	Call(ClearCursor)
	local placed = false
	if PickupMount(kind, id) then
		Call(PlaceAction, slot)
		placed = true
	end
	Call(ClearCursor)
	return placed
end

-- ============================================================
-- The slots
-- ============================================================
function E.PlaceSlots(layout, store, map, s)
	local spec = layout.specs and layout.specs[1] or {}
	local pins, remembered, mounts = store.layoutPins, store.layoutWaiting, store.layoutMounts
	E.ForgetBook()
	Call(ClearCursor)
	for slot = 1, Codec.MAX_SLOT do
		local want = spec.slots and spec.slots[slot]
		if want then
			remembered[slot] = nil                         -- (this layout says what the slot holds now)
			mounts[slot] = nil
			local kind, id, sub = E.ActionInfo(slot)
			local kindWanted = want[1]
			if kindWanted == "empty" then
				if E.HasActionAt(slot) then
					Call(PickupAction, slot)
					Call(ClearCursor)
					s.emptied = s.emptied + 1
				end
				pins[slot] = nil
			elseif kindWanted == "mount" or kindWanted == "family" then
				-- the best owned mount (or carried item of the family) in, whatever the slot held; none owned: the slot
				-- kept empty for it, and the first one owned goes in later (E.Recheck), a better one replacing it
				pins[slot] = nil
				mounts[slot] = { kind = kindWanted, spells = want.spells, items = want.items }
				local mk, mid, mn = E.BestMount(want)
				local now = E.MountRank(want, slot)
				if mk and type(now) == "number" and now <= mn then
					s.slots = s.slots + 1
				elseif mk then
					Call(ClearCursor)
					if PickupMount(mk, mid) then
						Call(PlaceAction, slot)
						s.slots = s.slots + 1
					end
					Call(ClearCursor)
				else
					if kindWanted == "mount" then s.unknown = s.unknown + 1 end
					if E.HasActionAt(slot) then
						Call(PickupAction, slot)
						Call(ClearCursor)
					end
				end
			else
				local placeID, ok = nil, false
				if kindWanted == "spell" then
					placeID = E.SpellFor(want)
					if want.auto == false then pins[slot] = true elseif want.auto == true then pins[slot] = false
					else pins[slot] = nil end
					if placeID and kind == "spell" and id == placeID then ok = "there"
					elseif placeID then E.PickupSpellID(placeID); ok = Holding() end
				elseif kindWanted == "item" then
					placeID = want[2]
					pins[slot] = nil
					if kind == "item" and id == placeID then ok = "there"
					else
						PickupItemID(placeID)
						ok = Holding()
					end
				elseif kindWanted == "macro" then
					pins[slot] = nil
					local m = map[want[2]]
					local _, index
					if m then _, index = E.FindMacro(m.scope, m.name, m.body) end
					placeID = index
					-- (0.1.7) "already there" only when the slot's macro is certainly that one: another nameless macro
					-- (" " too) on the slot is no proof - the macro is placed again
					local inSlot, guess
					if index and kind == "macro" then inSlot, guess = E.MacroInSlot(slot, id, sub) end
					if index and inSlot == index and not guess then ok = "there"
					elseif index then Call(PickupMacro, index); ok = Holding() end
				end
				if ok == "there" then
					s.slots = s.slots + 1
				elseif ok then
					Call(PlaceAction, slot)
					s.slots = s.slots + 1
				elseif kindWanted == "macro" then
					-- (0.1.9) the preset's macro could not be made: the slot never keeps what was there before (the old
					-- button left on it looked like the preset not being taken) - emptied
					if E.HasActionAt(slot) then
						Call(ClearCursor)
						Call(PickupAction, slot)
						s.emptied = s.emptied + 1
					end
				elseif kindWanted == "spell" then
					-- (the format's "Ranks and levels") not known yet: remembered, the slot kept empty for it, and placed
					-- the moment any rank of it is learnt (E.Recheck)
					s.unknown = s.unknown + 1
					remembered[slot] = { id = want[2], name = want.name or E.SpellName(want[2]), auto = want.auto }
					if E.HasActionAt(slot) then
						Call(ClearCursor)
						Call(PickupAction, slot)
					end
				end
				Call(ClearCursor)
			end
		end
	end
	store.autoRankDefault = layout.autoRankDefault ~= false
	return s
end

-- ============================================================
-- The keys: which button shows a command's slot now, and the binding it answers
-- ============================================================
E.MULTI_PAGE = { 6, 5, 3, 4, 13, 14, 15 }       -- MULTIACTIONBARn's page (Blizzard_ActionBar MultiActionBars.xml)
E.BLIZZARD_BARS = { "MultiBarBottomLeft", "MultiBarBottomRight", "MultiBarRight", "MultiBarLeft", "MultiBar5", "MultiBar6",
	"MultiBar7" }
-- the bar addons whose buttons are known by name (and whose "bar is on" can be asked): their folder names
E.BAR_ADDONS = { "Bartender4", "ElvUI", "Dominos" }

-- A command's slot: (slot on the bar's own page, the bar's page, the button's number); nil for one that is no slot's
-- (the stance, pet and extra buttons).
function E.SlotOfCommand(cmd)
	local i = tonumber(string.match(cmd, "^ACTIONBUTTON(%d+)$"))
	if i then return i, 1, i end
	local n, j = string.match(cmd, "^MULTIACTIONBAR(%d)BUTTON(%d+)$")
	n, j = tonumber(n), tonumber(j)
	if n and E.MULTI_PAGE[n] then return (E.MULTI_PAGE[n] - 1) * 12 + j, E.MULTI_PAGE[n], j end
	return nil
end

-- The game's own button for a command.
function E.BlizzardButton(cmd)
	local i = tonumber(string.match(cmd, "^ACTIONBUTTON(%d+)$"))
	if i then return rawget(_G, "ActionButton" .. i) end
	local n, j = string.match(cmd, "^MULTIACTIONBAR(%d)BUTTON(%d+)$")
	n = tonumber(n)
	if n and E.BLIZZARD_BARS[n] then return rawget(_G, E.BLIZZARD_BARS[n] .. "Button" .. j) end
	return nil
end

local function Bool(fn)
	return Plain(Call(fn)) and true or false
end
local function Num(fn)
	local v = Plain(Call(fn))
	return type(v) == "number" and v or nil
end

-- The page bar 1 shows now (the game's own rule: vehicle, override, temporary shapeshift, a form's bonus bar on page 1,
-- else the page chosen).
function E.Bar1Page()
	if Bool(HasVehicleActionBar) and Num(GetVehicleBarIndex) then return Num(GetVehicleBarIndex) end
	if Bool(HasOverrideActionBar) and Num(GetOverrideBarIndex) then return Num(GetOverrideBarIndex) end
	if Bool(HasTempShapeshiftActionBar) and Num(GetTempShapeshiftBarIndex) then return Num(GetTempShapeshiftBarIndex) end
	local page = Num(GetActionBarPage) or 1
	if page == 1 and Bool(HasBonusActionBar) and Num(GetBonusBarIndex) then return Num(GetBonusBarIndex) end
	return page
end

function E.Loaded(name)
	local f = C_AddOns and C_AddOns.IsAddOnLoaded or rawget(_G, "IsAddOnLoaded")
	local loaded = Call(f, name)
	return Plain(loaded) and true or false
end

-- The slot a button shows now, or nil.
function E.ButtonAction(b)
	if type(b) ~= "table" then return nil end
	local st = rawget(b, "_state_type")
	if st ~= nil then                                     -- LibActionButton (Bartender4, ElvUI)
		if st ~= "action" then return nil end
		local a = tonumber(rawget(b, "_state_action"))
		return a and a > 0 and a or nil
	end
	local a = Plain(Call(b.GetAttribute, b, "action"))
	if type(a) == "number" and a > 0 then return a end
	a = rawget(b, "action")
	if type(a) == "number" and a > 0 then return a end
	return nil
end

-- The binding command a button answers.
function E.ButtonCommand(b)
	local name = Plain(Call(b.GetName, b))
	local c = Plain(Call(b.GetAttribute, b, "commandName"))      -- Dominos
	if type(c) == "string" and c ~= "" then return c end
	local cfg = rawget(b, "config")
	if type(cfg) == "table" and (cfg.keyBoundTarget ~= nil or cfg.keyBoundClickButton ~= nil) then   -- LibActionButton
		if type(cfg.keyBoundTarget) == "string" and cfg.keyBoundTarget ~= "" then return cfg.keyBoundTarget end
		if name then return "CLICK " .. name .. ":" .. (type(cfg.keyBoundClickButton) == "string" and cfg.keyBoundClickButton or "LeftButton") end
	end
	c = rawget(b, "keyBoundTarget")
	if type(c) == "string" and c ~= "" then return c end
	if type(b.GetBindingAction) == "function" then
		c = Plain(Call(b.GetBindingAction, b))
		if type(c) == "string" and c ~= "" then return c end
	end
	c = rawget(b, "commandName") or rawget(b, "bindingAction")      -- the game's own
	if type(c) == "string" and c ~= "" then return c end
	if name then return "CLICK " .. name .. ":LeftButton" end
	return nil
end

-- (a bar shown only in a fight, or on mouseover with its buttons hidden) its addon's own word that the bar is on
function E.BarOn(b)
	local name = Plain(Call(b.GetName, b)) or ""
	local n = tonumber(string.match(name, "^BT4Button(%d+)$"))
	if n then
		local BT = rawget(_G, "Bartender4")
		local ok, mod = pcall(function() return BT:GetModule("ActionBars", true) end)
		local bars = ok and type(mod) == "table" and mod.actionbars
		local bar = type(bars) == "table" and bars[math.floor((n - 1) / 12) + 1]
		for _, candidate in pairs(type(bars) == "table" and bars or {}) do
			if type(candidate) == "table" and type(candidate.buttons) == "table" then
				for _, button in pairs(candidate.buttons) do if button == b then bar = candidate end end
			end
		end
		return type(bar) == "table" and not bar.disabled
	end
	local id = tonumber(string.match(name, "^ElvUI_Bar(%d+)Button%d+$"))
	if id then
		local elv = rawget(_G, "ElvUI")
		local db = type(elv) == "table" and type(elv[1]) == "table" and elv[1].db
		local ab = type(db) == "table" and db.actionbar
		local bar = type(ab) == "table" and ab["bar" .. id]
		return type(bar) == "table" and bar.enabled == true
	end
	local p = b
	for _ = 1, 4 do                                       -- Dominos: the frame that holds the button, its sets
		p = p and p.GetParent and Call(p.GetParent, p)
		if type(p) == "table" and type(rawget(p, "sets")) == "table" then return not p.sets.hidden end
	end
	return false
end

local function Visible(b)
	return Plain(Call(b.IsVisible, b)) == true
end

-- Every action button there is: the known names first (the bar addons', then the game's), then (any other addon's)
-- every frame of the game that answers an action slot.
function E.Candidates()
	local out, seen = {}, {}
	local function Add(b)
		if type(b) == "table" and not seen[b] then
			if b.IsForbidden and Call(b.IsForbidden, b) then return end
			seen[b] = true
			out[#out + 1] = b
		end
	end
	local function Named(name) Add(rawget(_G, name)) end
	for n = 1, 180 do Named("BT4Button" .. n) end
	for bar = 1, 15 do for i = 1, 12 do Named("ElvUI_Bar" .. bar .. "Button" .. i) end end
	for n = 1, 180 do Named("DominosActionButton" .. n) end
	for _, bar in ipairs({ "MultiBarRight", "MultiBarLeft", "MultiBarBottomRight", "MultiBarBottomLeft", "MultiBar5", "MultiBar6",
		"MultiBar7" }) do
		for i = 1, 12 do Named(bar .. "ActionButton" .. i) end
	end
	local blizzard = {}
	for i = 1, 12 do blizzard[#blizzard + 1] = "ActionButton" .. i end
	for _, bar in ipairs(E.BLIZZARD_BARS) do for i = 1, 12 do blizzard[#blizzard + 1] = bar .. "Button" .. i end end
	local generic = {}
	if type(EnumerateFrames) == "function" then
		local f = Call(EnumerateFrames)
		local guard = 0
		while f and guard < 200000 do
			guard = guard + 1
			local kind = not seen[f] and Plain(Call(f.GetObjectType, f))
			if (kind == "Button" or kind == "CheckButton") and E.ButtonAction(f) then generic[#generic + 1] = f end
			f = Call(EnumerateFrames, f)
		end
	end
	for _, b in ipairs(generic) do
		local name = Plain(Call(b.GetName, b))
		local isBlizzard = false
		for _, n in ipairs(blizzard) do if n == name then isBlizzard = true end end
		if not isBlizzard then Add(b) end
	end
	for _, name in ipairs(blizzard) do Named(name) end
	return out
end

-- Where a command's keys go now: (target command, hidden) - target nil when no button shows the slot under a bar addon.
function E.Resolve(cmd, candidates, commands)
	local slot, page, i = E.SlotOfCommand(cmd)
	if not slot or commands then return cmd, false end
	local want = { slot }
	if page == 1 then
		local now = E.Bar1Page()
		if now and now ~= 1 then table.insert(want, 1, (now - 1) * 12 + i) end
	end
	local function Pick(test)
		for _, s in ipairs(want) do
			local first
			for _, b in ipairs(candidates) do
				if E.ButtonAction(b) == s and test(b) then
					local c = E.ButtonCommand(b)
					if c == cmd then return c end
					first = first or c
				end
			end
			if first then return first end
		end
		return nil
	end
	local target = Pick(Visible)
	if target then return target, false end
	target = Pick(E.BarOn)
	if target then return target, false end
	-- nothing shows it: the game's own bars still take the command (the bar takes it when it is turned on)
	local barAddon = false
	for _, a in ipairs(E.BAR_ADDONS) do if E.Loaded(a) then barAddon = true end end
	if not barAddon and E.BlizzardButton(cmd) then return cmd, true end
	return nil, true
end

-- A key bound to a target ("CLICK <button>:<mouse>" through SetBindingClick).
local function Bind(key, target)
	local button, mouse = string.match(target, "^CLICK (.+):([^:]+)$")
	if button then return Call(SetBindingClick, key, button, mouse) end
	return Call(SetBinding, key, target)
end

-- ============================================================
-- (0.1.6, LAYOUT-FORMAT.md "Keys an import made") THE PLAYER'S OWN KEYS: an import never leaves a trace on them.
-- Harry, Oct 20: "just make it so that if i unbind something after mistakenly binding it, it doesn't interfere with the
-- game file at all" (he had put Shift+C on a bar button by mistake, removed it in the editor, and the next import left
-- Shift+C bound to nothing - his character pane's key lost). 0.1.4's restore on drop, for game commands only, made
-- general:
--   * Every key an import binds is remembered in the character's store the first time it takes it: what the key did
--     before (store.keysTaken[key] = { cmd = its old binding, "" for nothing; to = what the import made it do }).
--   * A key the layout no longer uses goes back to exactly what it did before ("" : unbound) and is forgotten - wherever
--     it sat, and also when the layout lists its button with no keys. Only these keys ever come off: a key the player
--     bound himself is never unbound, not even when it sits on a command the layout names.
--   * A remembered key the player has rebound since (it no longer does what the import made it do) is his: forgotten,
--     never given back over his choice.
--   * Nothing else is written: SetBinding of the layout's keys and of the keys given back, then SaveBindings.
-- ============================================================

-- What a key does now ("" for nothing).
function E.KeyAction(key)
	local a = Plain(Call(GetBindingAction, key))
	if type(a) ~= "string" then a = Plain(Call(GetBindingByKey, key)) end
	return type(a) == "string" and a or ""
end

-- The layout's keys bound. opts.commands: the host's buttons answer the game's commands (HUI Bars); opts.save(): the
-- host's own save. store: the character's (its keysTaken: the keys this importer made, and what they did before).
-- Returns (keys bound, keys on hidden bars, { [command] = target }, keys given back).
function E.BindKeys(layout, opts, store)
	opts = opts or {}
	local spec = layout.specs and layout.specs[1] or {}
	local keys = spec.keys or {}
	if type(store) == "table" and type(store.keysTaken) ~= "table" then store.keysTaken = {} end
	local made = type(store) == "table" and store.keysTaken or {}
	local commands = {}
	for cmd in pairs(keys) do if Codec.IsCommand(cmd) then commands[#commands + 1] = cmd end end
	table.sort(commands)
	-- a remembered key the player has rebound since is his: forgotten
	for key, rec in pairs(made) do
		if type(key) ~= "string" or type(rec) ~= "table" or type(rec.cmd) ~= "string" or type(rec.to) ~= "string"
			or E.KeyAction(key) ~= rec.to then
			made[key] = nil
		end
	end
	if #commands == 0 and not next(made) then return 0, 0, {}, 0 end
	local huiBars = opts.commands or E.Loaded("ForeverBars")
	local candidates = (not huiBars and #commands > 0) and E.Candidates() or {}
	local targets, order, hidden, alone = {}, {}, 0, {}
	for _, cmd in ipairs(commands) do
		local target, off = E.Resolve(cmd, candidates, huiBars)
		if off then hidden = hidden + #keys[cmd] end
		if target then
			if not targets[target] then order[#order + 1] = target end
			targets[target] = targets[target] or {}
			for _, k in ipairs(keys[cmd]) do table.insert(targets[target], k) end
		else
			for _, k in ipairs(keys[cmd]) do alone[k] = true end   -- (no button shows it under a bar addon: left alone)
		end
		targets[cmd .. "\0"] = target                       -- (for the report: what each command went to)
	end
	-- the layout's keys: what each did before kept the first time this importer takes it
	local used, bound = {}, 0
	for _, target in ipairs(order) do
		for _, key in ipairs(targets[target]) do
			used[key] = true
			local old, rec = E.KeyAction(key), made[key]
			if Bind(key, target) ~= false then
				bound = bound + 1
				if rec then
					if rec.cmd == target then made[key] = nil else rec.to = target end   -- (back to what it did: done)
				elseif old ~= target then
					made[key] = { cmd = old, to = target }
				end
			end
		end
	end
	-- a key this importer made that the layout no longer uses: back to what it did before (nothing: unbound)
	local restored, freed = 0, 0
	for key, rec in pairs(made) do
		if not used[key] and not alone[key] then
			if rec.cmd == "" then
				Call(SetBinding, key, nil)
				freed = freed + 1
			elseif Bind(key, rec.cmd) ~= false then
				restored = restored + 1
			end
			made[key] = nil
		end
	end
	if bound + restored + freed > 0 then                    -- (nothing bound, nothing given back: nothing saved)
		if opts.save then opts.save()
		else Call(SaveBindings, Plain(Call(GetCurrentBindingSet)) or 1) end
	end
	local map = {}
	for _, cmd in ipairs(commands) do map[cmd] = targets[cmd .. "\0"] end
	return bound, hidden, map, restored
end

-- ============================================================
-- (LAYOUT-FORMAT.md "Settings") the game settings a layout turns on, each only while it is off, never one turned off.
-- Each the client's own CVar (its Settings page's: Blizzard_SettingsDefinitions_Frame, Blizzard_DamageMeter); All bars
-- is the game's own "Action Bar N" ticks (PROXY_SHOW_ACTIONBAR_2..8, MultiActionBars.lua) for the bars the layout puts
-- something on, and only while the game's own bars are the ones drawn.
-- ============================================================
E.SETTINGS = {
	{ key = "autoLoot", cvar = "autoLootDefault", word = "Auto loot" },
	{ key = "damageMeter", cvar = "damageMeterEnabled", word = "Damage meter" },
}   -- (Harry, Oct 19: "remove cooldown numbers, target's target, mouse loot, self cast, key down, all bars")
-- the game's "Action Bar N" tick (N = 2..8) for each multi bar's page
E.BAR_TOGGLE = { [6] = 2, [5] = 3, [3] = 4, [4] = 5, [13] = 6, [14] = 7, [15] = 8 }

local function CVarOn(cvar)
	local v = C_CVar and C_CVar.GetCVarBool and Call(C_CVar.GetCVarBool, cvar)
	if v == nil then v = Call(GetCVarBool, cvar) end
	return Plain(v) == true, v ~= nil
end

local function SetCVarOn(cvar)
	if C_CVar and C_CVar.SetCVar then return Call(C_CVar.SetCVar, cvar, "1") ~= false end
	return Call(SetCVar, cvar, "1") ~= false
end

-- Whether the game's own bars are the ones on the screen (no bar addon, no HUI Bars).
function E.GameBars()
	if E.Loaded("ForeverBars") then return false end
	for _, a in ipairs(E.BAR_ADDONS) do if E.Loaded(a) then return false end end
	-- (any other bar addon hides the game's bar 1)
	local b = rawget(_G, "ActionButton1")
	if type(b) == "table" and Plain(Call(b.IsVisible, b)) == false then return false end
	return true
end

-- The bars (2..8) a layout puts something on.
function E.BarsUsed(layout)
	local out, spec = {}, layout.specs and layout.specs[1] or {}
	for slot, want in pairs(spec.slots or {}) do
		local n = E.BAR_TOGGLE[math.floor((slot - 1) / 12) + 1]
		if n and want[1] ~= "empty" then out[n] = true end
	end
	return out
end

-- Turn on what the layout asks. Returns the words of what was switched on.
function E.ApplySettings(layout)
	local want, on = layout.settings, {}
	if type(want) ~= "table" or InCombatLockdown() then return on end
	for _, def in ipairs(E.SETTINGS) do
		if want[def.key] == true then
			if def.cvar then
				local isOn, exists = CVarOn(def.cvar)
				if exists and not isOn and SetCVarOn(def.cvar) then on[#on + 1] = def.word end
			elseif def.key == "actionBars" and E.GameBars() and type(Settings) == "table" then
				local turned = false
				for n in pairs(E.BarsUsed(layout)) do
					local var = "PROXY_SHOW_ACTIONBAR_" .. n
					if Call(Settings.GetSetting, var) and Plain(Call(Settings.GetValue, var)) ~= true then
						Call(Settings.SetValue, var, true)
						turned = true
					end
				end
				if turned then on[#on + 1] = def.word end
			end
		end
	end
	return on
end

-- ============================================================
-- Apply: macros, slots, keys (and, when the host asks - opts.settings - the game settings). Out of a fight only (nil,
-- "combat" in one: the host queues it).
-- ============================================================
-- (LAYOUT-FORMAT.md "Utility buttons") an equipped slot's button is a macro the game keeps following the slot
-- ("#showtooltip 13" + "/use 13", account scope, made once): a layout's { "slot", n } becomes { "macro", key } of such a
-- macro, on a copy.
E.SLOT_WORDS = { "Head", "Neck", "Shoulder", "Shirt", "Chest", "Waist", "Legs", "Feet", "Wrist", "Hands", "Finger 1",
	"Finger 2", "Trinket 1", "Trinket 2", "Back", "Main hand", "Off hand", "Ranged", "Tabard" }
function E.SlotMacros(layout)
	local spec = layout.specs and layout.specs[1]
	local any = false
	for _, want in pairs(spec and spec.slots or {}) do if want[1] == "slot" then any = true end end
	if not any then return layout end
	layout = Codec.Copy(layout)
	spec = layout.specs[1]
	layout.macros = layout.macros or {}
	local made = {}
	for slot, want in pairs(spec.slots) do
		if want[1] == "slot" then
			local n = want[2]
			local key = "slot" .. n
			if not made[n] then
				made[n] = true
				layout.macros[#layout.macros + 1] = { key = key, name = E.SLOT_WORDS[n] or ("Slot " .. n), icon = Codec.QUESTION_MARK,
					body = "#showtooltip " .. n .. "\n/use " .. n, scope = "account" }
			end
			spec.slots[slot] = { "macro", key }
		end
	end
	return layout
end

function E.Apply(layout, store, opts)
	if type(layout) ~= "table" then return nil, "no layout" end
	if InCombatLockdown() then return nil, "combat" end
	layout = E.SlotMacros(layout)
	store = E.Store(store)
	local s = { slots = 0, keys = 0, made = 0, there = 0, noRoom = 0, unknown = 0, emptied = 0, hidden = 0, cleared = 0,
		updated = 0, removed = 0 }
	-- (0.1.7) opts.previous: the layout applied before - what it placed on a slot this one does not name, taken off first
	-- (before any macro is made, while the macros' places are still the ones the bars were filled with)
	if opts and type(opts.previous) == "table" then s.cleared = E.ClearLeftovers(opts.previous, layout) end
	-- (0.1.8) the macros it made are its own: the preset applied before records were kept seeded once, then edited in
	-- place, made, or (dropped) deleted - after the slots above are cleared, before any is placed
	if not store.macrosSeeded then
		if opts and type(opts.previous) == "table" then E.SeedMacros(store, opts.previous) end
		store.macrosSeeded = true
	end
	local map
	map, s.made, s.there, s.noRoom, s.updated, s.removed = E.Macros(layout, store)
	E.PlaceSlots(layout, store, map, s)
	s.keys, s.hidden, s.targets, s.restored = E.BindKeys(layout, opts, store)
	s.settings = opts and opts.settings and E.ApplySettings(layout) or {}
	return s
end

-- The one line: "Main applied - 7 slots, 6 keys, macros 2 new, 1 updated, 1 removed, 3 keys on hidden bars, 1 not known
-- yet"
function E.Words(name, s)
	local parts = { string.format("%s applied - %d slot%s, %d key%s", name, s.slots, s.slots == 1 and "" or "s", s.keys,
		s.keys == 1 and "" or "s") }
	local updated, removed = s.updated or 0, s.removed or 0
	if s.made + s.there + s.noRoom + updated + removed > 0 then
		local m = {}
		if s.made > 0 or (s.there == 0 and s.noRoom == 0 and updated == 0 and removed == 0) then m[#m + 1] = s.made .. " new" end
		if updated > 0 then m[#m + 1] = updated .. " updated" end            -- (0.1.8) edited in place
		if removed > 0 then m[#m + 1] = removed .. " removed" end            -- (0.1.8) dropped by the preset, deleted
		if s.there > 0 then m[#m + 1] = s.there .. " already there" end
		if s.noRoom > 0 then m[#m + 1] = s.noRoom .. " did not fit" end
		parts[#parts + 1] = "macros " .. table.concat(m, ", ")
	end
	if (s.hidden or 0) > 0 then parts[#parts + 1] = s.hidden .. " key" .. (s.hidden == 1 and "" or "s") .. " on hidden bars" end
	if (s.restored or 0) > 0 then parts[#parts + 1] = s.restored .. " key" .. (s.restored == 1 and "" or "s") .. " given back" end
	if (s.cleared or 0) > 0 then parts[#parts + 1] = s.cleared .. " cleared" end
	if s.unknown > 0 then parts[#parts + 1] = s.unknown .. " not known yet" end
	if type(s.settings) == "table" and #s.settings > 0 then parts[#parts + 1] = "on: " .. table.concat(s.settings, ", ") end
	return table.concat(parts, ", ")
end

-- ============================================================
-- Later: the waiting spells, the mounts, Auto rank
-- ============================================================
-- (once a character, before Auto rank first changes anything) a slot the player keeps at a LOWER rank than the highest
-- known - a downrank put there by hand - is pinned, so turning Auto rank on never takes a deliberate rank away. Waits
-- (false) while the spells' rank texts are not loaded yet. opts.only: the slots to look at (nil: all).
function E.SeedPins(store, only)
	if store.layoutPinsSeeded then return true end
	local b, any = E.Book(), false
	for _, e in pairs(b) do
		if e.rank > 0 then any = true; break end
	end
	if not any then return false end
	for slot = 1, Codec.MAX_SLOT do
		if store.layoutPins[slot] == nil and (not only or only[slot]) then
			local kind, id = E.ActionInfo(slot)
			local rank = kind == "spell" and E.RankOf(id)
			local name = rank and E.SpellName(id)
			local best = name and b[name]
			if best and best.rank > rank then store.layoutPins[slot] = true end
		end
	end
	store.layoutPinsSeeded = true
	return true
end

-- (the format's "Ranks and levels") the layout's spells not known when it was applied, placed as soon as any rank is
-- learnt (a pinned one: its own rank) while the slot is still empty; a slot the player filled meanwhile is his.
function E.PlaceRemembered(store)
	local w = store.layoutWaiting
	local placed = 0
	for slot, want in pairs(w) do
		if E.HasActionAt(slot) then
			w[slot] = nil
		else
			local id = E.SpellFor({ "spell", want.id, name = want.name, auto = want.auto })
			if id then
				Call(ClearCursor)
				E.PickupSpellID(id)
				if Holding() then
					Call(PlaceAction, slot)
					placed = placed + 1
					w[slot] = nil
				end
				Call(ClearCursor)
			end
		end
	end
	return placed
end

-- The mount slots: the best owned mount in (a faster one learnt replaces the one there); a slot the player gave
-- something else is his (forgotten).
function E.PlaceMounts(store)
	local placed = 0
	for slot, want in pairs(store.layoutMounts) do
		if E.MountRank(want, slot) == nil then
			store.layoutMounts[slot] = nil
		elseif E.PlaceMount(slot, want) then
			placed = placed + 1
		end
	end
	return placed
end

-- Auto rank: every ranked spell not pinned at the highest rank known. opts.only: the slots to look at (nil: all).
-- Returns the swaps, or false while the rank texts are not loaded (the host asks again later).
function E.AutoRank(store, only)
	if not E.SeedPins(store, only) then return false end
	local swaps = 0
	local b = E.Book()
	for slot = 1, Codec.MAX_SLOT do
		if not only or only[slot] then
			local kind, id = E.ActionInfo(slot)
			if kind == "spell" and type(id) == "number" and not E.IsPinned(store, slot) then
				local rank = E.RankOf(id)
				if rank then
					local name = E.SpellName(id)
					local best = name and b[name]
					if best and best.rank > rank and best.id ~= id and E.Known(best.id) then
						Call(ClearCursor)
						E.PickupSpellID(best.id)
						if Holding() then
							Call(PlaceAction, slot)
							swaps = swaps + 1
						end
						Call(ClearCursor)
					end
				end
			end
		end
	end
	return swaps
end

-- ============================================================
-- (0.1.5; Harry, Oct 19: "can you find out why inner focus is on E? i guess it took an empty slot when i talented it,
-- and then we assigned it to num1") THE GAME'S OWN PUSH. A spell learnt (a talent, a new trainer spell) is put by the
-- client itself into the first empty action slot, and SPELL_PUSHED_TO_ACTIONBAR(spellID, slot, position) says where
-- (SpellBookDocumentation.lua). Its second value is the ABSOLUTE action slot (1-180) and its third the button on that
-- slot's page (1-12), whatever the documentation's names ("slot", "page") suggest: the client's own reader,
-- Blizzard_FrameXML IconIntroAnimation.lua, works the page out as floor((slot - 1) / 12) + 1 and flies the icon to
-- ActionButton<position>, and ActionButton.lua's MarkNewActionHighlight(slot) / ClearNewActionHighlight(slot) ask
-- GetActionInfo of that same number. So the push's slot is taken as it comes, never paged again. Then the layout's own
-- placement put the spell on its planned button too: the spell twice, and the slot the layout keeps empty filled.
-- While a layout is applied:
--   * E.NotePush keeps the push (store.layoutPushed[slot] = { id, at }) when the layout plans that slot (empty, another
--     spell waiting, a mount, an item, a macro) or plans the spell (by ID or by name, any rank) on another slot. A slot
--     and a spell the layout says nothing of: the game's push left alone (the player may want it).
--   * E.UndoPushes, first thing in E.Recheck (so a pushed waiting slot is never taken for one the player filled), out of
--     a fight with nothing on the cursor: the pushed slot emptied (PickupAction + ClearCursor) only while it still holds
--     that spell - and a slot the layout does not mention only while the spell is, or is about to be, on its own button.
--     Something else there now: the player's, forgotten. Then the remembered spells are placed as before (the spell on
--     its own button). The host says it in one line of its own chat frame (E.PushLine): "Inner Focus kept to its own
--     button" (or "... left in the spellbook" when the layout has no button for it).
-- ============================================================
E.PUSH_WAIT = 5      -- seconds a pushed slot may still read empty (its own update a moment behind the event)

local function SameSpell(want, id, name)
	if type(want) ~= "table" or want[1] ~= "spell" then return false end
	if want[2] == id then return true end
	local planned = want.name or E.SpellName(want[2])
	return name ~= nil and planned == name
end

-- The push's absolute action slot, or nil (the gamepad's 0, or nothing usable).
function E.PushSlot(slot)
	slot = Plain(slot)
	if type(slot) ~= "number" or slot < 1 or slot > Codec.MAX_SLOT or slot % 1 ~= 0 then return nil end
	return slot
end

-- Whether a push goes against the layout: "slot" (the layout plans that slot for anything else), "spell" (it keeps the
-- spell on another button), or nil (its own button, or nothing the layout says); and the spell's own slots.
function E.PushAgainst(layout, id, slot)
	local spec = type(layout) == "table" and layout.specs and layout.specs[1] or {}
	local slots = spec.slots or {}
	local name = E.SpellName(id)
	local want = slots[slot]
	if SameSpell(want, id, name) then return nil, {} end
	local own = {}
	for s, w in pairs(slots) do
		if s ~= slot and SameSpell(w, id, name) then own[#own + 1] = s end
	end
	table.sort(own)
	if want ~= nil then return "slot", own end
	if #own > 0 then return "spell", own end
	return nil, own
end

-- Keep a push to undo. Returns true when kept (the host rechecks soon).
function E.NotePush(layout, store, id, slot)
	id, slot = Plain(id), E.PushSlot(slot)
	if type(id) ~= "number" or not slot or type(layout) ~= "table" or type(store) ~= "table" then return false end
	if not E.PushAgainst(layout, id, slot) then return false end
	E.Store(store).layoutPushed[slot] = { id = id, at = Plain(Call(GetTime)) }
	return true
end

-- Whether a push waits to be undone.
function E.PushesWaiting(store)
	return type(store) == "table" and type(store.layoutPushed) == "table" and next(store.layoutPushed) ~= nil
end

-- The spell on (or about to go on) one of its own slots: one holds it, or one still waits for it and it is known.
local function OnOwn(store, own, id, name)
	for _, s in ipairs(own) do
		local kind, have = E.ActionInfo(s)
		if kind == "spell" and (have == id or (name and E.SpellName(have) == name)) then return true end
		local w = store.layoutWaiting[s]
		if kind == nil and not E.HasActionAt(s) and type(w) == "table"
			and E.SpellFor({ "spell", w.id, name = w.name, auto = w.auto }) then
			return true
		end
	end
	return false
end

-- The pushes undone: a list of { id, name, own = on its own button }. Out of a fight, nothing on the cursor.
function E.UndoPushes(layout, store)
	local out = {}
	if not E.PushesWaiting(store) or type(layout) ~= "table" then return out end
	if InCombatLockdown() or Holding() then return out end
	local pushed = store.layoutPushed
	local now = Plain(Call(GetTime))
	local slots = {}
	for slot in pairs(pushed) do slots[#slots + 1] = slot end
	table.sort(slots)
	for _, slot in ipairs(slots) do
		local p = pushed[slot]
		local kind, id = E.ActionInfo(slot)
		local name = type(p) == "table" and E.SpellName(p.id) or nil
		if type(p) == "table" and kind == "spell" and (id == p.id or (name and E.SpellName(id) == name)) then
			local against, own = E.PushAgainst(layout, p.id, slot)
			local onOwn = OnOwn(store, own, p.id, name)
			if against == "slot" or (against == "spell" and onOwn) then
				Call(PickupAction, slot)
				Call(ClearCursor)
				out[#out + 1] = { id = p.id, name = name, own = onOwn }
			end
			pushed[slot] = nil
		elseif type(p) ~= "table" or kind ~= nil or E.HasActionAt(slot) or type(p.at) ~= "number" or type(now) ~= "number"
			or now < p.at or now - p.at > E.PUSH_WAIT then
			pushed[slot] = nil                              -- something else there now (the player's), or long gone
		end                                                 -- (empty a moment after the push: its update still coming)
	end
	return out
end

-- The one line for the pushes undone: "Inner Focus kept to its own button", nil for none.
function E.PushLine(undone)
	if type(undone) ~= "table" or #undone == 0 then return nil end
	local parts = {}
	for _, u in ipairs(undone) do
		parts[#parts + 1] = (u.name or "A new spell") .. (u.own and " kept to its own button" or " left in the spellbook")
	end
	return table.concat(parts, ", ")
end

-- ============================================================
-- (0.1.7; Harry, Oct 20: "it hasn't taken the new skills. it doesn't commit the changes ... i also moved something to a
-- different slot and it didn't move") A PRESET APPLIED OVER ANOTHER. A layout only names the slots it fills (and the ones
-- the editor knows were emptied: { "empty" }); a slot the new one does not name is left alone. So what the previous
-- layout placed on a slot the new one no longer names - a spell moved to another button, a button dropped, a macro
-- dropped - would stay. E.Leftovers lists those slots while each still holds exactly what the old layout put there (a
-- spell of that name, any rank; that item; that macro, certainly - by its name and text, never a guess between nameless
-- ones; a mount or family item of its list); E.Apply (opts.previous) empties them before it places anything. A slot the
-- player changed by hand since is his: never touched. (0.1.8) A dropped macro this addon made is then deleted
-- (character) or let go (account): "THE MACROS IT MADE".
-- ============================================================
-- The index of a layout's macro as E.Macros made or found it ("<name> 2" on a clash), or nil.
local function MacroIndexOf(m)
	if type(m) ~= "table" then return nil end
	local scope = m.scope == "character" and "character" or "account"
	for n = 1, 9 do
		local name = m.name or ""
		if n > 1 then
			local tail = " " .. n
			name = Codec.Truncate(name, Codec.MACRO_LETTERS - #tail) .. tail
		end
		local any, same = E.FindMacro(scope, name, m.body)
		if same then return same end
		if not any or name == "" then return nil end
	end
	return nil
end

-- Whether a slot still holds what a layout's entry put there.
function E.Holds(slot, want, macros)
	local kind, id, sub = E.ActionInfo(slot)
	if kind == nil or type(want) ~= "table" then return false end
	local k = want[1]
	if k == "spell" then
		return kind == "spell" and type(id) == "number" and SameSpell(want, id, E.SpellName(id))
	elseif k == "item" then
		return kind == "item" and id == want[2]
	elseif k == "macro" then
		if kind ~= "macro" then return false end
		local index = MacroIndexOf(macros[want[2]])
		local inSlot, guess = E.MacroInSlot(slot, id, sub)
		return index ~= nil and inSlot == index and not guess
	elseif k == "mount" or k == "family" then
		return E.MountRank(want, slot) ~= nil
	end
	return false
end

-- The slots the previous layout filled that the new one does not name, still holding what the previous one put there.
function E.Leftovers(previous, layout)
	local out = {}
	if type(previous) ~= "table" or type(layout) ~= "table" then return out end
	previous = E.SlotMacros(previous)                      -- (its equipment-slot buttons are macros on the bars)
	local old = previous.specs and previous.specs[1] and previous.specs[1].slots or {}
	local new = layout.specs and layout.specs[1] and layout.specs[1].slots or {}
	local macros = {}
	for _, m in ipairs(previous.macros or {}) do macros[m.key] = m end
	for slot = 1, Codec.MAX_SLOT do
		local want = old[slot]
		if want ~= nil and want[1] ~= "empty" and new[slot] == nil and E.Holds(slot, want, macros) then out[#out + 1] = slot end
	end
	return out
end

-- Those slots emptied (out of a fight, the host's E.Apply). Returns how many.
function E.ClearLeftovers(previous, layout)
	local n = 0
	Call(ClearCursor)
	for _, slot in ipairs(E.Leftovers(previous, layout)) do
		Call(PickupAction, slot)
		Call(ClearCursor)
		n = n + 1
	end
	return n
end

-- Everything later at once, out of a fight and with nothing on the cursor (else nil: the host asks again then).
-- opts.auto: Auto rank on; opts.only: its slots; opts.layout: the layout applied (0.1.5: the game's pushes undone first).
-- Returns placed, swaps (swaps false: rank texts not loaded yet), the pushes undone (E.UndoPushes).
function E.Recheck(store, opts)
	opts = opts or {}
	if InCombatLockdown() or Holding() then return nil end
	store = E.Store(store)
	E.ForgetBook()
	local undone = E.UndoPushes(opts.layout, store)
	local placed = E.PlaceRemembered(store) + E.PlaceMounts(store)
	local swaps = 0
	if opts.auto ~= false then swaps = E.AutoRank(store, opts.only) end
	return placed, swaps, undone
end

-- The slots of a layout that do not hold what they should yet: a spell not known (remembered, its slot still empty), a
-- spell below the rank the layout plans (Auto rank: its `rank`; pinned: exactly its own), a Mount up with no mount
-- owned. A slot the player gave something else is his: not counted. Each { slot, want, rank = the rank in the slot now
-- (0: none) }, in slot order.
function E.PendingList(layout, store)
	local out = {}
	if type(layout) ~= "table" then return out end
	store = E.Store(store)
	local spec = layout.specs and layout.specs[1] or {}
	for slot = 1, Codec.MAX_SLOT do
		local want = spec.slots and spec.slots[slot]
		if want then
			local kind, id = E.ActionInfo(slot)
			if want[1] == "spell" then
				if kind == nil then
					if store.layoutWaiting[slot] then out[#out + 1] = { slot = slot, want = want, rank = 0 } end
				elseif kind == "spell" and type(id) == "number" then
					local name = want.name or E.SpellName(want[2])
					if id == want[2] then
						-- exactly the layout's spell: placed
					elseif name and E.SpellName(id) == name then
						-- (a spell of that name with no rank - Forever's own profession spells - has nothing to compare: placed)
						local rank, goal = E.RankOf(id), want.rank
						if rank == nil then
							-- placed
						elseif want.auto == false or (goal and rank < goal) then   -- a pinned rank not learnt yet; a rank below the plan
							out[#out + 1] = { slot = slot, want = want, rank = rank }
						end
					end
				end
			elseif want[1] == "mount" then                  -- (a family's items come and go: never waited on)
				if kind == nil and store.layoutMounts[slot] then out[#out + 1] = { slot = slot, want = want, rank = 0 } end
			end
		end
	end
	return out
end

function E.Pending(layout, store)
	return #E.PendingList(layout, store)
end

-- ============================================================
-- (HUI Presets 0.1.2; Harry, Oct 19: "i'm on a level 19 priest and it's saying 'Waiting on 18'. why?") TRAIN N: of the
-- slots still waiting, the spells the character can buy at its trainer NOW - a rank it does not know, above the one it
-- has, up to the rank the layout plans (pinned: exactly that rank), learnt at or below its level. The level is the
-- game's own (C_Spell.GetSpellLevelLearned; 0 = no level: a tome's, a quest's), else Ranks.lua's; the ranks between
-- come from Ranks.lua (ns.RANKS: the editor's data, per class and name - a layout names only the rank it plans). A
-- talent spell (Ranks.lua's t, the game's IsClassTalentSpell) and a rank no trainer sells on its own (x: a talent's, a
-- book's) never count. One per spell name, its highest rank to buy.
-- ============================================================
function E.MyLevel()
	local level = Plain(Call(UnitLevel, "player"))
	if type(level) == "number" and level >= 1 then return level end
	local max = Plain(Call(rawget(_G, "GetMaxPlayerLevel")))
	return type(max) == "number" and max or 60
end

-- The level a spell is learnt at, or nil (no level: never one to buy).
function E.LearnLevel(id, fallback)
	local fn = C_Spell and C_Spell.GetSpellLevelLearned or rawget(_G, "GetSpellLevelLearned")
	if type(fn) == "function" then
		local ok, level = pcall(fn, id)
		level = ok and Plain(level) or nil
		if type(level) == "number" then return level >= 1 and level or nil end
	end
	return type(fallback) == "number" and fallback >= 1 and fallback or nil
end

function E.IsTalentSpell(id)
	return Plain(C_Spell and Call(C_Spell.IsClassTalentSpell, id)) == true
end

-- A spell's ladder from Ranks.lua: { t, x = { [id] = true }, { id, rank, level }, ... } in rank order, or nil.
local ladders = {}
function E.Ladder(class, name)
	local all = ns.RANKS
	local list = type(all) == "table" and type(class) == "string" and type(all[class]) == "table" and all[class][name]
	if type(list) ~= "table" or type(name) ~= "string" then return nil end
	local key = class .. "\n" .. name
	if ladders[key] then return ladders[key] end
	local out = { t = list.t == 1, x = {} }
	for _, id in ipairs(type(list.x) == "table" and list.x or {}) do out.x[id] = true end
	for i = 1, #list - 2, 3 do out[#out + 1] = { id = list[i], rank = list[i + 1], level = list[i + 2] } end
	ladders[key] = out
	return out
end

-- The rank of a waiting slot's spell to buy now: { id, name, rank } or nil.
function E.BuyNow(class, want, have, level)
	if want[1] ~= "spell" or type(want[2]) ~= "number" then return nil end
	local name = want.name or E.SpellName(want[2])
	local ladder = E.Ladder(class, name)
	if E.IsTalentSpell(want[2]) or (ladder and ladder.t) then return nil end
	local goal
	local candidates = {}
	if ladder then
		for _, r in ipairs(ladder) do if r.id == want[2] then goal = r.rank end end
	end
	goal = goal or want.rank
	if want.auto == false or not ladder or not goal then
		candidates[1] = { id = want[2], rank = want.rank or goal or 0 }
	else
		-- above the highest rank the character knows of it (bought and not placed yet counts as had)
		local known = name and E.Book()[name]
		if known and known.rank > (have or 0) then have = known.rank end
		for i = #ladder, 1, -1 do
			local r = ladder[i]
			if r.rank <= goal and r.rank > (have or 0) then candidates[#candidates + 1] = r end
		end
	end
	for _, r in ipairs(candidates) do
		if not (ladder and ladder.x[r.id]) and not E.Known(r.id) and not E.IsTalentSpell(r.id) then
			local fallback
			if ladder then for _, l in ipairs(ladder) do if l.id == r.id then fallback = l.level end end end
			local at = E.LearnLevel(r.id, fallback)
			if at and at <= level then return { id = r.id, name = name or E.SpellName(r.id) or "?", rank = r.rank } end
		end
	end
	return nil
end

-- What to buy now for a layout: a list of { id, name, rank }, one per spell name, in slot order; and how many slots are
-- waiting at all (E.Pending).
function E.Trainable(layout, store, level)
	local pending = E.PendingList(layout, store)
	level = level or E.MyLevel()
	local out, at = {}, {}
	E.ForgetBook()
	for _, p in ipairs(pending) do
		local buy = E.BuyNow(layout.class, p.want, p.rank, level)
		if buy then
			local i = at[buy.name]
			if not i then
				out[#out + 1] = buy
				at[buy.name] = #out
			elseif buy.rank > out[i].rank then
				out[i] = buy
			end
		end
	end
	return out, #pending
end

-- The slots a layout puts spells in (Auto rank's opts.only for a host that keeps to its own layout's slots).
function E.SpellSlots(layout)
	local out = {}
	local spec = layout and layout.specs and layout.specs[1] or {}
	for slot, want in pairs(spec.slots or {}) do
		if want[1] == "spell" then out[slot] = true end
	end
	return out
end

-- ============================================================
-- (HUI Presets 0.1.2; Harry, Oct 19: "we also have no way of exporting a string from in-game") CAPTURE: the character's
-- bars as they are now, a layout the editor reads (LAYOUT-FORMAT.md v1) - COPIED from HUI Bars' Layouts.lua L.Capture
-- (0.16.1; HUI Bars' own copy unchanged; no `bars` or druid `options` here, they are HUI Bars' own) with the race kept,
-- Auto rank from this addon's store, and the keys read on any bar addon (below).
-- ============================================================
-- Every command a layout keeps keys for: bar 1 and the seven multi bars (HUI Bars' Buttons.COMMANDS), then the stance,
-- pet and extra buttons.
E.COMMAND_BARS = { "ACTIONBUTTON", "MULTIACTIONBAR1BUTTON", "MULTIACTIONBAR2BUTTON", "MULTIACTIONBAR3BUTTON",
	"MULTIACTIONBAR4BUTTON", "MULTIACTIONBAR5BUTTON", "MULTIACTIONBAR6BUTTON", "MULTIACTIONBAR7BUTTON" }
function E.Commands()
	local out = {}
	for _, bar in ipairs(E.COMMAND_BARS) do
		for i = 1, 12 do out[#out + 1] = bar .. i end
	end
	for i = 1, 10 do out[#out + 1] = "SHAPESHIFTBUTTON" .. i end
	for i = 1, 10 do out[#out + 1] = "BONUSACTIONBUTTON" .. i end
	out[#out + 1] = "EXTRAACTIONBUTTON1"
	return out
end

local function KeysOf(target)
	local plain = {}
	for _, k in ipairs({ Call(GetBindingKey, target) }) do
		k = Plain(k)
		if type(k) == "string" and k ~= "" then plain[#plain + 1] = k end
	end
	return plain
end

-- THE KEYS, the apply's mapping (E.Resolve) the other way round: each bar command's slot (bar 1: the page it shows now),
-- the button that shows that slot on the screen (or, hidden for now, whose bar is on), and the keys of the binding that
-- button answers (Bartender4's and ElvUI's keyBoundTarget or CLICK, Dominos' commandName ...), written under the game's
-- command. HUI Bars (opts.commands, or loaded) and the game's own bars answer the commands themselves: read as they are.
-- A bar addon's slot no button shows has no keys. The stance, pet and extra buttons: their own commands.
function E.CaptureKeys(opts)
	local keys = {}
	local huiBars = (opts and opts.commands) or E.Loaded("ForeverBars")
	local candidates = (not huiBars) and E.Candidates() or {}
	for _, cmd in ipairs(E.Commands()) do
		local target = cmd
		if not huiBars and E.SlotOfCommand(cmd) then target = E.Resolve(cmd, candidates, false) end
		if target then
			local list = KeysOf(target)
			if #list > 0 then
				keys[cmd] = {}
				for i = 1, math.min(#list, 4) do keys[cmd][i] = list[i] end
			end
		end
	end
	return keys
end

-- The layout of the bars now (sanitized), or nil and why. store: this addon's (its pins: a pinned slot is auto = false).
function E.Capture(name, store, opts)
	local class = E.MyClass()
	if not class then return nil, "no class" end
	store = E.Store(store)
	local layout = {
		v = Codec.VERSION, name = name, class = class, race = E.MyRace(), firstLogin = false,
		autoRankDefault = store.autoRankDefault ~= false, macros = {}, specs = { { slots = {}, keys = {} } },
	}
	local slots, keyOf = layout.specs[1].slots, {}
	for slot = 1, Codec.MAX_SLOT do
		local kind, id, sub = E.ActionInfo(slot)
		if kind == nil then
			if not E.HasActionAt(slot) then slots[slot] = { "empty" } end
		elseif kind == "spell" and type(id) == "number" then
			local e = { "spell", id, name = E.SpellName(id) }
			local rank = E.RankOf(id)
			if rank then e.rank, e.auto = rank, not E.IsPinned(store, slot) end
			slots[slot] = e
		elseif kind == "item" and type(id) == "number" then
			slots[slot] = { "item", id }
		elseif kind == "macro" then
			local index = E.MacroInSlot(slot, id, sub)
			local mname, icon, body
			if index then mname, icon, body = Call(GetMacroInfo, index) end
			mname, icon, body = Plain(mname), Plain(icon), Plain(body)
			if index and type(mname) == "string" then
				local key = keyOf[index]
				if not key then
					key = "m" .. (#layout.macros + 1)
					keyOf[index] = key
					layout.macros[#layout.macros + 1] = { key = key, name = mname,
						icon = type(icon) == "number" and icon or Codec.QUESTION_MARK, body = type(body) == "string" and body or "",
						scope = index > E.MAX_ACCOUNT and "character" or "account" }
				end
				slots[slot] = { "macro", key }
			end
		end
		-- anything else (an equipment set, a mount, a flyout) is not the format's: left out, so left alone on apply
	end
	layout.specs[1].keys = E.CaptureKeys(opts)
	return Codec.Sanitize(layout)
end
