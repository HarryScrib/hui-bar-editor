-- HUI kit (kit/ at the repo root; its change log is kit/KIT.md). Every addon's Kit\ holds a byte-identical copy made
-- by _tools/sync_kit.py: change kit/ and run the sync, never a copy in place.
local ADDON, ns = ...

-- ============================================================
-- FONT OBJECTS AND FAMILIES (kit/KIT.md 39 and 41, kit/BUILD-38-font-families.md, kit/BUILD-41-font-objects.md).
-- Harry, Oct 10: a Korean name in General chat drawn as boxes, "[][][][] is all i get". None of our files (Arial
-- Narrow, Friz, the bundled faces) has Hangul or Chinese. The game's own fonts are FAMILIES, one file per alphabet
-- (Blizzard_Fonts_Shared/Mainline/Fonts.xml), and the client's CreateFontFamily(name, members) makes one at runtime.
--
-- What the client does (Harry's /btafont rounds 1-4, Oct 11 - Kit 39 broke on the second):
--   - a text given a family by SetFontObject, never SetFont: draws Korean (GetFont reads the roman member)
--   - text:SetFont(file, ...) and THEN SetFontObject(family): the SetFont wins - boxes. A font set on the text itself
--     is never replaced by an object given later. SetFontObject after SetFontObject replaces.
--   - ONE member draws a whole string: a string with Hangul is all drawn by the korean member (its Latin too), so
--     Hangul + Hanzi in one string shows the Hanzi as boxes (real names are one script). Chinese: ARKai_T.ttf (the
--     tooltip header's file, which drew a Chinese name); ARHei.ttf may not be on this client.
--   - a text with no font errors on SetText; an invalid file raises from SetFont ("Invalid font asset").
--
-- So NO TEXT OF OURS IS EVER GIVEN A FONT BY SetFont. Every one is given a FONT OBJECT through here:
--
--   Fonts.Set(target, file, size, flags[, game])   in place of target:SetFont(file, size, flags): true when the file
--                                                  loaded, false when not (the target then untouched - the callers'
--                                                  fallbacks, e.g. Arial Narrow, read it)
--   Fonts.Get(target)        file, size, flags as last asked of Fonts.Set (else target:GetFont())
--   Fonts.Forget(target)     never touched again by a login's catch-up (a region handed back to the game)
--   Fonts.ShadowOffset(target, x, y)            in place of target:SetShadowOffset(x, y)
--   Fonts.ShadowColor(target, r, g, b[, a])     in place of target:SetShadowColor(r, g, b, a)
--   Fonts.Family(file, size, flags[, shadow])   the family object itself (nil where there is none)
--   Fonts.HasFamily(target)  is it drawn by one of our families now
--   Fonts.status             counts, for an addon's debug dump
--
-- The object: after PLAYER_LOGIN the FAMILY (our file in the client's own alphabet - roman on an English client - and
-- the game's files for the others); before it, or where there is no CreateFontFamily or it fails, a PLAIN font object
-- of ours (CreateFont, :SetFont(file, size, flags) under pcall - its answer is the "did it load" handed back). One of
-- each per (file, size, flags, shadow), made once and kept, named HUIFont_<addon>_<n>. At the login every target still
-- on a plain object of ours is moved to its family (SetFontObject replaces an object). A target may be a FontString,
-- an EditBox or a Font object of an addon's own (HUI Menus' tooltip and game menu fonts, HUI QoL's countdown face):
-- the Font is given the object the same way and the texts that use it follow.
--
-- SetFontObject takes everything from the object, so the text's colour, its justification and its spacing are read
-- before and set back after. Latin text is drawn by the same file at the same size: it looks exactly as it did.
--
-- Members, from the game's own families (Fonts.xml / GameFonts.xml) - a sans face (Arial Narrow, Roboto, every bundled
-- condensed face) as the chat window's ChatFontNormal: Korean 2002.TTF at 13/14 of the size, simplified Chinese
-- ARKai_T (Kit 41: the file seen drawing a Chinese name; ARHei may be missing), traditional arheiuhk_bd, Russian
-- ARIALN (it has Cyrillic); a Friz-like face (Friz, Marcellus, Philosopher) as the game's nameplate names
-- (SystemFont_NamePlate): 2002.TTF, ARKai_T, blei00d, FRIZQT___CYR, all at the size.
--
-- THE SHADOW lives on the object, not on the text: a text drawn by a family and given a shadow of its own loses it
-- (12.0.7 retail, seen by other addons). So every shadow in the suite is set through Fonts.ShadowOffset and
-- Fonts.ShadowColor: on a target drawn by one of our objects the shadow is remembered and the target given the object
-- with that shadow; on any other the target's own method, as before. The shadow a target already has when it is
-- first set here is carried into its object. No Lua field is ever written on a target (some are the game's: the chat
-- edit box, the minimap's words). `game` (the chat edit box): never taken for already set, as the game may set it.
--
-- Nothing here is protected: SetFontObject on our own texts. Secret values: a colour read back may be secret (a health
-- text's colour): it is handed back as it is, never compared.
-- ============================================================

local Fonts = ns.Fonts or {}
ns.Fonts = Fonts

local ALPHABETS = { "roman", "korean", "simplifiedchinese", "traditionalchinese", "russian" }
Fonts.ALPHABETS = ALPHABETS

-- [kind][alphabet] = { the game's file, its height as a share of the size }
Fonts.GAME = {
	sans = {
		roman = { "Fonts\\ARIALN.TTF", 1 },
		korean = { "Fonts\\2002.TTF", 13 / 14 },
		simplifiedchinese = { "Fonts\\ARKai_T.ttf", 1 },
		traditionalchinese = { "Fonts\\arheiuhk_bd.TTF", 1 },
		russian = { "Fonts\\ARIALN.TTF", 1 },
	},
	friz = {
		roman = { "Fonts\\FRIZQT__.TTF", 1 },
		korean = { "Fonts\\2002.TTF", 1 },
		simplifiedchinese = { "Fonts\\ARKai_T.ttf", 1 },
		traditionalchinese = { "Fonts\\blei00d.TTF", 1 },
		russian = { "Fonts\\FRIZQT___CYR.TTF", 1 },
	},
}
local FRIZ_LIKE = { "friz", "morpheus", "skurri", "marcellus", "philosopher" }

local LOCALE_ALPHABET = { koKR = "korean", zhCN = "simplifiedchinese", zhTW = "traditionalchinese", ruRU = "russian" }
local locale = type(GetLocale) == "function" and GetLocale() or "enUS"
Fonts.PRIMARY = LOCALE_ALPHABET[locale] or "roman"

-- objects: plain font objects made; failed: families refused; set: Fonts.Set calls; given: SetFontObject done;
-- moved: targets given a family; refused: SetFontObject raised; locked: a target that still reads another file after
-- it (a font set on it directly, by the game); missing: files that did not load; waiting: targets for the login
Fonts.status = { families = 0, objects = 0, failed = 0, set = 0, given = 0, moved = 0, refused = 0, locked = 0,
	missing = 0, waiting = 0, shadows = 0 }
local status = Fonts.status

local families = {}                                      -- [key] = family, or false: refused
local plains = {}                                        -- [key] = { obj, ok }: a plain object and did its file load
local state = setmetatable({}, { __mode = "k" })         -- [target] = { file, size, flags, game, sx.. sa, object, family }
local waiting = setmetatable({}, { __mode = "k" })       -- [target] = true: on a plain object until the login
local made = 0                                           -- names: HUIFont_<addon>_<n>, families and objects alike

function Fonts.Kind(file)
	local f = type(file) == "string" and file:lower() or ""
	for i = 1, #FRIZ_LIKE do
		if f:find(FRIZ_LIKE[i], 1, true) then return "friz" end
	end
	return "sans"
end

local function LoggedIn()
	if type(IsLoggedIn) ~= "function" then return true end
	return IsLoggedIn() and true or false
end

local function Usable()
	return type(CreateFontFamily) == "function"
end

local function Num(v)
	return type(v) == "number" and not (issecretvalue and issecretvalue(v))
end

local function Name()
	made = made + 1
	return "HUIFont_" .. ADDON .. "_" .. made
end

local function Key(file, size, flags, sh)
	local k = file .. "|" .. string.format("%.3f", size) .. "|" .. flags
	if sh then k = k .. "|" .. string.format("%.2f,%.2f,%.3f,%.3f,%.3f,%.3f", sh[1], sh[2], sh[3], sh[4], sh[5], sh[6]) end
	return k
end

local function Shade(obj, sh)
	if not obj or not sh then return end
	if obj.SetShadowOffset then pcall(obj.SetShadowOffset, obj, sh[1], sh[2]) end
	if obj.SetShadowColor then pcall(obj.SetShadowColor, obj, sh[3], sh[4], sh[5], sh[6]) end
end

-- A plain font object of ours: the file set on IT (a font object's own definition, as the game's XML fonts), never on
-- a text. Made once per key; a file that did not load is tried again on the same object next time, and one that did
-- is asked again when a target CHANGES to it (a face picked: a new file may not load before a restart) - never for a
-- new target on a known font (every text sharing the object would be laid out again).
local function Plain(file, size, flags, sh, recheck)
	local key = Key(file, size, flags, sh)
	local p = plains[key]
	if p and p.ok and not recheck then return p.obj, true end
	if not p then
		local ok, obj = pcall(CreateFont, Name())
		if not ok or not obj then return nil, false end
		pcall(obj.SetTextColor, obj, 1, 1, 1, 1)
		Shade(obj, sh)
		p = { obj = obj, ok = false }
		plains[key] = p
		status.objects = status.objects + 1
	end
	local ok, result = pcall(p.obj.SetFont, p.obj, file, size, flags)
	p.ok = ok and (result or (result == nil and p.obj:GetFont() ~= nil)) and true or false
	if not p.ok then status.missing = status.missing + 1 end
	return p.obj, p.ok
end

-- The game's files are loaded once by a font object of ours before a family names them (a family read before its
-- files are loaded is what crashed other addons at login).
local preloaded = {}
local function Preload(file)
	if preloaded[file] then return end
	preloaded[file] = true
	if type(CreateFont) == "function" then Plain(file, 12, "") end
end

-- sh: { x, y, r, g, b, a } or nil (no shadow of its own: the family's none)
function Fonts.Family(file, size, flags, sh)
	if not Usable() or type(file) ~= "string" or not Num(size) then return nil end
	flags = flags or ""
	local key = Key(file, size, flags, sh)
	local fam = families[key]
	if fam ~= nil then return fam or nil end
	local game = Fonts.GAME[Fonts.Kind(file)]
	local members = {}
	for i = 1, #ALPHABETS do
		local a = ALPHABETS[i]
		local mfile, height = file, size
		if a ~= Fonts.PRIMARY then
			mfile, height = game[a][1], size * game[a][2]
			Preload(mfile)
		end
		members[i] = { alphabet = a, file = mfile, height = height, flags = flags }
	end
	local ok, family = pcall(CreateFontFamily, Name(), members)
	if not ok or not family then
		status.failed = status.failed + 1
		families[key] = false
		return nil
	end
	status.families = status.families + 1
	pcall(family.SetTextColor, family, 1, 1, 1, 1)
	if sh then
		Shade(family, sh)
		if family.GetFontObjectForAlphabet then
			for i = 1, #ALPHABETS do
				local ok2, obj = pcall(family.GetFontObjectForAlphabet, family, ALPHABETS[i])
				if ok2 then Shade(obj, sh) end
			end
		end
	end
	families[key] = family
	return family
end

-- What the target shows now that SetFontObject would take from the object: read, then set back (never compared).
local function Pack(ok, ...)
	if ok ~= true or select("#", ...) == 0 then return nil end
	return { n = select("#", ...), ... }
end

local function Grab(target, method)
	local fn = target[method]
	if type(fn) ~= "function" then return nil end
	return Pack(pcall(fn, target))
end

local function Put(target, method, values)
	local fn = values and target[method]
	if type(fn) == "function" then pcall(fn, target, unpack(values, 1, values.n)) end
end

-- The shadow the target carries now, as its object's: only plain numbers, and only what was not set through us since
-- (none read: no shadow of its own).
local function ReadShadow(target, st)
	local off, col = Grab(target, "GetShadowOffset"), Grab(target, "GetShadowColor")
	if st.sx == nil and off and Num(off[1]) and Num(off[2]) then
		st.sx, st.sy = off[1], off[2]
	end
	if st.sr == nil and col and Num(col[1]) and Num(col[2]) and Num(col[3]) then
		st.sr, st.sg, st.sb, st.sa = col[1], col[2], col[3], Num(col[4]) and col[4] or 1
	end
end

local function ShadowOf(st)
	if st.sx == nil and st.sr == nil then return nil end
	return { st.sx or 0, st.sy or 0, st.sr or 0, st.sg or 0, st.sb or 0, st.sa or 1 }
end

local function Same(a, b)
	return type(a) == "string" and type(b) == "string" and a:lower():gsub("/", "\\") == b:lower():gsub("/", "\\")
end

-- The target given the object, its colour, justification and spacing kept.
local function Give(target, st, obj, family)
	local colour, h, v, spacing = Grab(target, "GetTextColor"), Grab(target, "GetJustifyH"), Grab(target, "GetJustifyV"),
		Grab(target, "GetSpacing")
	if not pcall(target.SetFontObject, target, obj) then
		status.refused = status.refused + 1
		return false
	end
	Put(target, "SetTextColor", colour)
	Put(target, "SetJustifyH", h)
	Put(target, "SetJustifyV", v)
	Put(target, "SetSpacing", spacing)
	st.object, st.family = obj, family
	status.given = status.given + 1
	if family then status.moved = status.moved + 1 end
	-- (a font the game set on the target itself wins over any object: counted for the debug dump, nothing more)
	if target.GetFont then
		local ok, now = pcall(target.GetFont, target)
		if ok and type(now) == "string" and not Same(now, st.file) then status.locked = status.locked + 1 end
	end
	return true
end

-- The object this target should have now: the family once logged in (where there is one), else the plain object.
-- Returns the plain object's answer (did the file load).
local function Apply(target, st, recheck)
	local sh = ShadowOf(st)
	local plain, ok = Plain(st.file, st.size, st.flags, sh, recheck)
	if not ok then return false end
	local family = LoggedIn() and Fonts.Family(st.file, st.size, st.flags, sh) or nil
	if family then
		waiting[target] = nil
		return Give(target, st, family, family)
	end
	if not Give(target, st, plain, nil) then return false end
	st.alone = LoggedIn()                                 -- logged in and still no family: the plain object is all
	if not LoggedIn() and Usable() then
		if not waiting[target] then status.waiting = status.waiting + 1 end
		waiting[target] = true
		Fonts.Watch()
	end
	return true
end

-- The shadow (above: THE SHADOW): remembered and carried into the object on a target drawn by one of ours, else the
-- target's own.
function Fonts.ShadowOffset(target, x, y)
	local st = state[target]
	if st and st.object and Num(x) and Num(y) then
		st.sx, st.sy = x, y
		status.shadows = status.shadows + 1
		Apply(target, st)
		return
	end
	return target:SetShadowOffset(x, y)
end

function Fonts.ShadowColor(target, r, g, b, a)
	local st = state[target]
	if st and st.object and Num(r) and Num(g) and Num(b) and (a == nil or Num(a)) then
		st.sr, st.sg, st.sb, st.sa = r, g, b, a or 1
		status.shadows = status.shadows + 1
		Apply(target, st)
		return
	end
	return target:SetShadowColor(r, g, b, a)
end

-- The login listened for only while something waits for it, and not after (an addon at rest listens to nothing).
function Fonts.Watch()
	if type(CreateFrame) ~= "function" then return end
	if not Fonts.watcher then
		local f = CreateFrame("Frame")
		f:SetScript("OnEvent", function() Fonts.CatchUp() end)
		Fonts.watcher = f
	end
	Fonts.watcher:RegisterEvent("PLAYER_LOGIN")
end

local function Current(target)
	if not target.GetFontObject then return nil end
	local ok, obj = pcall(target.GetFontObject, target)
	return ok and obj or nil
end

function Fonts.Set(target, file, size, flags, game)
	flags = flags or ""
	if type(file) ~= "string" or not Num(size) then return false end
	-- a client without font objects (none known): the old way, the only one there is
	if type(CreateFont) ~= "function" or type(target.SetFontObject) ~= "function" then
		return target:SetFont(file, size, flags)
	end
	status.set = status.set + 1
	local st = state[target]
	if st and st.object and not game and st.file == file and st.size == size and st.flags == flags
		and (st.family or st.alone or not LoggedIn() or not Usable()) and Current(target) == st.object then
		return true
	end
	local fresh = not st
	if fresh then st = {} end
	if not st.read then
		st.read = true
		ReadShadow(target, st)
	end
	local was = { st.file, st.size, st.flags, st.game }
	st.file, st.size, st.flags, st.game = file, size, flags, game and true or false
	if not Apply(target, st, not fresh and was[1] ~= file) then
		-- not loaded: the target as it was (a caller falls back to another file)
		st.file, st.size, st.flags, st.game = was[1], was[2], was[3], was[4]
		return false
	end
	if fresh then state[target] = st end
	return true
end

function Fonts.Get(target)
	local st = state[target]
	if st and st.file then return st.file, st.size, st.flags end
	if target and target.GetFont then return target:GetFont() end
end

function Fonts.Forget(target)
	state[target] = nil
	if waiting[target] then status.waiting = status.waiting - 1 end
	waiting[target] = nil
end

-- Is this target drawn by one of our families now?
function Fonts.HasFamily(target)
	local st = state[target]
	return st and st.family ~= nil or false
end

-- The login: every target still on a plain object of ours moved to its family (one given another object meanwhile -
-- the game's, a caller's fallback - is left with it).
function Fonts.CatchUp()
	local list = {}
	for target in pairs(waiting) do list[#list + 1] = target end
	for i = 1, #list do
		local target = list[i]
		waiting[target] = nil
		local st = state[target]
		if st and st.object and not st.family and Current(target) == st.object then Apply(target, st) end
	end
	status.waiting = 0
	if Fonts.watcher then Fonts.watcher:UnregisterEvent("PLAYER_LOGIN") end
	return #list
end
