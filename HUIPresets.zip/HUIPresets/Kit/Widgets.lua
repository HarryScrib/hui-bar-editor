-- HUI kit (kit/ at the repo root; its change log is kit/KIT.md). Every addon's Kit\ holds a byte-identical copy made
-- by _tools/sync_kit.py: change kit/ and run the sync, never a copy in place.
local ADDON, ns = ...

-- ============================================================
-- The suite's widget kit. Generic: nothing in this file knows about bags.
-- It needs only Skin.lua (colours, fonts, 9-slice helpers) and the media folder.
-- If the host addon has ns.Safe, every callback runs through it; otherwise pcall.
-- The kit options (kit/KIT.md "Kit options") are read from ns.KIT, which the host's Core.lua may set.
--
-- House rules the kit follows:
--   * No Blizzard templates (wrong look, and a taint risk).
--   * No outlines. A control is a lighter fill, a shadow, or both.
--   * Nothing runs while idle: the slider's OnUpdate exists only during a drag,
--     the dropdown's click-away watcher only while its list is open.
--   * Drag and wheel handlers allocate nothing. Text is only rewritten when a
--     value actually changes.
--
--   W.Button(parent, label, onClick, kind)           kind: nil (quiet) | "primary"
--   W.Checkbox(parent, onChange)                     :SetChecked(bool) :GetChecked()
--   W.Slider(parent, opts, onChange)                 opts = { min, max, step, unit, width, format }  :SetValue(n) :GetValue()
--   W.Segmented(parent, items, onSelect)             items = { { value, label }, ... }       :SetValue(v)
--   W.Dropdown(parent, width, items, onSelect)       items = { { value, label }, ... }       :SetValue(v) :Open() :Close()
--   W.ColorSwatch(parent, opts)                      opts = { get, set, isDefault, reset }   :Refresh()
--   W.Scroll(parent)                                 .child, :SetContentHeight(h), :SetOffset(y), .thumb, .track
--                                                    (ns.KIT.scroll = "marker": the first scroll, no .thumb / .track)
--   W.Sidebar(parent, items, onSelect)               items = { { id, label, gapAbove }, ... } :SetValue(id)
--   W.Page(parent, width)                            :Section(title) :Row(label, hint) -> row; row:SetControl(ctrl); row:SetRowShown(bool)
--                                                    (parent.pageColumns set: the hub's compartments in two columns, below)
--   W.LitRule(parent)                                a compartment's lit rule (the line; its glow follows it)
-- ============================================================

local Skin = ns.Skin
local C, A = Skin.C, Skin.A

local W = {}
ns.Widgets = W

local function Safe(fn, ...)
	if not fn then return end
	if ns.Safe then return ns.Safe(fn, ...) end
	return pcall(fn, ...)
end

local function SetFillAlpha(tex, alpha)
	tex:SetVertexColor(1, 1, 1, alpha)
end

local function SetTextColor(fs, color)
	fs:SetTextColor(color[1], color[2], color[3])
end

-- Soft drop shadow under a control. The texture has the control's rectangle cut
-- out, so it never darkens a translucent fill. The control must be at least 16px
-- in both directions (9-slice margins).
function W.Shadow(frame, alpha)
	local room = Skin.CTL_SHADOW_ROOM
	local t = Skin.Slice(frame, "ctlshadow", "BACKGROUND", -8)
	t:SetPoint("TOPLEFT", frame, "TOPLEFT", -room, room)
	t:SetPoint("BOTTOMRIGHT", frame, "BOTTOMRIGHT", room, -room)
	t:SetVertexColor(0, 0, 0, alpha or 1)
	return t
end

-- Shadow falling into the top edge of a field (fields, troughs, empty checkbox).
-- The control must be at least 12px in both directions.
function W.Inset(frame, alpha)
	local t = Skin.Slice(frame, "inset", "BACKGROUND", 1)
	t:SetAllPoints(frame)
	t:SetVertexColor(0, 0, 0, alpha or 0.75)
	return t
end

-- ============================================================
-- Button
-- ============================================================
local DARK = { 10 / 255, 10 / 255, 10 / 255 }
-- (Kit 50; Harry, Oct 15, of the group finder's Invite and Search: "i think this is the best kind of purple and dark ... to
-- have on dialogue / vendor confirmations or whatever. the ones we changed to purple earlier") a primary button is the
-- plain one (Search's dark plate, its pale word) with a soft purple wash laid over it: HUI Menus' group finder Invite
-- (GroupFinder\Pane.lua Button: the lift purple 158, 118, 238 at 18 %). Kit 49's solid purple plate is gone.
local LIFT, LIFT_A = { 158 / 255, 118 / 255, 238 / 255 }, 0.18

local function ButtonPaint(b)
	-- (Kit 50) the primary one paints as the plain one; its wash stays put
	SetFillAlpha(b.fill, b.down and A.buttonDown or (b.over and A.buttonHover or A.button))
	SetTextColor(b.text, b.over and C.text or C.body)
	b.text:SetPoint("CENTER", 0, b.down and -1 or 0)
end

function W.Button(parent, label, onClick, kind)
	local b = CreateFrame("Button", nil, parent)
	b.primary = kind == "primary"
	b.shadow = W.Shadow(b, b.primary and 1 or 0.8)
	b.fill = Skin.Fill(b, A.button)
	if b.primary then
		b.lit = Skin.Fill(b, LIFT_A, "BACKGROUND", 2)
		b.lit:SetVertexColor(LIFT[1], LIFT[2], LIFT[3], LIFT_A)
	end
	b.text = Skin.Text(b, "regular", 13, C.body, "CENTER")
	b.text:SetPoint("CENTER", 0, 0)
	b.text:SetText(label)
	local pad = b.primary and 28 or 18
	b:SetSize(math.ceil(b.text:GetStringWidth() or 40) + pad * 2, 32)

	b:SetScript("OnEnter", function(self) self.over = true; ButtonPaint(self) end)
	b:SetScript("OnLeave", function(self) self.over = false; self.down = false; ButtonPaint(self) end)
	b:SetScript("OnMouseDown", function(self) self.down = true; ButtonPaint(self) end)
	b:SetScript("OnMouseUp", function(self) self.down = false; ButtonPaint(self) end)
	b:SetScript("OnHide", function(self) self.over = false; self.down = false; ButtonPaint(self) end)
	b:SetScript("OnClick", function() Safe(onClick) end)
	ButtonPaint(b)
	return b
end

-- Small muted text that acts as a button ("reset").
function W.TextButton(parent, label, onClick)
	local b = CreateFrame("Button", nil, parent)
	b.text = Skin.Text(b, "regular", 11, C.mut, "CENTER")
	b.text:SetPoint("CENTER", 0, 0)
	b.text:SetText(label)
	b:SetSize(math.ceil(b.text:GetStringWidth() or 24) + 8, 20)
	b:SetScript("OnEnter", function(self) SetTextColor(self.text, C.text) end)
	b:SetScript("OnLeave", function(self) SetTextColor(self.text, C.mut) end)
	b:SetScript("OnClick", function() Safe(onClick) end)
	return b
end

-- ============================================================
-- Checkbox: 18px, a "shadowed well" (tools\make_checkbox.py): a recessed dark box with a
-- soft drop shadow, shadow falling in from its top edge, a lit lower lip and fine grain.
-- On = a white tick with its own small shadow sits in the well. Hover = the same well laid
-- over itself additively at low strength, so only its lit parts brighten (black adds nothing).
-- The textures are 64px with the box in the middle 32, drawn at 36px around the 18px button.
-- ============================================================
local function CheckboxPaint(c)
	c.tick:SetShown(c.checked)
	c.lift:SetShown(c.over and true or false)
end

function W.Checkbox(parent, onChange)
	local c = CreateFrame("Button", nil, parent)
	c:SetSize(18, 18)
	c:SetHitRectInsets(-6, -6, -6, -6)
	c.well = c:CreateTexture(nil, "BACKGROUND")
	c.well:SetTexture(Skin.TEX.check_well)
	c.well:SetSize(36, 36)
	c.well:SetPoint("CENTER", 0, 0)
	c.lift = c:CreateTexture(nil, "BORDER")
	c.lift:SetTexture(Skin.TEX.check_well)
	c.lift:SetBlendMode("ADD")
	c.lift:SetAlpha(0.35)
	c.lift:SetAllPoints(c.well)
	c.tick = c:CreateTexture(nil, "ARTWORK")
	c.tick:SetTexture(Skin.TEX.check_tick)
	c.tick:SetAllPoints(c.well)
	c.checked = false

	function c:SetChecked(value)
		self.checked = value and true or false
		CheckboxPaint(self)
	end
	function c:GetChecked()
		return self.checked
	end

	c:SetScript("OnEnter", function(self) self.over = true; CheckboxPaint(self) end)
	c:SetScript("OnLeave", function(self) self.over = false; CheckboxPaint(self) end)
	c:SetScript("OnClick", function(self)
		self:SetChecked(not self.checked)
		Safe(onChange, self.checked)
	end)
	CheckboxPaint(c)
	return c
end

-- Is this control made in a row of a page in compartments (the HUI settings hub, kit/KIT.md 14)? There the slider and
-- the segmented choice take the mockup's sizes (.sl 186 wide; .seg 22 high, 10 either side of a word, 12.5 type), so
-- a six-way choice fits a 346 column. Everywhere else they are exactly what they were.
local function InCompartment(parent)
	local page = type(parent) == "table" and parent.page
	return type(page) == "table" and page.columns == true
end

-- ============================================================
-- Slider: slim 4px groove, light fill, small rectangular grip, value at the right.
-- ============================================================
local GRIP_HALF = 4      -- half the grip's 8px width: the grip never overhangs the groove
local VALUE_WIDTH = 42
local VALUE_GAP = 14

local function SliderPlace(s)
	local span = s.max - s.min
	local frac = span > 0 and (s.value - s.min) / span or 0
	local x = GRIP_HALF + frac * (s.trackWidth - GRIP_HALF * 2)
	s.fill:SetWidth(math.max(x, 1))
	s.fillShine:SetWidth(math.max(x, 1))
	s.grip:SetPoint("CENTER", s.track, "LEFT", x, 0)
end

-- Snaps, clamps, stores. Returns true if the value changed.
local function SliderStore(s, value)
	local step = s.step
	value = s.min + math.floor((value - s.min) / step + 0.5) * step
	if value < s.min then value = s.min end
	if value > s.max then value = s.max end
	if value == s.value then return false end
	s.value = value
	if s.format then
		-- opts.format(value) -> the label's text, and optionally a FACES key the label keeps for it (a
		-- sign the chosen face may lack); nil follows the chosen face again.
		local text, face = s.format(value)
		if face ~= s.numberFace then
			s.numberFace = face
			Skin.ApplyFont(s.number, "regular", 13, nil, face)
		end
		s.number:SetText(text)
	else
		s.number:SetText(value)
	end
	SliderPlace(s)
	return true
end

local function SliderFromCursor(s)
	local track = s.track
	local cursorX = GetCursorPosition()
	local scale = track:GetEffectiveScale()
	local left = track:GetLeft()
	if not cursorX or not scale or scale <= 0 or not left then return end
	local usable = s.trackWidth - GRIP_HALF * 2
	local frac = (cursorX / scale - left - GRIP_HALF) / usable
	if frac < 0 then frac = 0 elseif frac > 1 then frac = 1 end
	if SliderStore(s, s.min + frac * (s.max - s.min)) then
		Safe(s.onChange, s.value)
	end
end

-- One shared function; it is a track's OnUpdate only while that track is being dragged.
local function SliderDragUpdate(track)
	local s = track.slider
	if IsMouseButtonDown and not IsMouseButtonDown("LeftButton") then
		track:SetScript("OnUpdate", nil)
		s.dragging = false
		return
	end
	SliderFromCursor(s)
end

function W.Slider(parent, opts, onChange)
	local s = CreateFrame("Frame", nil, parent)
	-- (in a page in compartments, the mockup's .sl: 186 wide unless the caller says)
	local width = opts.width or (InCompartment(parent) and 186) or 252
	s:SetSize(width, 22)
	s.min, s.max, s.step = opts.min, opts.max, opts.step or 1
	s.onChange = onChange
	s.format = opts.format
	s.trackWidth = width - VALUE_WIDTH - VALUE_GAP
	s.value = nil

	-- value, right-aligned on the slider's right edge: number in the text colour, unit muted
	if opts.unit then
		s.unit = Skin.Text(s, "regular", 11, C.mut, "RIGHT")
		s.unit:SetPoint("RIGHT", s, "RIGHT", 0, -1)
		s.unit:SetText(opts.unit)
	end
	s.number = Skin.Text(s, "regular", 13, C.text, "RIGHT")
	if s.unit then
		s.number:SetPoint("RIGHT", s.unit, "LEFT", -1, 1)
	else
		s.number:SetPoint("RIGHT", s, "RIGHT", 0, 0)
	end

	-- the track is the hit area: full height, so it is easy to grab
	local track = CreateFrame("Frame", nil, s)
	track:SetPoint("LEFT", s, "LEFT", 0, 0)
	track:SetSize(s.trackWidth, 22)
	track:EnableMouse(true)
	track.slider = s
	s.track = track

	s.groove = track:CreateTexture(nil, "BACKGROUND")
	s.groove:SetColorTexture(1, 1, 1, 0.10)
	s.groove:SetHeight(4)
	s.groove:SetPoint("LEFT", track, "LEFT", 0, 0)
	s.groove:SetPoint("RIGHT", track, "RIGHT", 0, 0)

	-- fill: mid grey, with a white ramp over it so it brightens toward the grip
	s.fill = track:CreateTexture(nil, "BORDER")
	s.fill:SetColorTexture(0x8e / 255, 0x8e / 255, 0x8e / 255, 1)
	s.fill:SetHeight(4)
	s.fill:SetPoint("LEFT", track, "LEFT", 0, 0)
	s.fillShine = track:CreateTexture(nil, "BORDER", nil, 1)
	s.fillShine:SetTexture(Skin.TEX.fade_h)
	s.fillShine:SetVertexColor(0xf2 / 255, 0xf2 / 255, 0xf2 / 255, 1)
	s.fillShine:SetHeight(4)
	s.fillShine:SetPoint("LEFT", track, "LEFT", 0, 0)

	-- grip.tga is 32x32 with an 8x18 rectangle and its shadow in the middle
	s.grip = track:CreateTexture(nil, "ARTWORK")
	s.grip:SetTexture(Skin.TEX.grip)
	s.grip:SetSize(32, 32)

	function s:SetValue(value)
		if type(value) ~= "number" then return end
		SliderStore(self, value)
	end
	function s:GetValue()
		return self.value
	end

	track:SetScript("OnMouseDown", function(self, button)
		if button ~= "LeftButton" then return end
		s.dragging = true
		SliderFromCursor(s)
		self:SetScript("OnUpdate", SliderDragUpdate)
	end)
	track:SetScript("OnMouseUp", function(self)
		s.dragging = false
		self:SetScript("OnUpdate", nil)
	end)
	track:SetScript("OnHide", function(self)
		s.dragging = false
		self:SetScript("OnUpdate", nil)
	end)

	-- (Harry, Oct 19: "don't let me change these kinds of sliders ... with mouse wheel, because if i'm scrolling down and
	-- pass a slider it tends to start sliding") no wheel: it passes through to the page's scroll
	s:EnableMouseWheel(false)

	s.value = s.min - 1 -- forces the first SetValue to draw
	s:SetValue(opts.min)
	return s
end

-- ============================================================
-- Segmented choice: a trough with the chosen option as a lighter plate.
-- ============================================================
function W.Segmented(parent, items, onSelect, opts)
	local compact = (opts and opts.compact) or InCompartment(parent)
	local PAD, SEG_HEIGHT, SEG_PAD = 3, compact and 22 or 24, compact and 10 or 14
	local seg = CreateFrame("Frame", nil, parent)
	seg.fill = Skin.Fill(seg, A.field)
	seg.inset = W.Inset(seg)
	seg.buttons = {}

	local x = PAD
	for i, item in ipairs(items) do
		local b = CreateFrame("Button", nil, seg)
		b.value = item[1]
		b.shadow = W.Shadow(b, 0.7)
		b.plate = Skin.Fill(b, A.plate)
		-- (Harry, Oct 14: the chosen one in the suite's button purple, D1 - "it looks nicer ... consistent across the full set
		-- of settings"; was a lighter grey plate)
		b.plate:SetVertexColor(103 / 255, 53 / 255, 167 / 255, 1)
		b.text = Skin.Text(b, "regular", compact and 12.5 or 13, C.mut, "CENTER")
		b.text:SetPoint("CENTER", 0, 0)
		b.text:SetText(item[2])
		local width = math.ceil(b.text:GetStringWidth() or 30) + SEG_PAD * 2
		b:SetSize(width, SEG_HEIGHT)
		b:SetPoint("LEFT", seg, "LEFT", x, 0)
		x = x + width

		b:SetScript("OnEnter", function(self)
			if not self.selected then SetTextColor(self.text, C.body) end
		end)
		b:SetScript("OnLeave", function(self)
			if not self.selected then SetTextColor(self.text, C.mut) end
		end)
		b:SetScript("OnClick", function(self)
			if self.selected then return end
			seg:SetValue(self.value)
			Safe(onSelect, self.value)
		end)
		seg.buttons[i] = b
	end
	seg:SetSize(x + PAD, SEG_HEIGHT + PAD * 2)

	function seg:SetValue(value)
		self.value = value
		for _, b in ipairs(self.buttons) do
			local on = b.value == value
			b.selected = on
			b.plate:SetShown(on)
			b.shadow:SetShown(on)
			if on then
				b.text:SetTextColor(1, 1, 1)
			else
				SetTextColor(b.text, C.mut)
			end
		end
	end
	seg:SetValue(nil)
	return seg
end

-- ============================================================
-- Dropdown: a field with the current value and a chevron. The list is one shared
-- popup frame (FULLSCREEN_DIALOG), in the same black look. It closes on
-- selection, on Escape, on a click anywhere else, and when its field hides.
-- ============================================================
local popup
local POPUP_ITEM, POPUP_PAD = 26, 5

local function IsInside(frame, a, b)
	while frame do
		if frame == a or frame == b then return true end
		frame = frame.GetParent and frame:GetParent() or nil
	end
	return false
end

local function ClosePopup()
	if popup and popup:IsShown() then popup:Hide() end
end

local function GetPopup()
	if popup then return popup end
	popup = CreateFrame("Frame", nil, UIParent)
	popup:Hide()
	popup:SetFrameStrata("FULLSCREEN_DIALOG")
	popup:SetToplevel(true)
	popup:EnableMouse(true)
	popup:SetClampedToScreen(true)
	popup.skinMinAlpha = 0.96 -- a list over other controls has to stay readable
	Skin.Panel(popup, { glowReach = 24, glowKey = "dropdowns" })
	popup.items = {}

	-- Click-away: the event is registered only while the list is open.
	popup:SetScript("OnEvent", function(self)
		local inside = false
		if GetMouseFoci then
			local foci = GetMouseFoci()
			for i = 1, #foci do
				if IsInside(foci[i], self, self.owner) then inside = true end
			end
		elseif GetMouseFocus then
			inside = IsInside(GetMouseFocus(), self, self.owner)
		end
		if not inside then self:Hide() end
	end)
	popup:SetScript("OnShow", function(self)
		self:RegisterEvent("GLOBAL_MOUSE_DOWN")
		-- Escape closes just the list. Key propagation may not be changed in combat,
		-- so in combat the keyboard is left alone (Escape then closes the window behind,
		-- whose OnHide closes this list).
		self.keys = false
		if not InCombatLockdown() then
			local ok = pcall(self.SetPropagateKeyboardInput, self, true)
			if ok then
				self:EnableKeyboard(true)
				self.keys = true
			end
		end
	end)
	popup:SetScript("OnHide", function(self)
		self:UnregisterEvent("GLOBAL_MOUSE_DOWN")
		if self.keys then
			self:EnableKeyboard(false)
			self.keys = false
		end
		local owner = self.owner
		self.owner = nil
		if owner then owner:PaintOpen(false) end
	end)
	popup:SetScript("OnKeyDown", function(self, key)
		if not self.keys or InCombatLockdown() then return end
		local isEscape = key == "ESCAPE"
		pcall(self.SetPropagateKeyboardInput, self, not isEscape)
		if isEscape then self:Hide() end
	end)
	return popup
end

local function PopupItem(index)
	local p = GetPopup()
	local b = p.items[index]
	if b then return b end
	b = CreateFrame("Button", nil, p)
	b:SetHeight(POPUP_ITEM)
	b.hover = Skin.Fill(b, A.button)
	b.hover:Hide()
	b.text = Skin.Text(b, "regular", 13, C.body)
	b.text:SetPoint("LEFT", b, "LEFT", 9, 0)
	b.text:SetPoint("RIGHT", b, "RIGHT", -9, 0)
	b:SetScript("OnEnter", function(self) self.hover:Show() end)
	b:SetScript("OnLeave", function(self) self.hover:Hide() end)
	b:SetScript("OnHide", function(self) self.hover:Hide() end)
	b:SetScript("OnClick", function(self)
		local owner = p.owner
		p:Hide()
		if owner then
			owner:SetValue(self.value)
			Safe(owner.onSelect, self.value)
		end
	end)
	p.items[index] = b
	return b
end

function W.Dropdown(parent, width, items, onSelect)
	local d = CreateFrame("Button", nil, parent)
	d:SetSize(width or 168, 30)
	d.items, d.onSelect = items, onSelect
	d.fill = Skin.Fill(d, A.field)
	d.inset = W.Inset(d)
	d.chevron = Skin.Icon(d, "chevron", 12, C.mut)
	d.chevron:SetPoint("RIGHT", d, "RIGHT", -9, 0)
	d.text = Skin.Text(d, "regular", 13, C.body)
	d.text:SetPoint("LEFT", d, "LEFT", 12, 0)
	d.text:SetPoint("RIGHT", d.chevron, "LEFT", -6, 0)

	function d:PaintOpen(open)
		SetFillAlpha(self.fill, (open or self.over) and A.fieldHover or A.field)
	end
	function d:SetValue(value)
		self.value = value
		local label = ""
		for _, item in ipairs(self.items) do
			if item[1] == value then label = item[2] end
		end
		self.text:SetText(label)
	end
	function d:Close()
		if popup and popup.owner == self then ClosePopup() end
	end
	function d:Open()
		local p = GetPopup()
		if p:IsShown() then p:Hide() end
		p.owner = self
		-- The list lives under UIParent; match the field if its window is scaled.
		local own, base = self:GetEffectiveScale(), UIParent:GetEffectiveScale()
		p:SetScale((own and base and base > 0) and own / base or 1)
		local n = #self.items
		p:SetSize(self:GetWidth(), n * POPUP_ITEM + POPUP_PAD * 2)
		p:ClearAllPoints()
		p:SetPoint("TOPLEFT", self, "BOTTOMLEFT", 0, -4)
		for i, item in ipairs(self.items) do
			local b = PopupItem(i)
			b.value = item[1]
			-- item.face: show this entry in a face of its own (the font list). Pooled items are
			-- shared by every dropdown, so each one is re-dressed every time a list opens.
			Skin.ApplyFont(b.text, "regular", 13, nil, item.face)
			b.text:SetText(item[2])
			if item[1] == self.value then
				b.text:SetTextColor(1, 1, 1)
			else
				SetTextColor(b.text, C.body)
			end
			b:ClearAllPoints()
			b:SetPoint("TOPLEFT", p, "TOPLEFT", POPUP_PAD, -(POPUP_PAD + (i - 1) * POPUP_ITEM))
			b:SetPoint("RIGHT", p, "RIGHT", -POPUP_PAD, 0)
			b:Show()
		end
		for i = n + 1, #p.items do p.items[i]:Hide() end
		self:PaintOpen(true)
		p:Show()
		p:Raise()
	end

	d:SetScript("OnEnter", function(self) self.over = true; self:PaintOpen(popup and popup.owner == self) end)
	d:SetScript("OnLeave", function(self) self.over = false; self:PaintOpen(popup and popup.owner == self) end)
	d:SetScript("OnHide", function(self) self:Close() end)
	d:SetScript("OnClick", function(self)
		if popup and popup:IsShown() and popup.owner == self then
			ClosePopup()
		else
			Safe(self.Open, self)
		end
	end)
	d:SetValue(nil)
	return d
end

W.CloseDropdowns = ClosePopup

-- The shared list frame, or nil if no dropdown has been opened yet.
function W.GetDropdownPopup()
	return popup
end

-- ============================================================
-- Colour swatch: 19px square of the colour, opens the game's colour picker.
-- Verified in Blizzard_ColorPickerFrame/Mainline/ColorPickerFrame.lua (1.60.1):
--   ColorPickerFrame:SetupColorPickerAndShow(info) with info.r/g/b, info.hasOpacity,
--   info.swatchFunc() (called with no arguments on every change; read the value
--   with ColorPickerFrame:GetColorRGB()) and info.cancelFunc(previousValues),
--   where previousValues = { r, g, b, a }. Cancel, Escape and a click outside the
--   picker all call cancelFunc.
-- opts = { get = function() return r, g, b end, set = function(r, g, b) end,
--          isDefault = function() return bool end, reset = function() end }
-- ============================================================
function W.ColorSwatch(parent, opts)
	local f = CreateFrame("Frame", nil, parent)

	local swatch = CreateFrame("Button", nil, f)
	swatch:SetSize(19, 19)
	swatch:SetPoint("RIGHT", f, "RIGHT", 0, 0)
	swatch.shadow = W.Shadow(swatch, 0.8)
	swatch.fill = Skin.Fill(swatch, 1)
	swatch.hover = Skin.Fill(swatch, 0.18, "BACKGROUND", 2)
	swatch.hover:Hide()
	f.swatch = swatch

	local reset = W.TextButton(f, "reset", function()
		opts.reset()
		f:Refresh()
	end)
	reset:SetPoint("RIGHT", swatch, "LEFT", -8, 0)
	f.resetButton = reset
	f:SetSize(19 + 8 + reset:GetWidth(), 22)

	function f:Refresh()
		local r, g, b = opts.get()
		swatch.fill:SetVertexColor(r, g, b, 1)
		reset:SetShown(not opts.isDefault())
	end

	local function Apply(r, g, b)
		opts.set(r, g, b)
		f:Refresh()
	end

	swatch:SetScript("OnEnter", function(self) self.hover:Show() end)
	swatch:SetScript("OnLeave", function(self) self.hover:Hide() end)
	swatch:SetScript("OnClick", function()
		Safe(function()
			local picker = ColorPickerFrame
			if not picker or not picker.SetupColorPickerAndShow then
				error("ColorPickerFrame:SetupColorPickerAndShow is missing on this client")
			end
			local r, g, b = opts.get()
			picker:SetupColorPickerAndShow({
				r = r, g = g, b = b,
				hasOpacity = false,
				swatchFunc = function()
					local nr, ng, nb = picker:GetColorRGB()
					if nr then Safe(Apply, nr, ng, nb) end
				end,
				cancelFunc = function(previous)
					if type(previous) == "table" and previous.r then
						Safe(Apply, previous.r, previous.g, previous.b)
					else
						Safe(Apply, r, g, b)
					end
				end,
			})
			-- The picker and a DIALOG window share a strata; make sure it is on top.
			if picker.Raise then picker:Raise() end
		end)
	end)

	f:Refresh()
	return f
end

-- ============================================================
-- Scroll container: the mouse wheel anywhere over it, and a slim bar at its right (HUI Journal, kit/KIT.md 8):
-- the 3px line is the thumb's look, but the thumb is grabbed in an invisible BAR_HIT wide area its own height
-- and a few px more; hovered or dragged it widens and turns pearl. A click on the bar's track pages toward the
-- click. The bar is mouse-enabled and takes no drag, so pressing on it never moves the window behind.
-- The thumb's OnUpdate exists only while it is dragged. No scrollbar art.
-- KIT OPTION (kit/KIT.md 11): a host whose Core.lua sets ns.KIT = { scroll = "marker" } keeps the kit's FIRST
-- scroll instead, the one every copy had before the bar: the mouse wheel plus a thin 3px position marker, nothing
-- to grab (MarkerScroll below, unchanged). HUI Bars and HUI Quests set it: they had that scroll, and moving them to
-- the bar is a visible change for later.
-- ============================================================
local WHEEL_STEP = 42
local BAR_HIT = 18          -- the thumb's and the track's grab width
local BAR_W, BAR_W_HOT = 3, 5
local THUMB_PAD = 3         -- the grab area reaches this far above and below the thumb
local PAGE = 0.9            -- a track click pages this much of the view
local PEARL = { 239 / 255, 237 / 255, 248 / 255 }   -- the suite's L2

local function PaintThumb(thumb)
	local hot = thumb.over or thumb.dragging
	local line = thumb.line
	line:SetWidth(hot and BAR_W_HOT or BAR_W)
	if hot then
		line:SetColorTexture(PEARL[1], PEARL[2], PEARL[3], 0.6)
	else
		line:SetColorTexture(1, 1, 1, 0.16)
	end
end

-- Cursor y in the scroll frame's own units.
local function CursorY(frame)
	local _, y = GetCursorPosition()
	local scale = frame:GetEffectiveScale()
	if not y or not scale or scale <= 0 then return nil end
	return y / scale
end

local function ThumbUpdate(thumb)
	local scroll = thumb.scroll
	if IsMouseButtonDown and not IsMouseButtonDown("LeftButton") then
		thumb:StopDrag()
		return
	end
	local y = CursorY(scroll)
	if not y or not thumb.startY then return end
	local range, view = scroll:GetRange()
	local travel = math.max(1, view - (thumb.size or 0))
	scroll:SetOffset(thumb.startOffset + (thumb.startY - y) * range / travel)
end

-- The first scroll (ns.KIT.scroll = "marker"): mouse wheel plus a thin 3px position marker. No scrollbar art.
local function MarkerScroll(parent)
	local scroll = CreateFrame("ScrollFrame", nil, parent)
	scroll:EnableMouseWheel(true)

	local child = CreateFrame("Frame", nil, scroll)
	child:SetSize(10, 10)
	scroll:SetScrollChild(child)
	scroll.child = child
	scroll.contentHeight = 0
	scroll.offset = 0

	local marker = scroll:CreateTexture(nil, "OVERLAY")
	marker:SetColorTexture(1, 1, 1, 0.16)
	marker:SetWidth(3)
	marker:Hide()
	scroll.marker = marker

	function scroll:GetRange()
		local view = self:GetHeight() or 0
		if view <= 0 then return 0, 0 end
		return math.max(0, self.contentHeight - view), view
	end

	function scroll:SetOffset(y)
		local range, view = self:GetRange()
		if y < 0 then y = 0 elseif y > range then y = range end
		self.offset = y
		self:SetVerticalScroll(y)
		if range <= 0 then
			marker:Hide()
			return
		end
		local size = math.max(24, view * view / self.contentHeight)
		marker:SetHeight(size)
		marker:ClearAllPoints()
		marker:SetPoint("TOPRIGHT", self, "TOPRIGHT", -6, -(view - size) * (y / range))
		marker:Show()
	end

	function scroll:SetContentHeight(height)
		self.contentHeight = height
		child:SetHeight(math.max(height, 1))
		self:SetOffset(self.offset)
	end

	scroll:SetScript("OnMouseWheel", function(self, delta)
		self:SetOffset(self.offset - delta * WHEEL_STEP)
	end)
	scroll:SetScript("OnSizeChanged", function(self, width)
		if width and width > 0 then child:SetWidth(width) end
		self:SetOffset(self.offset)
	end)
	scroll:SetScript("OnShow", function(self) self:SetOffset(self.offset) end)
	return scroll
end

-- The grabbable bar (the default).
local function BarScroll(parent)
	local scroll = CreateFrame("ScrollFrame", nil, parent)
	scroll:EnableMouseWheel(true)

	local child = CreateFrame("Frame", nil, scroll)
	child:SetSize(10, 10)
	scroll:SetScrollChild(child)
	scroll.child = child
	scroll.contentHeight = 0
	scroll.offset = 0

	local function Wheel(_, delta) scroll:SetOffset(scroll.offset - delta * WHEEL_STEP) end

	-- the track: the bar's whole height; a click there pages toward the click
	local track = CreateFrame("Button", nil, scroll)
	track:SetWidth(BAR_HIT)
	track:SetPoint("TOPRIGHT", scroll, "TOPRIGHT", 0, 0)
	track:SetPoint("BOTTOMRIGHT", scroll, "BOTTOMRIGHT", 0, 0)
	track:SetFrameLevel(child:GetFrameLevel() + 40)
	track:EnableMouse(true)
	track:EnableMouseWheel(true)
	track:SetScript("OnMouseWheel", Wheel)
	track:SetScript("OnMouseDown", function(self, button)
		if button ~= "LeftButton" then return end
		local y, top, bottom = CursorY(scroll), scroll.thumb:GetTop(), scroll.thumb:GetBottom()
		if not y or not top or not bottom then return end
		local _, view = scroll:GetRange()
		if y > top then
			scroll:SetOffset(scroll.offset - view * PAGE)
		elseif y < bottom then
			scroll:SetOffset(scroll.offset + view * PAGE)
		end
	end)
	track:Hide()
	scroll.track = track

	-- the thumb: grabbed in its BAR_HIT wide area, the slim line its look
	local thumb = CreateFrame("Button", nil, track)
	thumb:SetWidth(BAR_HIT)
	thumb:SetFrameLevel(track:GetFrameLevel() + 1)
	thumb:EnableMouse(true)
	thumb:EnableMouseWheel(true)
	thumb.scroll = scroll
	local line = thumb:CreateTexture(nil, "OVERLAY")
	thumb.line = line
	function thumb:StopDrag()
		self.dragging = false
		self:SetScript("OnUpdate", nil)
		PaintThumb(self)
	end
	thumb:SetScript("OnMouseWheel", Wheel)
	thumb:SetScript("OnEnter", function(self) self.over = true; PaintThumb(self) end)
	thumb:SetScript("OnLeave", function(self) self.over = false; PaintThumb(self) end)
	thumb:SetScript("OnMouseDown", function(self, button)
		if button ~= "LeftButton" then return end
		self.startY = CursorY(scroll)
		self.startOffset = scroll.offset
		self.dragging = true
		self:SetScript("OnUpdate", ThumbUpdate)
		PaintThumb(self)
	end)
	thumb:SetScript("OnMouseUp", function(self) self:StopDrag() end)
	thumb:SetScript("OnHide", function(self) if self.dragging then self:StopDrag() end end)
	PaintThumb(thumb)
	scroll.thumb = thumb
	scroll.marker = line       -- the visible line (the name the callers know)

	function scroll:GetRange()
		local view = self:GetHeight() or 0
		if view <= 0 then return 0, 0 end
		return math.max(0, self.contentHeight - view), view
	end

	function scroll:SetOffset(y)
		local range, view = self:GetRange()
		if y < 0 then y = 0 elseif y > range then y = range end
		self.offset = y
		self:SetVerticalScroll(y)
		if range <= 0 then
			track:Hide()
			return
		end
		-- the line where the list is; its grab area THUMB_PAD more each way, kept inside the track
		local size = math.max(24, view * view / self.contentHeight)
		local lineTop = (view - size) * (y / range)
		local hitTop, hitBottom = math.max(0, lineTop - THUMB_PAD), math.min(view, lineTop + size + THUMB_PAD)
		thumb.size = size
		thumb:SetHeight(hitBottom - hitTop)
		thumb:ClearAllPoints()
		thumb:SetPoint("TOP", track, "TOP", 0, -hitTop)
		line:SetHeight(size)
		line:ClearAllPoints()
		line:SetPoint("TOP", thumb, "TOP", 0, -(lineTop - hitTop))
		track:Show()
	end

	function scroll:SetContentHeight(height)
		self.contentHeight = height
		child:SetHeight(math.max(height, 1))
		self:SetOffset(self.offset)
	end

	scroll:SetScript("OnMouseWheel", Wheel)
	scroll:SetScript("OnSizeChanged", function(self, width)
		if width and width > 0 then child:SetWidth(width) end
		self:SetOffset(self.offset)
	end)
	scroll:SetScript("OnShow", function(self) self:SetOffset(self.offset) end)
	return scroll
end

function W.Scroll(parent)
	if ns.KIT and ns.KIT.scroll == "marker" then return MarkerScroll(parent) end
	return BarScroll(parent)
end

-- ============================================================
-- Sidebar category list. The current one is a lighter plate with a soft shadow.
-- ============================================================
function W.Sidebar(parent, items, onSelect)
	local ITEM_HEIGHT, SIDE_PAD, TOP_PAD = 32, 10, 14
	local bar = CreateFrame("Frame", nil, parent)
	bar.buttons = {}

	local y = TOP_PAD
	for i, item in ipairs(items) do
		local b = CreateFrame("Button", nil, bar)
		b.value = item[1]
		b:SetHeight(ITEM_HEIGHT)
		-- item[3]: extra space above this entry, to set it apart from the group before it
		y = y + (item[3] or 0)
		b:SetPoint("TOPLEFT", bar, "TOPLEFT", SIDE_PAD, -y)
		y = y + ITEM_HEIGHT + 1
		b:SetPoint("RIGHT", bar, "RIGHT", -SIDE_PAD, 0)
		b.shadow = W.Shadow(b, 0.8)
		b.plate = Skin.Fill(b, 0.085)
		b.hover = Skin.Fill(b, 0.035)
		b.hover:Hide()
		b.text = Skin.Text(b, "regular", 13, C.mut)
		b.text:SetPoint("LEFT", b, "LEFT", 14, 0)
		b.text:SetText(item[2])

		b:SetScript("OnEnter", function(self)
			if not self.selected then
				self.hover:Show()
				SetTextColor(self.text, C.body)
			end
		end)
		b:SetScript("OnLeave", function(self)
			self.hover:Hide()
			if not self.selected then SetTextColor(self.text, C.mut) end
		end)
		b:SetScript("OnClick", function(self)
			if self.selected then return end
			bar:SetValue(self.value)
			Safe(onSelect, self.value)
		end)
		bar.buttons[i] = b
	end

	function bar:SetValue(value)
		self.value = value
		for _, b in ipairs(self.buttons) do
			local on = b.value == value
			b.selected = on
			b.plate:SetShown(on)
			b.shadow:SetShown(on)
			b.hover:Hide()
			if on then
				b.text:SetTextColor(1, 1, 1)
			else
				SetTextColor(b.text, C.mut)
			end
		end
	end
	bar:SetValue(nil)
	return bar
end

-- ============================================================
-- Page: stacks section titles and 42px rows inside a parent (usually a scroll
-- child). Rows: label on the left (optional faint hint under it), one control
-- on the right, all controls sharing the page's right edge. Between the rows of
-- a section a 1px rule at white 5% that fades out toward the right. No boxes.
-- ============================================================
local ROW_HEIGHT = 42
local ROW_HEIGHT_TALL = 56 -- a row whose hint needs two lines
local SECTION_TOP, SECTION_TEXT, SECTION_BOTTOM = 22, 13, 6
local LABEL_GAP = 18 -- least distance between a label and its control

local function RowSetControl(row, control)
	control:SetParent(row)
	control:ClearAllPoints()
	control:SetPoint("RIGHT", row, "RIGHT", 0, 0)
	row.control = control
	local room = row.width - (control:GetWidth() or 0) - LABEL_GAP
	row.label:SetWidth(math.max(room, 40))
	if row.hint then row.hint:SetWidth(math.max(room, 40)) end
	return control
end

local function RowSetShown(row, shown)
	shown = shown and true or false
	if row.rowHidden == not shown then return end
	row.rowHidden = not shown
	row:SetShown(shown)
	row.page:Reflow()
end

-- ============================================================
-- PAGES IN COMPARTMENTS (kit/KIT.md 14, the HUI settings hub; the same block is in HUI Menus' Kit\Widgets.lua).
-- The host (HUI Menus' Hub.lua) marks the frame it hands a page with
--     parent.pageColumns = { width = 728, gap = 36 }
-- and W.Page(parent, width) then builds the page this way. Without the mark (every addon's own window) W.Page is
-- exactly what it always was, so nothing changes outside the hub.
--   * Each section is a COMPARTMENT: its title in tracked capitals (10.5, #b7b1c8), under it a 1-unit rule lit in
--     the purple at its start with a soft glow, fading through pearl to nothing (UI/mockups/hub-r1.css .rule). No box.
--   * The compartments flow into TWO COLUMNS: each goes to the shorter column; a WIDE one spans both and lays its
--     rows out two to a line. Rows are 38 high with their hairlines, a label and a control.
--   * Showing or hiding a row (row:SetRowShown) lays the columns out again and tells page.onHeight.
--   * No hint lines (Harry's one-word rule): row.hint is still made, so code that sets it keeps working, but it is
--     hidden. A row's own code may show it (a live state such as "Changes when combat ends").
-- The page's API, plus:
--   page.columns                        true: code that must differ in the hub asks this
--   page.width / page.fullWidth         a column's width (the rows') / the whole page's
--   page:Section(title, opts)           opts (optional) = { wide = true, control = frame, column = 1 | 2,
--                                       hideEmpty = true } -> title, note
--                                       (column: the compartment stays in that column, whatever the heights: a page
--                                       whose lists grow keeps its arrangement - HUI Frames' Auras page; kit/KIT.md 15)
--                                       (hideEmpty, kit/KIT.md 27: while every row of it is hidden the compartment takes
--                                       no room, its title neither; an element's edge that follows the presentation)
--   page.current                        the compartment the next row goes into (its record: name, rows, head, note)
--   page:SectionControl(frame)          a control on the current compartment's title line, at its right (the
--                                       picker for the rows under it: Bars' Individual Bar Settings, Bar 1-8)
--   row:SetSpan(true)                   in a wide compartment, a row across both columns (a preview)
-- ============================================================
local CP_ROW = 38                 -- .row
local CP_TITLE = 13               -- the title's line
local CP_TITLE_GAP = 7            -- title to rule (.cmp h4 margin-bottom)
local CP_RULE_GAP = 4             -- rule to the first row (.cmp .rule margin-bottom)
local CP_GAP = 22                 -- between compartments (.cols row gap)
local CP_TRACK = 2                -- .20em of 10.5, on whole units
local CP_HEAD = { 183 / 255, 177 / 255, 200 / 255 }
local CP_LABEL = { 214 / 255, 211 / 255, 222 / 255 }
local CP_LIFT = { 158 / 255, 118 / 255, 238 / 255 }
local CP_GLOW = 0.30 * 0.133      -- .rule's box-shadow, rgba(purple, .30) blurred 6px: its peak over a 1-unit line

-- The lit rule (a compartment's, the page title's): the line (rulelit.tga, its colours baked) and its glow (ruleglow.tga,
-- white, tinted here). Anchor the line; the glow follows it.
function W.LitRule(parent)
	local glow = parent:CreateTexture(nil, "BACKGROUND", nil, 2)
	glow:SetTexture(Skin.TEX.ruleglow)
	glow:SetVertexColor(CP_LIFT[1], CP_LIFT[2], CP_LIFT[3], CP_GLOW)
	glow:SetHeight(16)
	local line = parent:CreateTexture(nil, "ARTWORK")
	line:SetTexture(Skin.TEX.rulelit)
	line:SetHeight(1)
	glow:SetPoint("LEFT", line, "LEFT", 0, 0)
	glow:SetPoint("RIGHT", line, "RIGHT", 0, 0)
	line.glow = glow
	return line
end

local function ColumnRowSetSpan(row, span)
	span = span and true or false
	if (row.span or false) == span then return end
	row.span = span
	row.width = span and row.page.fullWidth or row.page.width
	row:SetWidth(row.width)
	if row.control then
		row.label:SetWidth(math.max(row.width - (row.control:GetWidth() or 0) - LABEL_GAP, 40))
	end
	row.page:Reflow()
end

local function ColumnPage(parent, opts)
	local full = opts.width or 728
	local gap = opts.gap or 36
	local colW = math.floor((full - gap) / 2)
	local page = { columns = true, width = colW, fullWidth = full, gap = gap, y = 0, controls = {}, items = {},
		sections = {}, dirty = false }
	local frame = CreateFrame("Frame", nil, parent)
	frame:SetPoint("TOPLEFT", parent, "TOPLEFT", 0, 0)
	frame:SetSize(full, 10)
	page.frame = frame

	function page:Section(text, o)
		local s = { rows = {}, wide = (o and o.wide) and true or false, name = text,
			column = (o and (o.column == 1 or o.column == 2)) and o.column or nil, hideEmpty = (o and o.hideEmpty) and true or nil }
		s.head = CreateFrame("Frame", nil, frame)
		s.head.section = s -- (for a check of what fits: _tools/lua-harness/hub_audit.lua)
		if text and text ~= "" then
			s.title = Skin.Tracked(s.head, string.upper(text), "medium", 10.5, CP_HEAD, CP_TRACK)
			s.rule = W.LitRule(s.head)
		end
		s.note = Skin.Text(s.head, "regular", 11, C.faint, "RIGHT")
		s.note:SetText("")
		self.sections[#self.sections + 1] = s
		self.items[#self.items + 1] = { section = s }
		self.current = s
		if o and o.control then self:SectionControl(o.control) end
		self.dirty = true
		return s.title, s.note
	end

	function page:SectionControl(control)
		if not self.current then self:Section(nil) end
		local s = self.current
		control:SetParent(s.head)
		s.control = control
		self.dirty = true
		return control
	end

	function page:Row(labelText, hintText)
		if not self.current then self:Section(nil) end
		local s = self.current
		local row = CreateFrame("Frame", nil, frame)
		row:SetSize(colW, CP_ROW)
		row.width = colW
		row.rule = row:CreateTexture(nil, "BACKGROUND")
		row.rule:SetTexture(Skin.TEX.rulefade)
		row.rule:SetVertexColor(1, 1, 1, A.rule)
		row.rule:SetHeight(1)
		row.rule:SetPoint("TOPLEFT", row, "TOPLEFT", 0, 0)
		row.rule:SetPoint("TOPRIGHT", row, "TOPRIGHT", 0, 0)
		row.label = Skin.Text(row, "regular", 13, CP_LABEL)
		row.label:SetPoint("LEFT", row, "LEFT", 0, 0)
		row.label:SetText(labelText)
		if hintText then
			row.hint = Skin.Text(row, "regular", 11, C.faint)
			row.hint:SetPoint("LEFT", row, "LEFT", 0, -8)
			row.hint:SetText(hintText)
			row.hint:Hide()
		end
		row.SetControl = RowSetControl
		row.SetRowShown = RowSetShown
		row.SetSpan = ColumnRowSetSpan
		row.page, row.height, row.rowHidden, row.section = self, CP_ROW, false, s
		s.rows[#s.rows + 1] = row
		self.items[#self.items + 1] = { row = row }
		self.dirty = true
		return row
	end

	-- A compartment's title block: its height, and the height of the title's line.
	local function HeadHeight(s)
		if not s.title and not s.control then return 0, 0 end
		local line = CP_TITLE
		if s.control then line = math.max(line, math.ceil(s.control:GetHeight() or 0)) end
		return line + CP_TITLE_GAP + 1 + CP_RULE_GAP, line
	end

	local function PlaceHead(s, x, y, w)
		local h, line = HeadHeight(s)
		s.head:ClearAllPoints()
		s.head:SetPoint("TOPLEFT", frame, "TOPLEFT", x, -y)
		s.head:SetSize(w, math.max(h, 1))
		s.head:SetShown(h > 0)
		if h == 0 then return 0 end
		local mid = -math.floor(line / 2)
		if s.title then
			s.title:ClearAllPoints()
			s.title:SetPoint("LEFT", s.head, "TOPLEFT", 0, mid)
			s.rule:ClearAllPoints()
			s.rule:SetPoint("TOPLEFT", s.head, "TOPLEFT", 0, -(line + CP_TITLE_GAP))
			s.rule:SetPoint("TOPRIGHT", s.head, "TOPRIGHT", 0, -(line + CP_TITLE_GAP))
		end
		s.note:ClearAllPoints()
		if s.control then
			s.control:ClearAllPoints()
			s.control:SetPoint("RIGHT", s.head, "TOPRIGHT", 0, mid)
			s.note:SetPoint("RIGHT", s.control, "LEFT", -12, 0)
		else
			s.note:SetPoint("RIGHT", s.head, "TOPRIGHT", 0, mid)
		end
		return h
	end

	local function PlaceRow(row, x, y, ruled)
		row:ClearAllPoints()
		row:SetPoint("TOPLEFT", frame, "TOPLEFT", x, -y)
		row.rule:SetShown(ruled)
	end

	-- (hideEmpty) A compartment with no row shown.
	local function Empty(s)
		if not s.hideEmpty then return false end
		for _, row in ipairs(s.rows) do
			if not row.rowHidden then return false end
		end
		return true
	end

	local function Layout()
		page.dirty = false
		local colY = { 0, 0 }
		for _, s in ipairs(page.sections) do
			if Empty(s) then
				s.head:Hide()
			elseif s.wide then
				local y = math.max(colY[1], colY[2])
				if y > 0 then y = y + CP_GAP end
				y = y + PlaceHead(s, 0, y, full)
				local col, lineH, lines = 1, 0, 0
				for _, row in ipairs(s.rows) do
					if not row.rowHidden then
						if row.span then
							if col == 2 then
								y, lines, col = y + lineH, lines + 1, 1
							end
							PlaceRow(row, 0, y, lines > 0)
							y, lines = y + row.height, lines + 1
						elseif col == 1 then
							PlaceRow(row, 0, y, lines > 0)
							lineH, col = row.height, 2
						else
							PlaceRow(row, colW + gap, y, lines > 0)
							lineH = math.max(lineH, row.height)
							y, lines, col = y + lineH, lines + 1, 1
						end
					end
				end
				if col == 2 then y = y + lineH end
				colY[1], colY[2] = y, y
			else
				local c = s.column or (colY[2] < colY[1] and 2 or 1)
				local x = c == 1 and 0 or colW + gap
				local y = colY[c]
				if y > 0 then y = y + CP_GAP end
				y = y + PlaceHead(s, x, y, colW)
				local first = true
				for _, row in ipairs(s.rows) do
					if not row.rowHidden then
						PlaceRow(row, x, y, not first)
						first = false
						y = y + row.height
					end
				end
				colY[c] = y
			end
		end
		page.y = math.max(colY[1], colY[2])
		frame:SetHeight(math.max(page.y, 1))
	end

	function page:Reflow()
		Layout()
		if self.onHeight then self.onHeight(self.y) end
	end

	function page:Height()
		if self.dirty then Layout() end
		return self.y
	end
	return page
end

-- (hideEmpty, kit/KIT.md 27) A section of the single column with no row shown.
local function SectionEmpty(item)
	for _, row in ipairs(item.rows) do
		if not row.rowHidden then return false end
	end
	return true
end

function W.Page(parent, width)
	if parent and parent.pageColumns then return ColumnPage(parent, parent.pageColumns) end
	local page = { y = 0, width = width, firstInSection = true, controls = {}, items = {} }
	local frame = CreateFrame("Frame", nil, parent)
	frame:SetPoint("TOPLEFT", parent, "TOPLEFT", 0, 0)
	frame:SetSize(width, 10)
	page.frame = frame

	-- Small uppercase muted title. Returns the title and an optional faint note
	-- right-aligned on the same line (set its text later, or leave it empty). o (optional): { hideEmpty = true }
	-- (kit/KIT.md 27): while every row of it is hidden the section takes no room, its title neither.
	function page:Section(text, o)
		self.y = self.y + SECTION_TOP
		local title = Skin.Text(frame, "medium", 10.5, C.faint)
		title:SetPoint("TOPLEFT", frame, "TOPLEFT", 0, -self.y)
		title:SetText(string.upper(text))
		local note = Skin.Text(frame, "regular", 11, C.faint, "RIGHT")
		note:SetPoint("TOPRIGHT", frame, "TOPRIGHT", 0, -self.y + 1)
		note:SetText("")
		self.y = self.y + SECTION_TEXT + SECTION_BOTTOM
		self.firstInSection = true
		frame:SetHeight(self.y)
		local item = { title = title, note = note, name = text, rows = {}, hideEmpty = (o and o.hideEmpty) and true or nil }
		self.items[#self.items + 1] = item
		self.current = item
		return title, note
	end

	-- tall = true gives the hint room for two lines (56px instead of 42).
	function page:Row(labelText, hintText, tall)
		local height = (tall and hintText) and ROW_HEIGHT_TALL or ROW_HEIGHT
		local row = CreateFrame("Frame", nil, frame)
		row:SetSize(self.width, height)
		row:SetPoint("TOPLEFT", frame, "TOPLEFT", 0, -self.y)
		row.width = self.width

		if not self.firstInSection then
			local rule = row:CreateTexture(nil, "BACKGROUND")
			rule:SetTexture(Skin.TEX.rulefade)
			rule:SetVertexColor(1, 1, 1, A.rule)
			rule:SetHeight(1)
			rule:SetPoint("TOPLEFT", row, "TOPLEFT", 0, 0)
			rule:SetPoint("TOPRIGHT", row, "TOPRIGHT", 0, 0)
		end
		self.firstInSection = false

		row.label = Skin.Text(row, "regular", 13, C.body)
		row.label:SetText(labelText)
		if hintText and height == ROW_HEIGHT_TALL then
			-- 8px above, label 13, 3px, two hint lines of 13, 6px below
			row.label:SetPoint("TOPLEFT", row, "TOPLEFT", 0, -8)
			row.hint = Skin.Text(row, "regular", 11, C.faint)
			row.hint:SetPoint("TOPLEFT", row, "TOPLEFT", 0, -24)
			row.hint:SetWordWrap(true)
			row.hint:SetJustifyV("TOP")
			row.hint:SetMaxLines(2)
			row.hint:SetText(hintText)
		elseif hintText then
			row.label:SetPoint("LEFT", row, "LEFT", 0, 7)
			row.hint = Skin.Text(row, "regular", 11, C.faint)
			row.hint:SetPoint("LEFT", row, "LEFT", 0, -8)
			row.hint:SetText(hintText)
		else
			row.label:SetPoint("LEFT", row, "LEFT", 0, 0)
		end
		row.SetControl = RowSetControl
		row.SetRowShown = RowSetShown
		row.page, row.height, row.rowHidden = self, height, false
		if self.current then
			local rowsOf = self.current.rows
			rowsOf[#rowsOf + 1] = row
		end
		self.items[#self.items + 1] = { row = row }

		self.y = self.y + height
		frame:SetHeight(self.y)
		return row
	end

	-- Restacks everything after a row was shown or hidden, so a hidden row leaves
	-- no gap. page.onHeight(height), if set, hears about the new height.
	function page:Reflow()
		local y = 0
		for _, item in ipairs(self.items) do
			if item.row then
				if not item.row.rowHidden then
					item.row:ClearAllPoints()
					item.row:SetPoint("TOPLEFT", frame, "TOPLEFT", 0, -y)
					y = y + item.row.height
				end
			elseif item.hideEmpty and SectionEmpty(item) then
				item.title:Hide()
				item.note:Hide()
			else
				if item.hideEmpty then
					item.title:Show()
					item.note:Show()
				end
				y = y + SECTION_TOP
				item.title:ClearAllPoints()
				item.title:SetPoint("TOPLEFT", frame, "TOPLEFT", 0, -y)
				item.note:ClearAllPoints()
				item.note:SetPoint("TOPRIGHT", frame, "TOPRIGHT", 0, -y + 1)
				y = y + SECTION_TEXT + SECTION_BOTTOM
			end
		end
		self.y = y
		frame:SetHeight(math.max(y, 1))
		if self.onHeight then self.onHeight(y) end
	end

	function page:Height()
		return self.y
	end
	return page
end
