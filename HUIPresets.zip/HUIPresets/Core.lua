local ADDON, ns = ...

-- ============================================================
-- HUI PRESETS (0.1.0, Oct 19 2026). The HUI Bar Editor's own in-game half, a small addon of its own that needs no other
-- (Harry: "fine tiny addon. just call it HUIPresets. give the menu aesthetic the hui aesthetic, but have it as a standalone
-- in-game and give it a map icon"; "surely we just save it as a 'human priest' layout, and the addon should recognise
-- that and load it itself"; "on a new load (detected on new character) it should ask for permission first").
--
--   Presets\      (0.1.1, Harry, Oct 19: "the solution is to just make Human Priest.lua, Dwarf Rogue.lua") one file per
--                 playable race and class (HumanPriest.lua, DwarfRogue.lua ...), each written by the editor's Download
--                 as HUIPresets_Add({ <layout>, ... }) - a call, never a global, so no file overwrites another's presets.
--                 Shipped as comment lines only; read at load (a /reload reads them again). The layouts are
--                 dev/docs/actionbars/LAYOUT-FORMAT.md v1. Presets.lua, the old single file (HUIPRESETS = { ... }), is
--                 still read for this one version when it is in the folder.
--   Apply.lua     which presets are this character's (its class, its race first), the ask on a character that never had
--                 one (Apply | Not now | Never), applying (out of a fight: macros, slots, keys on whatever bars are
--                 drawn, settings), and afterwards the spells learnt and ranks bought placed ("Train N" / "Up to
--                 date" / "All placed") and a better mount or potion swapped in; Export (0.1.2) the bars as a string.
--   Ranks.lua     (0.1.2) every class's spells and ranks, the editor's data (website/tools/make_preset_ranks.js).
--   Window.lua    the window in HUI's look (the kit's panel, Arial Narrow, the purple edge); Minimap.lua its button;
--                 Slash.lua /presets and /hpresets; (0.1.8) /presets tidy lists the duplicate macros to remove.
--   Codec.lua, Engine.lua   the layout's text and the engine that puts a layout on the character (copied from HUI Bars'
--                 LayoutCodec.lua / Layouts.lua and grown here: keys on any bar addon, mounts, settings).
--   Kit\          a byte-identical copy of the HUI kit (dev/kit, dev/tools/sync_kit.py): never edit it in place.
--
-- SAVED (per character only: HUIPresetsCharDB): what was applied and when (name, class, race, its hash, at), "Never",
-- the minimap button's angle, and the engine's store (pins, the spells and mounts it still waits for; 0.1.8: the macros
-- it made, so a changed one is edited in place and a dropped one deleted).
-- Nothing here posts to any chat: its lines are printed in your own chat frame only.
-- ============================================================
ns.VERSION = "0.1.11"

ns.NAMES = {
	title = "HUI Presets",
	chat = "HUI Presets",
	short = "Presets",
	framePrefix = "HUIPresets",            -- HUIPresetsWindow, HUIPresetsMinimapButton
	charVariables = "HUIPresetsCharDB",    -- must match ## SavedVariablesPerCharacter
	slash = { "/presets", "/hpresets" },
	slashKey = "HUIPRESETS",
	-- the window's words (one or two plain words each)
	head = "PRESETS",
	none = "None",
	apply = "Apply",
	notNow = "Not now",
	never = "Never",
	load = "Load",
	paste = "Import From String",          -- (0.1.2, Harry, Oct 19: "just have it say Import From String")
	export = "Export",
	allPlaced = "All placed",
	train = "Train %d",                    -- (0.1.2) the spells to buy at the trainer now
	upToDate = "Up to date",               -- nothing to buy now, more to come at later levels
	updated = "Updated",
	applied = "Applied",
	waits = "%s waits for the fight to end.",
	sameAgain = "Same as applied - replaced the file? /reload first",   -- (0.1.7) the files are read at load
	-- (0.1.8) /presets tidy
	tidy = "Tidy",
	tidyHead = "MACROS",
	remove = "Remove",
	removeAsk = "Remove %d?",
	yes = "Yes",
	no = "No",
	tidied = "%d duplicate macros removed",
	tidied1 = "%d duplicate macro removed",
	badString = "not a HUI layout",
	otherClass = "for %s",
	classes = { WARRIOR = "Warrior", PALADIN = "Paladin", HUNTER = "Hunter", ROGUE = "Rogue", PRIEST = "Priest",
		SHAMAN = "Shaman", MAGE = "Mage", WARLOCK = "Warlock", DRUID = "Druid" },
}
local NAMES = ns.NAMES

-- The kit's edge: one element of our own, the window's (dev/kit/KIT.md 18), Dark as every HUI edge starts.
ns.EDGES = {
	own = { { key = "window", label = "Window", page = { "general" }, default = "dark" } },
	uses = {},
}

-- ============================================================
-- HUIPresets_Add({ <layout>, ... }): what each Presets\ file calls. The tables are only kept here, as they came (one
-- layout alone is taken too); Apply.lua checks them (the codec's Sanitize) when it reads the presets.
-- ============================================================
ns.added = {}
function HUIPresets_Add(list)
	if type(list) ~= "table" then return end
	if list.v ~= nil or list.name ~= nil then list = { list } end
	for i = 1, 400 do
		local t = list[i]
		if t == nil then break end
		ns.added[#ns.added + 1] = t
	end
end

-- ============================================================
-- Chat lines (your own frame only) and errors
-- ============================================================
local PURPLE = "|cffb084f0"
function ns.Print(msg)
	print(PURPLE .. NAMES.chat .. ":|r " .. tostring(msg))
end

ns.errors = {}
local seen = {}
function ns.OnError(err)
	local text = tostring(err)
	if seen[text] then return text end
	seen[text] = true
	if #ns.errors < 40 then ns.errors[#ns.errors + 1] = { msg = text } end
	-- (Oct 21, the stress test; Harry: "an error catcher ... that stops me from seeing errors - but logs them for you to
	-- read") handed to the probe's catcher (live-test-probe: HUI_ERROR_SINK), said in chat only while it keeps no quiet
	local sink = rawget(_G, "HUI_ERROR_SINK")
	if type(sink) == "function" then pcall(sink, ADDON, text, nil) end
	if not rawget(_G, "HUI_QUIET_ERRORS") then print("|cffe278ba" .. NAMES.chat .. " error:|r " .. text) end
	return text
end

function ns.Safe(fn, ...)
	return xpcall(fn, ns.OnError, ...)
end

function ns.Wrap(fn)
	return function(...) ns.Safe(fn, ...) end
end

function ns.Call(fn, ...)
	if type(fn) ~= "function" then return nil end
	local ok, a, b, c, d = pcall(fn, ...)
	if not ok then return nil end
	return a, b, c, d
end

function ns.Num(v)
	if issecretvalue and issecretvalue(v) then return nil end
	if type(v) ~= "number" or v ~= v then return nil end
	return v
end

function ns.Str(v)
	if issecretvalue and issecretvalue(v) then return nil end
	if type(v) ~= "string" or v == "" then return nil end
	return v
end

-- ============================================================
-- Events
-- ============================================================
local frame = CreateFrame("Frame")
local handlers = {}
frame:SetScript("OnEvent", function(_, event, ...)
	local list = handlers[event]
	if not list then return end
	for i = 1, #list do ns.Safe(list[i], event, ...) end
end)

function ns.On(event, fn)
	if not handlers[event] then
		handlers[event] = {}
		local ok, err = pcall(frame.RegisterEvent, frame, event)
		if not ok then ns.OnError("could not register " .. event .. ": " .. tostring(err)) end
	end
	table.insert(handlers[event], fn)
end

-- What may not run in a fight waits for its end, one job per key, the last asked for winning.
local waiting, order = {}, {}
function ns.OutOfCombat(key, fn)
	if not InCombatLockdown() then
		fn()
		return true
	end
	if not waiting[key] then order[#order + 1] = key end
	waiting[key] = fn
	return false
end
function ns.Waiting(key) return waiting[key] ~= nil end
ns.On("PLAYER_REGEN_ENABLED", function()
	local keys = order
	order = {}
	for _, key in ipairs(keys) do
		local fn = waiting[key]
		waiting[key] = nil
		if fn then ns.Safe(fn) end
	end
end)

-- ============================================================
-- Saved variables
-- ============================================================
local initCallbacks, loginCallbacks = {}, {}
function ns.OnInit(fn) initCallbacks[#initCallbacks + 1] = fn end
function ns.OnLogin(fn) loginCallbacks[#loginCallbacks + 1] = fn end
-- (the kit asks for option changes; we have none to tell)
function ns.OnOption() end

ns.On("ADDON_LOADED", function(_, name)
	if name ~= ADDON then return end
	local db = rawget(_G, NAMES.charVariables)
	if type(db) ~= "table" then db = {} end
	_G[NAMES.charVariables] = db
	if type(db.edges) ~= "table" then db.edges = {} end
	if type(db.store) ~= "table" then db.store = {} end
	if db.applied ~= nil and type(db.applied) ~= "table" then db.applied = nil end
	if type(db.minimapAngle) ~= "number" then db.minimapAngle = 200 end
	db.version = ns.VERSION
	ns.db = db
	if ns.Skin and ns.Skin.SetFontFace then ns.Skin.SetFontFace("arialn") end
	for i = 1, #initCallbacks do ns.Safe(initCallbacks[i]) end
end)

ns.On("PLAYER_LOGIN", function()
	if not ns.db then
		ns.OnError("PLAYER_LOGIN arrived before ADDON_LOADED; saved variables missing")
		return
	end
	for i = 1, #loginCallbacks do ns.Safe(loginCallbacks[i]) end
	ns.ready = true
end)

-- Any NAMED movable frame gets its position saved by the client itself: not ours.
function ns.ForgetClientPlacement(f)
	if f.SetDontSavePosition then pcall(f.SetDontSavePosition, f, true) end
	if f.SetUserPlaced and f:IsMovable() then pcall(f.SetUserPlaced, f, false) end
end
