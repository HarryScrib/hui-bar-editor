-- HUI kit (kit/ at the repo root; its change log is kit/KIT.md). Every addon's Kit\ holds a byte-identical copy made
-- by _tools/sync_kit.py: change kit/ and run the sync, never a copy in place. This file is also HUI Menus' own
-- (UI/ForeverMenus/Kit\Edge.lua, the sync's partial member, KIT.md 18): the one edge engine of both lineages of the kit.
local ADDON, ns = ...

-- ============================================================
-- THE EDGE (KIT.md 17 - 20, 27, 34; the design is kit/DESIGN-edges.md). A ramp all round a frame: four sides and four
-- eased corners, starting `radius` inside it so the corners turn with its own and reaching `reach` past it, under the
-- fill and over the black shadow (BACKGROUND -7). Every edge is an ELEMENT, named by its key (Skin.Panel's glowKey;
-- DESIGN-edges.md 2), and its element decides how it looks (Edge.Resolve): its Colour < Dark | Purple | None >, its
-- Strength and its Spread (KIT.md 20, saved in the addon's ns.db.edges). (KIT.md 34, Harry, Oct 7: "just remove default
-- ... have every single edge default setting as dark, not purple") There is no "Default" any more and nothing follows
-- anything: every element starts Dark (or None, where it is declared so) at 40 % and 100 % (Edge.START) unless it
-- declares numbers of its own (KIT.md 25), and each number is the element's own once it was moved. The hub's All edges
-- only SETS every element at once (HUI Menus' Edges page); a saved "default" becomes Dark when it loads (Edge.Clean).
-- Colour: Purple, the white art tinted D1, or Dark, the black edgeshade art the edge was drawn from until 17 (a vertex
-- colour multiplies, so D1 never showed on it). SPREAD (KIT.md 19): how far the ramp reaches, a multiplier of its reach;
-- the inner radius shrinks with it below 100 %, so a condensed edge keeps its brightness at the glass.
--
-- RULE: no code outside the kit ever calls SetAlpha, SetVertexColor, SetShown, Show or Hide on a glow piece. An owner
-- turns its edge off and on with Skin.ShowGlow and a side with Skin.SetGlowSides; both are kept through every repaint.
-- (On this client a texture's SetAlpha REPLACES the alpha SetVertexColor gave it: HUI Menus' tooltips drew their edge
-- at full alpha that way until 18.)
--
--   Skin.Glow(frame, reach, radius, anchor, key)  the eight pieces (right, left, top, bottom, tr, tl, br, bl), an array
--                                  that also carries its record: key, kind "ring", owner, anchor, reach (the base),
--                                  radius, art (the colour on it), spread, R and r (as laid), and once set, sides and off
--   Skin.EdgeGlow(frame, side, reach, key)  one ramp along an open edge ("right" or "bottom"); returns the texture
--   Skin.GlowOf(tex)               the record a piece belongs to
--   Skin.ShowGlow(glow, on)        the owner's own on and off (glow: the pieces, or an EdgeGlow's texture)
--   Skin.SetGlowSides(glow, sides) e.g. { left = false }: a side that is off hides its ramp and its two corners
--   Skin.SetGlow(strength), Skin.SetGlowColour(name), Skin.SetGlowSpread(mult)   the hub's All edges as published (the
--                                  old names keep working; KIT.md 34: no element takes them - nothing follows)
--   Skin.GlowTexture(kind, key)    the art of a piece of that kind in that element's colour, for code that draws its own
--   Skin.OutlinePieces(groups, R)  (KIT.md 22) the pieces of ONE edge round each group of touching boxes, outer
--                                  boundary only (a pure function: THE OUTLINE, below)
--   Skin.Outline(key, opts)        (KIT.md 22) that edge as a glow of its element: o:Set(groups), o:Clear()
--   Edge.Resolve(key)              colour, strength (0..1), spread (a multiplier of the reach), shown
--   Edge.Tint(key)                 (KIT.md 44) r, g, b the element's art is tinted with: D1 (Dark's black art and Purple's
--                                  white), or its own colour on Custom (the white art) - for code that draws its own edge
--   Edge.OwnRgb(key)               (KIT.md 44) the Custom colour saved for it (r, g, b), nil while none was picked
--   Edge.Watch(key, fn)            fn(key) after that element changed (nil: after any change); for code that draws its own
--   Edge.Get / Set / Clean / Load / Provider / Section / Rows / RefreshRows   an element's own values and rows (KIT.md 20;
--                                  27: one compartment per element, "<Label> edge": Colour, Strength, Spread, Reset)
--   Edge.OwnNumbers(key)           (KIT.md 27) the numbers the element has of its own (saved), nil where it follows
--   Edge.NoDefault(key)            (KIT.md 32; 34: true for every element - no element has Default any more)
--   Edge.AllSection(page, binding, opts)   (KIT.md 27; 34) the "All edges" compartment: the hub's control that SETS every
--                                  element at once (its binding does the setting; nothing follows it)
--   Edge.Forget(page)              (Brief C2) a page's rows dropped (the hub's Edges page, built again)
--   Edge.Follow()                  (KIT.md 33) follow the hub's edge now, as the first glow would (an addon that draws
--                                  its own edge and maybe no kit glow); Edge.Following() whether it does
--   Edge.Debug()                   the registry (below), for /debug and the tests
-- ============================================================
local Skin = ns.Skin
local Edge = {}
ns.Edge = Edge

local MEDIA = "Interface\\AddOns\\" .. ADDON .. "\\Kit\\media\\"

-- ForeverBars 0.2.0 (KIT.md 3): the suite purple D1 (Harry, round 7), was 62,14,120.
Skin.GLOW = { 103 / 255, 53 / 255, 167 / 255 } -- D1
Skin.GLOW_ALPHA = 0.85  -- where the ramp touches the glass, at full strength
Skin.GLOW_REACH = 56    -- how far it reaches past a window
Skin.glow = 0.4         -- the hub's All edges strength as published, 0..1 (KIT.md 34: read by nothing that draws)
-- KIT.md 17: the edge's ART, by its colour. "purple": the ramps in white (media\edgeglow_*.tga, kit/tools/
-- make_edge_glow.py: the edgeshade files' alpha, texel for texel), so the D1 tint above is the colour. "dark": the
-- edgeshade files themselves, black, the edge as it was until 17 to the texel (the same tint, alpha and reach). The
-- edgeshade files stay as they are: they are also plain shadows (HUI Quests' window, HUI Journal's Look, the hub's).
-- (KIT.md 22) "i", an outline's inside corner: the brighter of the two ramps that meet there, max(h[x], h[31 - y]) of the
-- h ramp (kit/tools/make_edge_glow.py), solid along its foot and its left side as the corner "c" is.
Skin.GLOW_ART = {
	purple = { h = MEDIA .. "edgeglow_h.tga", v = MEDIA .. "edgeglow_v.tga", c = MEDIA .. "edgeglow_c.tga",
		i = MEDIA .. "edgeglow_i.tga" },
	dark = { h = MEDIA .. "edgeshade_h.tga", v = MEDIA .. "edgeshade_v.tga", c = MEDIA .. "edgeshade_c.tga",
		i = MEDIA .. "edgeshade_i.tga" },
}
-- (KIT.md 44) "custom": Purple's white art, tinted with the element's own colour (Edge.Tint) instead of D1 - so a light
-- colour shows as light as Purple's purple does; Dark's black art would take no colour at all (a tint multiplies).
Skin.GLOW_ART.custom = Skin.GLOW_ART.purple
Skin.glowColour = "dark"   -- the hub's All edges colour as published, "purple" | "dark" (Skin.SetGlowColour; KIT.md 34:
                           -- Dark, and read by nothing that draws)
Skin.glowSpread = 1        -- (KIT.md 19) the hub's All edges Spread as published, a multiplier, 0.2..2 (Skin.SetGlowSpread)

-- ============================================================
-- THE ELEMENTS. Each addon declares its own in its Core.lua (which loads before Kit\), as data:
--   ns.EDGES = { own = { { key, label, page = { categoryId, tabId }, default = "dark" | "none" (KIT.md 34: what it
--                          starts at - Dark when not said; any other word, "default" and "purple" among them, is refused:
--                          it starts Dark, and Edge.Debug's `refused` says so),
--                          strength, spread = (KIT.md 25; 34: each on its own, with any start) the Strength (5 - 100)
--                          and Spread (20 - 200) it starts at, taken as a saved number is (in range, on a step of 5);
--                          one not said is the kit's start, 40 and 100 (Edge.START; one that is no number is refused),
--                          noDefault = (KIT.md 32; 34: every element is without Default now - accepted and unread),
--                          presentation = (HUI Menus' panes) "windows" | "column" | "curtain" | "halo",
--                          live = function() return false while its surface cannot show (its row dims) end }, ... },
--                uses = { the shared elements it draws },
--                keep = { (optional, KIT.md 23) every key it may declare on SOME character, e.g. HUI Assign's, whose
--                         lists change with the class while its saved values are the account's: Edge.Clean keeps their
--                         saved entries; nothing else reads it (Known, Resolve, Set, the rows and the provider go by the
--                         live own and uses) } }
-- The five shared elements belong to the hub (HUI Menus: ns.KIT.edgeHost) and, without one, to each addon that draws
-- them. (Brief C2) Under a hub that keeps them (ForeverSuiteOptions.edges = 1, HUI Menus 0.7.1, its Edges page) every
-- other kit takes them as the hub publishes them (.edge.elements), sets none of them and builds no rows for them; alone,
-- or under an older hub, each addon keeps its own (saved in its ns.db.edges, rows on its first page). PENDING: elements
-- declared before their surface exists - each later brief of DESIGN-edges.md 13 empties its own entries (KIT.md 21, Brief
-- D: the stone panels and the minimap's glass are drawn; KIT.md 22, Brief E: the meter's outline - none is left).
-- ============================================================
Edge.SHARED = { "settings", "dropdowns", "colourwheel", "prompts", "unlock" }
local SHARED = {}
for i = 1, #Edge.SHARED do SHARED[Edge.SHARED[i]] = true end
Edge.SHARED_LABELS = { settings = "Settings", dropdowns = "Dropdowns", colourwheel = "Colour wheel", prompts = "Prompts",
	unlock = "Unlock" }
local PENDING = {} -- [addon] = { [key] = the brief that draws its surface } (none left: every element is drawn)
Edge.PENDING = PENDING[ADDON] or {}

-- (KIT.md 20) An element's own values, DESIGN-edges.md 3: edges[key] = { colour = one of these four words,
-- strength = 5..100, spread = 20..200 } (both in steps of 5; (KIT.md 27) each number only once it was moved: a number
-- that is not there follows - the declared one, else All edges').
-- (KIT.md 34) Three words: "default" is gone (a saved one becomes "dark" when it loads, Edge.Clean).
-- (KIT.md 44, Harry, Oct 12: "can you add a colour wheel to edge colours ... players should be able to add different edge
-- colours to all different components if they so desire") A fourth, "custom": the colour picked on the wheel, saved
-- beside the numbers as rgb = { r, g, b } (0..1 each; kept while another colour is chosen, so Custom comes back as it
-- was). Custom with no rgb yet draws CUSTOM_START, the suite purple D1.
local COLOURS = { purple = true, dark = true, none = true, custom = true }
local STRENGTH, SPREAD, STEP = { 5, 100 }, { 20, 200 }, 5
Edge.COLOURS = { "dark", "purple", "none", "custom" } -- (the rows' order)
Edge.STRENGTH, Edge.SPREAD, Edge.STEP = STRENGTH, SPREAD, STEP
-- (KIT.md 34) What every element starts at unless it declares otherwise: Dark, Strength 40 %, Spread 100 % (the numbers
-- the suite's Default had; never purple).
local START = { colour = "dark", strength = 40, spread = 100 }
Edge.START = START
local CUSTOM_START = { Skin.GLOW[1], Skin.GLOW[2], Skin.GLOW[3] }
Edge.CUSTOM_START = CUSTOM_START

local function Declared()
	local d = ns.EDGES
	return type(d) == "table" and d or {}
end

local function IsHost()
	return type(ns.KIT) == "table" and ns.KIT.edgeHost == true
end

-- An own element's declaration (a short list, read where it is needed: nothing is cached, so a test may declare more).
local function Own(key)
	local own = Declared().own
	if type(own) ~= "table" or key == nil then return nil end
	for i = 1, #own do
		if type(own[i]) == "table" and own[i].key == key then return own[i] end
	end
	return nil
end
Edge.Own = Own

local function Uses(key)
	local uses = Declared().uses
	if type(uses) == "table" then
		for i = 1, #uses do if uses[i] == key then return true end end
	end
	return false
end

-- Is `key` an element of this addon: its own, a shared one it draws, or (the host) any shared one?
function Edge.Known(key)
	if type(key) ~= "string" then return false end
	if Own(key) then return true end
	if Uses(key) then return true end
	return IsHost() and SHARED[key] == true
end

-- (KIT.md 23, the review of Oct 1) Is `key` one the addon keeps saved values for although it may not declare it on this
-- character (ns.EDGES.keep: a list of keys, or a set)? Edge.Clean only: a mage's login must not wipe the paladin's
-- HUI Assign edges from the account's table.
local function Kept(key)
	local keep = Declared().keep
	if type(keep) ~= "table" or type(key) ~= "string" then return false end
	if keep[key] == true then return true end
	for i = 1, #keep do if keep[i] == key then return true end end
	return false
end

-- (KIT.md 20, Brief C2) A SHARED element under a hub that keeps them (ForeverSuiteOptions.edges = 1, HUI Menus 0.7.1):
-- the hub's own values, published as ForeverSuiteOptions.edge.elements[key] = { colour, strength = 0..1, spread =
-- 0.2..2 } - false while the hub has published none for it (the Default then). nil when this kit keeps the element
-- itself: its own elements always, the host's kit, and every element alone or under an older hub (no `edges`). Read
-- fresh each time and never kept; no allocation (HUI Menus' tooltips resolve on a hot path).
local function Published(key)
	if key == nil or not SHARED[key] or IsHost() then return nil end
	local suite = _G.ForeverSuiteOptions
	if type(suite) ~= "table" or type(suite.host) ~= "string" or suite.edges ~= 1 then return nil end
	local edge = suite.edge
	local elements = type(edge) == "table" and edge.elements
	local e = type(elements) == "table" and elements[key]
	if type(e) == "table" then return e end
	return false
end

-- ============================================================
-- THE SAVED VALUES (KIT.md 20). The addon's ns.db.edges, read fresh every time and never kept (HUI Bars' ns.db is a
-- profile). The kit writes it itself, never through the addon's SetOption (HUI Assign's refuses keys it does not know,
-- HUI Menus' walks a path). Nothing here allocates on a read: HUI Menus' tooltips ask Edge.Resolve on a hot path.
-- ============================================================
local function Store()
	local db = ns.db
	if type(db) ~= "table" then return nil end
	local t = db.edges
	return type(t) == "table" and t or nil
end

local function Entry(key)
	local t = Store()
	if not t or key == nil then return nil end
	local e = t[key]
	return type(e) == "table" and e or nil
end

local function Round5(v) return math.floor(v / STEP + 0.5) * STEP end

-- A saved number as it may be used: within its range, on a step of 5; nil for anything that is not a number (or NaN).
local function Num(v, range)
	if type(v) ~= "number" or v ~= v then return nil end
	v = Round5(v)
	if v < range[1] then v = range[1] elseif v > range[2] then v = range[2] end
	return v
end

-- (KIT.md 44) A saved colour as it may be used: { r, g, b } (or { r =, g =, b = }), each a number put in 0..1 on a step
-- of 1/255; nil, nil, nil for anything else (a missing or non-number channel, NaN).
local function Channel(v)
	if type(v) ~= "number" or v ~= v then return nil end
	if v < 0 then v = 0 elseif v > 1 then v = 1 end
	return math.floor(v * 255 + 0.5) / 255
end
local function Rgb(t)
	if type(t) ~= "table" then return nil end
	local r, g, b = Channel(t[1] or t.r), Channel(t[2] or t.g), Channel(t[3] or t.b)
	if not (r and g and b) then return nil end
	return r, g, b
end
Edge.Rgb = Rgb

-- (KIT.md 34) What a declaration starts at: "none" (DESIGN-edges.md 2: Halo, the quest tracker's Stone, the minimap's
-- glass) or Dark - every other start, never purple; and (KIT.md 25) its declared Strength and Spread, each taken as a
-- saved number is (Num), nil where it declares none. Returns the colour and the two numbers.
local function DeclaredStart(d)
	if type(d) ~= "table" then return START.colour end
	local word = d.default == "none" and "none" or START.colour
	return word, Num(d.strength, STRENGTH), Num(d.spread, SPREAD)
end

-- (KIT.md 34) Is a declaration's start refused: a word other than "dark" or "none" ("default", "purple", anything else),
-- or a Strength or Spread that is no number? It starts Dark (at the kit's number); Edge.Debug's `refused` names it.
local function DeclaredRefused(d)
	if type(d) ~= "table" then return false end
	if d.default ~= nil and d.default ~= "dark" and d.default ~= "none" then return true end
	if d.strength ~= nil and not Num(d.strength, STRENGTH) then return true end
	if d.spread ~= nil and not Num(d.spread, SPREAD) then return true end
	return false
end

-- What an element starts at, declared (a shared one, or a key not declared: Dark).
local function Starts(key)
	return (DeclaredStart(Own(key)))
end

-- (KIT.md 25) The numbers an element falls back on, each on its own, while nothing is saved for it: its declared
-- Strength and Spread, whatever colour it is on; nil for one it does not declare (the kit's start then: Numbers).
local function DeclaredNumbers(key)
	local _, s, p = DeclaredStart(Own(key))
	return s, p
end

-- (KIT.md 32; 34) No element has Default any more: true for every one (kept for 32's callers).
function Edge.NoDefault(key)
	return true
end

-- The element's Colour as chosen: its saved one, else what it starts at; (Brief C2) a shared one the hub keeps: the
-- hub's (its start while it has published none). (KIT.md 34) Never "default": a saved one not cleaned yet, or one an
-- older hub publishes, reads Dark.
local function ColourOf(key)
	local p = Published(key)
	local c
	if p ~= nil then
		c = p and p.colour
	else
		local e = Entry(key)
		c = e and e.colour
	end
	if c ~= nil then
		if COLOURS[c] then return c end
		if c == "default" then return START.colour end
	end
	return Starts(key)
end
Edge.ColourOf = ColourOf

-- A published number (0..1 of its %) as a saved one: in its range on a step of 5, or nil.
local function PubNum(v, range)
	if type(v) ~= "number" then return nil end
	return Num(v * 100, range)
end

-- (KIT.md 27) The numbers the element has of its own (%): the ones saved for it (each only once it was moved), (Brief C2)
-- or a shared one's as the hub published them (HUI Menus publishes its own numbers only); nil for a number that is not
-- its own (it is drawn at its declared one, else the kit's start). Its rows show Reset while either is there.
local function OwnNumbers(key)
	local p = Published(key)
	if p ~= nil then
		if not p then return nil, nil end
		return PubNum(p.strength, STRENGTH), PubNum(p.spread, SPREAD)
	end
	local e = Entry(key)
	if not e then return nil, nil end
	return Num(e.strength, STRENGTH), Num(e.spread, SPREAD)
end
Edge.OwnNumbers = OwnNumbers

-- (KIT.md 44) The Custom colour the element has of its own: saved for it, or (a shared one under a hub that keeps them)
-- as the hub published it; nil while none was picked. No allocation.
local function OwnRgb(key)
	local p = Published(key)
	if p ~= nil then
		if not p then return nil end
		return Rgb(p.rgb)
	end
	local e = Entry(key)
	if not e then return nil end
	return Rgb(e.rgb)
end
Edge.OwnRgb = OwnRgb

-- (KIT.md 44) The colour the element's art is tinted with: its own on Custom (CUSTOM_START while none was picked), else
-- D1 - Purple's colour, and on Dark's black art no colour at all (the edge as it always was). r, g, b; no allocation.
function Edge.Tint(key)
	if ColourOf(key) == "custom" then
		local r, g, b = OwnRgb(key)
		if r then return r, g, b end
		return CUSTOM_START[1], CUSTOM_START[2], CUSTOM_START[3]
	end
	local c = Skin.GLOW
	return c[1], c[2], c[3]
end

-- The element's Strength and Spread (%): its own numbers, each falling back on its own to its declared one (KIT.md 25),
-- else (KIT.md 34) the kit's start, 40 and 100 - never a number another setting holds (nothing follows).
local function Numbers(key)
	local s, p = OwnNumbers(key)
	if s and p then return s, p end
	local ds, dp = DeclaredNumbers(key)
	return s or ds or START.strength, p or dp or START.spread
end

-- An element's look: colour ("purple" | "dark" | "none"), strength (0..1), spread (a multiplier of the reach) and whether
-- it shows. (KIT.md 34) Its own colour - Dark, Purple, or None, which shows nothing - and its numbers (Numbers: its own,
-- else declared, else the kit's start); an element's Strength is 5 - 100, so None is its only off. (Brief C2) A shared
-- one under a hub that keeps them: as the hub published it.
function Edge.Resolve(key)
	local colour = ColourOf(key)
	local s, p = Numbers(key)
	local spread = p / 100
	if colour == "none" then return "none", 0, spread, false end
	local strength = s / 100
	return colour, strength, spread, strength > 0
end

-- The art of one kind of piece in an element's colour (None: Dark's, KIT.md 34): "h" (a side's ramp, solid at its
-- left), "v" (the top's and the bottom's, solid at its bottom) or "c" (a corner, solid at its bottom left). key nil: an
-- element no one declared (Dark). For code that draws its own edge (HUI Menus' column).
local function ArtColour(key)
	local colour = Edge.Resolve(key)
	if Skin.GLOW_ART[colour] then return colour end
	return START.colour
end

function Skin.GlowTexture(kind, key)
	local art = Skin.GLOW_ART[ArtColour(key)]
	return art[kind] or art.h
end

-- ============================================================
-- THE GLOWS
-- ============================================================
local glows = {}         -- every glow, in the order made (its record: the pieces with their fields)
Skin.glows = glows       -- (to read: a test, a debug dump)
local byKey = {}         -- [key] = { glow, ... }
Edge.byKey = byKey
local pieceArt = {}      -- [piece] = { kind, texcoords }: its ramp ("h", "v", "c") and how it is laid
local recordOf = {}      -- [piece] = its glow
local painted = {}       -- [glow] = { colour, strength, shown }: what it was last painted with (Edge.Load repaints a
                         -- glow only when its element resolves to something else)
local unlit = {}         -- every Skin.Panel made with glow = false (Edge.Unlit), for Edge.Debug
local records = {}       -- [glow] = true for every glow registered (an outline may have no pieces yet: KIT.md 22)
local following, Follow = false, nil -- (THE SUITE'S EDGE, below: started by the first glow)
local LayOutline         -- (THE OUTLINE, below: an outline's pieces laid again, KIT.md 22)
local RefreshRows        -- (THE ROWS, below: every element's rows read again)

local RING = { "right", "left", "top", "bottom", "tr", "tl", "br", "bl" } -- Skin.Glow's pieces, in the order made
local CORNER = { tr = { "top", "right" }, tl = { "top", "left" }, br = { "bottom", "right" }, bl = { "bottom", "left" } }

-- Is piece i of a glow on its sides? (A side that is off hides its ramp and the two corners that turn into it.)
local function SideOn(glow, i)
	local sides = glow.sides
	if not sides then return true end
	if glow.kind ~= "ring" then return sides[glow.side] ~= false end
	local corner = CORNER[RING[i]]
	if corner then return sides[corner[1]] ~= false and sides[corner[2]] ~= false end
	return sides[RING[i]] ~= false
end

-- SPREAD (KIT.md 19, DESIGN-edges.md 10): one glow laid at spread s. The ramp reaches R = max(2, round(reach x s)) past
-- the frame and starts r = radius x min(1, s) inside it, so below 100 % the whole ramp - the corner's turn included - is
-- the same art drawn smaller and keeps its alpha at the glass (0.79 of the ramp's), and above 100 % only the reach grows
-- (the glass a little brighter: 0.85 at 150 %, 0.89 at 200 %). The sides run from r inside to R outside, inset by r at
-- both ends; the corners are (R + r) square. At 100 % every point is as it always was (R = the reach itself). Texture
-- calls only (ClearAllPoints, SetPoint, SetSize): safe in a fight. first: the glow is being made (no points to clear).
local function Layout(glow, s, first)
	glow.spread = s
	if glow.kind == "outline" then -- (KIT.md 22) laid again from its groups at R = max(2, round(reach x s))
		LayOutline(glow)
		return
	end
	local base, radius = glow.reach, glow.radius or 0
	local R = (s == 1) and base or math.max(2, math.floor(base * s + 0.5))
	local r = (s < 1) and radius * s or radius
	glow.R, glow.r = R, r
	if glow.kind == "edge" then
		local tex = glow[1]
		if glow.side == "bottom" then tex:SetHeight(R) else tex:SetWidth(R) end
		return
	end
	local frame = glow.anchor
	local reach = R + r -- (the outer offsets as reach - r: at 100 % the very numbers Skin.Glow has always laid)
	local right, left, top, bottom, tr, tl, br, bl = glow[1], glow[2], glow[3], glow[4], glow[5], glow[6], glow[7], glow[8]
	if not first then
		for i = 1, 8 do glow[i]:ClearAllPoints() end
	end
	right:SetPoint("TOPLEFT", frame, "TOPRIGHT", -r, -r)
	right:SetPoint("BOTTOMRIGHT", frame, "BOTTOMRIGHT", reach - r, r)
	left:SetPoint("TOPRIGHT", frame, "TOPLEFT", r, -r)
	left:SetPoint("BOTTOMLEFT", frame, "BOTTOMLEFT", r - reach, r)
	top:SetPoint("BOTTOMLEFT", frame, "TOPLEFT", r, -r)
	top:SetPoint("TOPRIGHT", frame, "TOPRIGHT", -r, reach - r)
	bottom:SetPoint("TOPLEFT", frame, "BOTTOMLEFT", r, r)
	bottom:SetPoint("BOTTOMRIGHT", frame, "BOTTOMRIGHT", -r, r - reach)
	tr:SetSize(reach, reach)
	tr:SetPoint("BOTTOMLEFT", frame, "TOPRIGHT", -r, -r)
	tl:SetSize(reach, reach)
	tl:SetPoint("BOTTOMRIGHT", frame, "TOPLEFT", r, -r)
	br:SetSize(reach, reach)
	br:SetPoint("TOPLEFT", frame, "BOTTOMRIGHT", -r, r)
	bl:SetSize(reach, reach)
	bl:SetPoint("TOPRIGHT", frame, "BOTTOMLEFT", r, r)
end

-- One glow painted as its element is now: the colour's art on every piece (its texcoords laid again) when the colour
-- moved, laid again when its Spread moved, the tint (D1; KIT.md 44: Custom's own colour, Edge.Tint) at 0.85 x
-- strength, and shown while the element shows, its owner
-- has not turned it off and its side is on. artOnly (a change of the Default's colour): the art and the tint alone, as
-- KIT.md 17 did. Never SetAlpha.
local function Paint(glow, artOnly)
	local colour, strength, spread, shown = Edge.Resolve(glow.key)
	if not artOnly and spread ~= glow.spread then Layout(glow, spread) end
	local art = Skin.GLOW_ART[colour]
	local relay = art ~= nil and glow.art ~= colour -- (after Layout: an outline laid again takes the art as it is now)
	local cr, cg, cb = Edge.Tint(glow.key)
	local a = Skin.GLOW_ALPHA * strength
	for i = 1, #glow do
		local tex = glow[i]
		if relay then
			local laid = pieceArt[tex]
			tex:SetTexture(art[laid[1]] or art.h)
			if laid[2] then tex:SetTexCoord(laid[2], laid[3], laid[4], laid[5]) end
		end
		tex:SetVertexColor(cr, cg, cb, a)
		if not artOnly then tex:SetShown(shown and strength > 0 and not glow.off and SideOn(glow, i)) end
	end
	if relay then glow.art = colour end
	local p = painted[glow]
	if not p then
		p = {}
		painted[glow] = p
	end
	p[1], p[2], p[3], p[4], p[5], p[6] = colour, strength, shown, cr, cg, cb
	return #glow
end

-- Does a glow carry its element's look as it resolves now? (Edge.Load leaves the ones that do alone.)
local function Current(glow)
	local p = painted[glow]
	if not p then return false end
	local colour, strength, spread, shown = Edge.Resolve(glow.key)
	if not (p[1] == colour and p[2] == strength and p[3] == shown and spread == glow.spread) then return false end
	local r, g, b = Edge.Tint(glow.key)
	return p[4] == r and p[5] == g and p[6] == b
end

local function Register(glow)
	glows[#glows + 1] = glow
	records[glow] = true
	for i = 1, #glow do recordOf[glow[i]] = glow end
	local key = glow.key
	if key ~= nil then
		local list = byKey[key]
		if not list then
			list = {}
			byKey[key] = list
		end
		list[#list + 1] = glow
	end
end

-- reach: how far past the frame (default GLOW_REACH; the base, before Spread); radius: how far inside it the ramp starts
-- (the frame's corner radius; 0 for a square frame); anchor: the region the ramp is laid round (the textures still
-- belong to the frame); key: its element. Returns the eight pieces.
function Skin.Glow(frame, reach, radius, anchor, key)
	Follow()
	local owner = frame
	frame = anchor or frame
	local colour = ArtColour(key)
	local art = Skin.GLOW_ART[colour]
	local pieces = {}
	local function Piece(kind, l, rr, t, b)
		local tex = owner:CreateTexture(nil, "BACKGROUND", nil, -7)
		tex:SetTexture(art[kind] or art.h)
		tex:SetTexCoord(l, rr, t, b)
		pieceArt[tex] = { kind, l, rr, t, b }
		pieces[#pieces + 1] = tex
		return tex
	end
	Piece("h", 0, 1, 0, 1)  -- right
	Piece("h", 1, 0, 0, 1)  -- left
	Piece("v", 0, 1, 0, 1)  -- top
	Piece("v", 0, 1, 1, 0)  -- bottom
	Piece("c", 0, 1, 0, 1)  -- tr
	Piece("c", 1, 0, 0, 1)  -- tl
	Piece("c", 0, 1, 1, 0)  -- br
	Piece("c", 1, 0, 1, 0)  -- bl
	pieces.key, pieces.kind, pieces.owner, pieces.anchor = key, "ring", owner, frame
	pieces.reach, pieces.radius, pieces.art = reach or Skin.GLOW_REACH, radius or 7, colour
	Layout(pieces, select(3, Edge.Resolve(key)), true)
	Register(pieces)
	Paint(pieces)
	return pieces
end

-- One ramp along one open edge ("right" or "bottom") of a surface whose other edges run off the screen (HUI Menus'
-- curtain band). Registered like a glow; returns the texture (Skin.GlowOf finds its record).
function Skin.EdgeGlow(frame, side, reach, key)
	Follow()
	local colour = ArtColour(key)
	local art = Skin.GLOW_ART[colour]
	local tex = frame:CreateTexture(nil, "BACKGROUND", nil, -7)
	if side == "bottom" then
		tex:SetTexture(art.v)
		tex:SetTexCoord(0, 1, 1, 0) -- solid at the top (on the glass), clear below
		pieceArt[tex] = { "v", 0, 1, 1, 0 }
		tex:SetPoint("TOPLEFT", frame, "BOTTOMLEFT", 0, 0)
		tex:SetPoint("TOPRIGHT", frame, "BOTTOMRIGHT", 0, 0)
	else
		tex:SetTexture(art.h)
		pieceArt[tex] = { "h" }
		tex:SetPoint("TOPLEFT", frame, "TOPRIGHT", 0, 0)
		tex:SetPoint("BOTTOMLEFT", frame, "BOTTOMRIGHT", 0, 0)
	end
	local glow = { tex, key = key, kind = "edge", side = side == "bottom" and "bottom" or "right", owner = frame,
		anchor = frame, reach = reach or Skin.GLOW_REACH, radius = 0, art = colour }
	Layout(glow, select(3, Edge.Resolve(key)), true) -- (its height, or its width: the reach at its Spread)
	Register(glow)
	Paint(glow)
	return tex
end

function Skin.GlowOf(tex)
	return recordOf[tex]
end

local function Record(glow)
	if type(glow) ~= "table" then return nil end
	if recordOf[glow] then return recordOf[glow] end -- an EdgeGlow's texture, or one piece
	if records[glow] then return glow end            -- the pieces' array itself (an outline's, KIT.md 22, even empty)
	return nil
end

-- The owner's own on and off: kept through every repaint, so no change of the edge brings back one its owner turned
-- off (HUI Menus' tooltips with HUI finish off: the game's own tooltip, as it was). Returns whether it was a glow.
function Skin.ShowGlow(glow, on)
	glow = Record(glow)
	if not glow then return false end
	glow.off = not on
	Paint(glow)
	return true
end

-- sides: { left = false, ... } (nil: all on). A side that is off hides its ramp and its two corners.
function Skin.SetGlowSides(glow, sides)
	glow = Record(glow)
	if not glow then return false end
	local copy
	if type(sides) == "table" then
		copy = {}
		for side, on in pairs(sides) do copy[side] = on end
	end
	glow.sides = copy
	Paint(glow)
	return true
end

-- A Skin.Panel with glow = false (its frame.skinGlowBy names the element that draws its edge, or frame.skinGlowWhy
-- says why it has none): noted for Edge.Debug.
function Edge.Unlit(frame)
	unlit[#unlit + 1] = frame
end

-- ============================================================
-- THE OUTLINE (KIT.md 22; kit/DESIGN-edges.md 9, Brief E): ONE edge round a group of frames that touch, on its outer
-- boundary only. Harry, Oct 1 2026, of HUI Meter's windows: "if there are 2 meter windows attached to each other, treat
-- them as one window with regards to the border. 3 windows in an L - like i say, treat all as 1 frame with regards to
-- the outer glow" (the approved picture meter/mockups/out/meter-edge-r1.png; its algorithm, make_meter_edge_r1.py
-- edge_pieces, is what this lays). Put another way: the light at a point is the ramp at that point's distance from the
-- group. Square (radius 0): the ramp starts at the boxes' very edges.
--   Skin.OutlinePieces(groups, R)  a pure function (below): the pieces of each group's outline, R deep
--   Skin.Outline(key, opts)        the edge itself, one record under its element's key, so its colour, strength and
--                                  Spread work on it as on any glow (opts.reach: its reach before Spread, 56 by default).
--     o:Set(groups)                lays it: groups = { { member, ... }, ... }, a member { frame, origin = { x, y }, rect
--                                  = { l, b, r, t } } in UIParent's units, y up: the frame its pieces ride on, where that
--                                  frame's bottom left corner is, and the box it counts as (one frame may be several
--                                  members). Each group has its own outline (a group dragged and the rest: two, so
--                                  nothing tears while one moves). Where boxes overlap, the first member listed owns
--                                  the edge along them: list a member that is drawn over the others first
--     o:Clear()                    takes it away
-- Its pieces are textures on each member frame's HOLDER (KIT.md 24): a plain child frame of that frame, over its whole
-- box, at BACKGROUND -7, anchored to the member frame's BOTTOMLEFT by (piece - origin): they ride every move of the frame,
-- fade with its alpha and hide with it. Each layout sets every holder's frame level to one above the highest member
-- frame of its group (read then: a toplevel member raised later needs o:Set again), so every member's shadow lies under
-- every piece of its group - a neighbour's 96-unit shadow drawn later never dims them at a seam - and as no piece lies in
-- a box of its group, none covers a member's glass. A pool of textures per frame; the ones a layout does not use are
-- hidden. A Spread change lays it again from o.groups. Texture calls and SetFrameLevel on our own plain holder frames
-- only (CreateFrame once per member frame): safe in a fight.
-- ============================================================
local OUT_EPS = 1e-6

-- The values of a list, sorted, each once (two closer than OUT_EPS are one).
local function Unique(list)
	table.sort(list)
	local out, n = {}, 0
	for i = 1, #list do
		local v = list[i]
		if n == 0 or v - out[n] > OUT_EPS then
			n = n + 1
			out[n] = v
		end
	end
	return out
end

-- A member's box (its rect, or the member itself as { l, b, r, t }): four finite numbers with some width and height;
-- nil for anything else.
local function MemberBox(m)
	if type(m) ~= "table" then return nil end
	local q = type(m.rect) == "table" and m.rect or m
	local l, b, r, t = q[1], q[2], q[3], q[4]
	if type(l) ~= "number" or type(b) ~= "number" or type(r) ~= "number" or type(t) ~= "number" then return nil end
	if not (r - l > OUT_EPS and t - b > OUT_EPS) then return nil end -- (NaN fails this too)
	if l < -1e7 or b < -1e7 or r > 1e7 or t > 1e7 then return nil end
	return l, b, r, t
end

-- (the dominance tests, below) The least and the most of (v - c)^2 for v in lo..hi.
local function MinSq(lo, hi, c)
	if c < lo then return (lo - c) * (lo - c) elseif c > hi then return (hi - c) * (hi - c) end
	return 0
end
local function MaxSq(lo, hi, c)
	return math.max((lo - c) * (lo - c), (hi - c) * (hi - c))
end
-- (v - s)^2 - (v - p)^2 = (p - s)(2v - s - p) for v in lo..hi: its least and its most (it is linear in v).
local function Span(lo, hi, s, p)
	local a, b = (p - s) * (2 * lo - s - p), (p - s) * (2 * hi - s - p)
	if a < b then return a, b end
	return b, a
end

local function Tc(v)
	return math.floor(v * 1e9 + 0.5) / 1e9
end

-- One group's outline. rects: { { l, b, r, t }, ... }; appends its pieces to out, each { kind, l, b, r, t, tc =
-- { left, right, top, bottom }, owner = the index of the box it belongs to }.
--   1. The grid of the boxes' edges; a cell is covered when its centre lies in a box (the first such box owns it).
--   2. The outline's features: each grid line's segments between a covered cell and a free one (a side's run, owned by
--      the box it borders), and each grid point's free quadrant whose two neighbours are free and whose opposite cell is
--      covered (an outside corner, owned by the box whose corner it is).
--   3. A finer grid: the boxes' edges, each R either side of them, and the middle between any two of them less than
--      2R apart. Each of its cells outside every box takes the features whose reach holds it (a run's: R off its side,
--      along its length; an outside corner's: the R x R square in its free quadrant) and keeps the nearest vertical run
--      and the nearest horizontal one (the middles make that one feature over the whole cell), and every outside corner
--      no other of them is nearer than everywhere in the cell (exact tests: the distances' squares differ by something
--      linear in x or in y). A run nearer than a corner everywhere in the cell drops the corner, and the other way about.
--   4. A cell's art: a vertical run and a horizontal one: the inside-corner piece "i" (the brighter of the two ramps,
--      exactly the light there: an inside corner of the group, the floor of a notch, or a run's end beside another);
--      one of them: its ramp ("h", "v"); and each corner kept: the kit's "c". Two pieces on one cell only where an
--      outside corner is kept with something no nearer everywhere (a narrow step's side running on under it; BLEND
--      gives about the brighter of the two there).
--   5. The cells of each piece (the same art from the same feature, the same owner) joined into rectangles, each laid
--      with its texcoords cut from the whole piece it is part of (a ramp R deep from its side, a corner R x R from its
--      point), so a ramp cut short or cut where it passes from one box to the next shows no seam.
-- The mockup's cases come out exactly as it laid them (its runs cut where they pass from one box to the next); a notch
-- (a run shorter than 2R with an inside corner at each end) and a narrow step (a run shorter than R from an inside
-- corner to an outside one) come out as kit/DESIGN-edges.md 9 asks: the inside pieces and the ramps facing each other
-- across the notch cut to half the gap; the step's inside piece cut to its run, the side running on over the rest of
-- that square under the whole outside corner.
local function OneOutline(rects, R, out)
	local n = #rects
	local xs, ys = {}, {}
	for k = 1, n do
		local q = rects[k]
		xs[#xs + 1] = q[1]
		xs[#xs + 1] = q[3]
		ys[#ys + 1] = q[2]
		ys[#ys + 1] = q[4]
	end
	xs, ys = Unique(xs), Unique(ys)
	local nx, ny = #xs - 1, #ys - 1
	local cov = {}
	for ci = 1, nx do
		local col, cx = {}, (xs[ci] + xs[ci + 1]) / 2
		for cj = 1, ny do
			local cy, who = (ys[cj] + ys[cj + 1]) / 2, false
			for k = 1, n do
				local q = rects[k]
				if q[1] < cx and cx < q[3] and q[2] < cy and cy < q[4] then
					who = k
					break
				end
			end
			col[cj] = who
		end
		cov[ci] = col
	end
	local function C(ci, cj)
		local col = cov[ci]
		return col and col[cj] or false
	end

	-- 2. the features
	local V, H, K = {}, {}, {}
	for gi = 1, #xs do
		for cj = 1, ny do
			local left, right = C(gi - 1, cj), C(gi, cj)
			if left and not right then
				V[#V + 1] = { line = gi, s = xs[gi], d = 1, lo = ys[cj], hi = ys[cj + 1], owner = left }
			elseif right and not left then
				V[#V + 1] = { line = gi, s = xs[gi], d = -1, lo = ys[cj], hi = ys[cj + 1], owner = right }
			end
		end
	end
	for gj = 1, #ys do
		for ci = 1, nx do
			local below, above = C(ci, gj - 1), C(ci, gj)
			if below and not above then
				H[#H + 1] = { line = gj, s = ys[gj], d = 1, lo = xs[ci], hi = xs[ci + 1], owner = below }
			elseif above and not below then
				H[#H + 1] = { line = gj, s = ys[gj], d = -1, lo = xs[ci], hi = xs[ci + 1], owner = above }
			end
		end
	end
	for gi = 1, #xs do
		for gj = 1, #ys do
			for dx = -1, 1, 2 do
				for dy = -1, 1, 2 do
					local qi, qj = dx > 0 and gi or gi - 1, dy > 0 and gj or gj - 1  -- the free quadrant's cell
					local oi, oj = dx > 0 and gi - 1 or gi, dy > 0 and gj - 1 or gj  -- the cells across its sides
					local across = C(oi, oj)
					if across and not C(qi, qj) and not C(oi, qj) and not C(qi, oj) then
						K[#K + 1] = { x = xs[gi], y = ys[gj], dx = dx, dy = dy, owner = across, n = #K + 1 }
					end
				end
			end
		end
	end

	-- 3. the finer grid
	local X, Y = {}, {}
	for _, pair in ipairs({ { xs, X }, { ys, Y } }) do
		local src, dst = pair[1], pair[2]
		for i = 1, #src do
			dst[#dst + 1] = src[i]
			dst[#dst + 1] = src[i] - R
			dst[#dst + 1] = src[i] + R
			for j = i + 1, #src do
				if src[j] - src[i] < 2 * R then dst[#dst + 1] = (src[i] + src[j]) / 2 end
			end
		end
	end
	X, Y = Unique(X), Unique(Y)
	local e = OUT_EPS
	local keys, byKey = {}, {}
	local function Note(key, kind, px, py, dx, dy, owner, a, b)
		local p = byKey[key]
		if not p then
			p = { kind = kind, px = px, py = py, dx = dx, dy = dy, owner = owner, cells = {} }
			byKey[key] = p
			keys[#keys + 1] = key
		end
		p.cells[#p.cells + 1] = { a, b }
	end
	local near = {}
	for a = 1, #X - 1 do
		local x0, x1 = X[a], X[a + 1]
		local cx = (x0 + x1) / 2
		for b = 1, #Y - 1 do
			local y0, y1 = Y[b], Y[b + 1]
			local cy = (y0 + y1) / 2
			local inside = false
			for k = 1, n do
				local q = rects[k]
				if q[1] < cx and cx < q[3] and q[2] < cy and cy < q[4] then
					inside = true
					break
				end
			end
			if not inside then
				-- the nearest vertical run whose reach holds the cell, and the nearest horizontal one
				local v, vd, h, hd
				for i = 1, #V do
					local f = V[i]
					if f.lo < cy and cy < f.hi then
						local ok
						if f.d > 0 then ok = x0 >= f.s - e and x1 <= f.s + R + e else ok = x0 >= f.s - R - e and x1 <= f.s + e end
						if ok then
							local dist = f.d * (cx - f.s)
							if not vd or dist < vd then v, vd = f, dist end
						end
					end
				end
				for i = 1, #H do
					local f = H[i]
					if f.lo < cx and cx < f.hi then
						local ok
						if f.d > 0 then ok = y0 >= f.s - e and y1 <= f.s + R + e else ok = y0 >= f.s - R - e and y1 <= f.s + e end
						if ok then
							local dist = f.d * (cy - f.s)
							if not hd or dist < hd then h, hd = f, dist end
						end
					end
				end
				-- the outside corners whose square holds it
				local nk = 0
				for i = 1, #K do
					local k = K[i]
					local okx = (k.dx > 0 and x0 >= k.x - e and x1 <= k.x + R + e) or (k.dx < 0 and x0 >= k.x - R - e and x1 <= k.x + e)
					if okx and ((k.dy > 0 and y0 >= k.y - e and y1 <= k.y + R + e) or (k.dy < 0 and y0 >= k.y - R - e and y1 <= k.y + e)) then
						nk = nk + 1
						near[nk] = k
					end
				end
				-- a run no corner is nearer than everywhere in the cell stays; so does a corner no run and no other corner is
				local vOn, hOn = v ~= nil, h ~= nil
				for i = 1, nk do
					local k = near[i]
					if vOn and MaxSq(y0, y1, k.y) <= Span(x0, x1, v.s, k.x) + e then vOn = false end
					if hOn and MaxSq(x0, x1, k.x) <= Span(y0, y1, h.s, k.y) + e then hOn = false end
				end
				if vOn and hOn then
					Note("i" .. v.line .. ":" .. v.d .. ":" .. h.line .. ":" .. h.d .. ":" .. h.owner, "i", v.s, h.s, v.d, h.d,
						h.owner, a, b)
				elseif vOn then
					Note("h" .. v.line .. ":" .. v.d .. ":" .. v.owner, "h", v.s, nil, v.d, nil, v.owner, a, b)
				elseif hOn then
					Note("v" .. h.line .. ":" .. h.d .. ":" .. h.owner, "v", nil, h.s, nil, h.d, h.owner, a, b)
				end
				for i = 1, nk do
					local k = near[i]
					local keep = true
					if v and select(2, Span(x0, x1, v.s, k.x)) <= MinSq(y0, y1, k.y) + e then keep = false end
					if keep and h and select(2, Span(y0, y1, h.s, k.y)) <= MinSq(x0, x1, k.x) + e then keep = false end
					if keep then
						for j = 1, nk do
							local o = near[j]
							-- (corner o no farther than k anywhere: d_o^2 - d_k^2 is linear, so its four corners say)
							if j ~= i then
								local ax, ay, sx, sy = k.x - o.x, k.y - o.y, o.x + k.x, o.y + k.y
								if ax * (2 * x0 - sx) + ay * (2 * y0 - sy) <= e and ax * (2 * x1 - sx) + ay * (2 * y0 - sy) <= e
									and ax * (2 * x0 - sx) + ay * (2 * y1 - sy) <= e and ax * (2 * x1 - sx) + ay * (2 * y1 - sy) <= e then
									keep = false
									break
								end
							end
						end
					end
					if keep then Note("c" .. k.n, "c", k.x, k.y, k.dx, k.dy, k.owner, a, b) end
				end
			end
		end
	end

	-- 5. each piece's cells joined into rectangles, along its run first (a side's ramp, "h", up its side: a narrow step's
	-- side runs on as one piece, its extension under the corner another; a top or a foot, "v", along it; a corner as
	-- "v"), each laid with its texcoords cut from the whole piece it is part of
	for _, key in ipairs(keys) do
		local p = byKey[key]
		local cells, up = p.cells, p.kind == "h"
		-- (major, minor): runs along minor, then the same run in the next major joins it. The cells came column by
		-- column (a, then b): for "h", rows first instead
		if up then
			table.sort(cells, function(c1, c2)
				if c1[2] ~= c2[2] then return c1[2] < c2[2] end
				return c1[1] < c2[1]
			end)
		end
		local major, minor = up and 2 or 1, up and 1 or 2
		local open, rects2 = {}, {}
		local i = 1
		while i <= #cells do
			local m = cells[i][major]
			local j = i
			while j <= #cells and cells[j][major] == m do j = j + 1 end
			local runs, s = {}, i
			for k = i + 1, j do
				if k == j or cells[k][minor] ~= cells[k - 1][minor] + 1 then
					runs[#runs + 1] = { cells[s][minor], cells[k - 1][minor] }
					s = k
				end
			end
			local next = {}
			for _, run in ipairs(runs) do
				local id = run[1] .. ":" .. run[2]
				local r = open[id]
				if r and r.m1 == m - 1 then
					r.m1 = m
				else
					r = { m0 = m, m1 = m, n0 = run[1], n1 = run[2] }
					rects2[#rects2 + 1] = r
				end
				next[id] = r
			end
			open = next
			i = j
		end
		for _, r in ipairs(rects2) do
			if up then r.a0, r.a1, r.b0, r.b1 = r.n0, r.n1, r.m0, r.m1 else r.a0, r.a1, r.b0, r.b1 = r.m0, r.m1, r.n0, r.n1 end
		end
		for _, r in ipairs(rects2) do
			local l, rr, bb, t = X[r.a0], X[r.a1 + 1], Y[r.b0], Y[r.b1 + 1]
			local tc
			if p.kind == "h" then
				tc = { Tc(p.dx * (l - p.px) / R), Tc(p.dx * (rr - p.px) / R), 0, 1 }
			elseif p.kind == "v" then
				tc = { 0, 1, Tc(1 - p.dy * (t - p.py) / R), Tc(1 - p.dy * (bb - p.py) / R) }
			else
				tc = { Tc(p.dx * (l - p.px) / R), Tc(p.dx * (rr - p.px) / R), Tc(1 - p.dy * (t - p.py) / R),
					Tc(1 - p.dy * (bb - p.py) / R) }
			end
			out[#out + 1] = { kind = p.kind, l = l, b = bb, r = rr, t = t, tc = tc, owner = p.owner }
		end
	end
end

function Skin.OutlinePieces(groups, R)
	local out = {}
	if type(groups) ~= "table" or type(R) ~= "number" or not (R > 0) or R > 1e6 then return out end
	for g = 1, #groups do
		local group = groups[g]
		if type(group) == "table" then
			local rects, index = {}, {}
			for m = 1, #group do
				local l, b, r, t = MemberBox(group[m])
				if l then
					rects[#rects + 1] = { l, b, r, t }
					index[#rects] = m
				end
			end
			if #rects > 0 then
				local first = #out + 1
				OneOutline(rects, R, out)
				for p = first, #out do
					local piece = out[p]
					piece.group, piece.member, piece.owner = g, index[piece.owner], nil
				end
			end
		end
	end
	return out
end

-- A member's frame (the one its pieces go on), or nil.
local function OutlineFrame(m)
	if type(m) ~= "table" then return nil end
	local frame = m.frame or m[1]
	if type(frame) == "table" and frame.CreateTexture then return frame end
	return nil
end

-- A frame's level as a plain number, or nil (never one the client would hand back secret).
local function PlainLevel(frame)
	if not frame.GetFrameLevel then return nil end
	local lv = frame:GetFrameLevel()
	if issecretvalue and issecretvalue(lv) then return nil end
	if type(lv) ~= "number" then return nil end
	return lv
end

-- (KIT.md 24) The level each member frame's holder is laid at: one above the highest member frame of its group (of every
-- group it is in).
local function HolderLevels(groups)
	local levels = {}
	if type(groups) ~= "table" then return levels end
	for g = 1, #groups do
		local group = groups[g]
		if type(group) == "table" then
			local top
			for m = 1, #group do
				local frame = OutlineFrame(group[m])
				local lv = frame and PlainLevel(frame)
				if lv and (not top or lv > top) then top = lv end
			end
			if top then
				for m = 1, #group do
					local frame = OutlineFrame(group[m])
					if frame and (not levels[frame] or levels[frame] < top + 1) then levels[frame] = top + 1 end
				end
			end
		end
	end
	return levels
end

-- The outline's pieces laid as o.groups and o.spread have them (o:Set, o:Clear, and Layout on a Spread change): each
-- piece on its member frame's holder from that frame's pool, each holder at its level, the rest of every pool hidden,
-- then each piece tinted and shown as the element resolves (the art in its colour, its texcoords cut from its whole
-- piece; never SetAlpha).
LayOutline = function(o)
	local s = o.spread or 1
	local R = (s == 1) and o.reach or math.max(2, math.floor(o.reach * s + 0.5))
	o.R, o.r = R, 0
	local pieces = o.groups and Skin.OutlinePieces(o.groups, R) or {}
	o.art = ArtColour(o.key)
	local art = Skin.GLOW_ART[o.art]
	for i = #o, 1, -1 do o[i] = nil end
	local used = {}
	local levels = HolderLevels(o.groups)
	for i = 1, #pieces do
		local p = pieces[i]
		local m = o.groups[p.group][p.member]
		local frame = OutlineFrame(m)
		local origin = type(m.origin) == "table" and m.origin or {}
		local ox, oy = origin.x or origin[1] or 0, origin.y or origin[2] or 0
		if frame then
			local pool = o.pools[frame]
			if not pool then
				pool = {}
				o.pools[frame] = pool
				o.frames[#o.frames + 1] = frame
			end
			local holder = o.holders[frame]
			if not holder then
				-- a plain frame of our own over the member's box: no mouse, nothing of its own but the pieces
				holder = CreateFrame("Frame", nil, frame)
				holder:SetAllPoints(frame)
				holder:EnableMouse(false)
				o.holders[frame] = holder
			end
			local n = (used[frame] or 0) + 1
			used[frame] = n
			if n == 1 and levels[frame] then holder:SetFrameLevel(levels[frame]) end
			local tex = pool[n]
			if not tex then
				tex = holder:CreateTexture(nil, "BACKGROUND", nil, -7)
				pool[n] = tex
				recordOf[tex] = o
				pieceArt[tex] = {}
			end
			local laid, tc = pieceArt[tex], p.tc
			laid[1], laid[2], laid[3], laid[4], laid[5] = p.kind, tc[1], tc[2], tc[3], tc[4]
			tex:SetTexture(art[p.kind] or art.h)
			tex:SetTexCoord(tc[1], tc[2], tc[3], tc[4])
			tex:ClearAllPoints()
			tex:SetPoint("BOTTOMLEFT", frame, "BOTTOMLEFT", p.l - ox, p.b - oy)
			tex:SetSize(p.r - p.l, p.t - p.b)
			o[#o + 1] = tex
		end
	end
	for f = 1, #o.frames do
		local frame = o.frames[f]
		local pool = o.pools[frame]
		for k = (used[frame] or 0) + 1, #pool do pool[k]:Hide() end
	end
	local colour, strength, _, shown = Edge.Resolve(o.key)
	local cr, cg, cb = Edge.Tint(o.key)
	local a = Skin.GLOW_ALPHA * strength
	local on = shown and strength > 0 and not o.off
	for i = 1, #o do
		o[i]:SetVertexColor(cr, cg, cb, a)
		o[i]:SetShown(on)
	end
	local p = painted[o]
	if not p then
		p = {}
		painted[o] = p
	end
	p[1], p[2], p[3], p[4], p[5], p[6] = colour, strength, shown, cr, cg, cb
	return #o
end

local function OutlineSet(o, groups)
	o.groups = type(groups) == "table" and groups or nil
	o.spread = select(3, Edge.Resolve(o.key))
	return LayOutline(o)
end

local function OutlineClear(o)
	o.groups = nil
	return LayOutline(o)
end

-- key: its element; opts.reach: how far it reaches past the boxes before Spread (GLOW_REACH, 56, by default).
function Skin.Outline(key, opts)
	Follow()
	local o = { key = key, kind = "outline", reach = (type(opts) == "table" and opts.reach) or Skin.GLOW_REACH,
		radius = 0, art = ArtColour(key), pools = {}, frames = {}, holders = {}, Set = OutlineSet, Clear = OutlineClear }
	o.spread = select(3, Edge.Resolve(key))
	Register(o)
	LayOutline(o)
	return o
end

-- ============================================================
-- WATCHING. Code that draws an edge of its own (HUI Menus' column) repaints when its element changes: fn(key) after
-- that element's look changed; key nil: after any.
-- ============================================================
local watchers, watchKeys, anyWatchers = {}, {}, {}
local told = {}          -- [key] = { colour, strength, spread, shown, r, g, b }: what its watchers last heard (Edge.Load;
                         -- KIT.md 44: the tint too, so a new Custom colour tells them)

function Edge.Watch(key, fn)
	if type(fn) ~= "function" then return false end
	local list = anyWatchers
	if key ~= nil then
		list = watchers[key]
		if not list then
			list = {}
			watchers[key] = list
			watchKeys[#watchKeys + 1] = key
			-- (what it would hear now: Edge.Load tells it only when its element resolves to something else)
			local t = {}
			t[1], t[2], t[3], t[4] = Edge.Resolve(key)
			t[5], t[6], t[7] = Edge.Tint(key)
			told[key] = t
		end
	end
	for i = 1, #list do if list[i] == fn then return true end end
	list[#list + 1] = fn
	return true
end

local function Call(fn, ...)
	if ns.Safe then return ns.Safe(fn, ...) end
	return pcall(fn, ...)
end

local function Heard(name)
	local t = told[name]
	if not t then
		t = {}
		told[name] = t
	end
	t[1], t[2], t[3], t[4] = Edge.Resolve(name)
	t[5], t[6], t[7] = Edge.Tint(name)
end

local function TellKey(name)
	Heard(name)
	local list = watchers[name]
	if list then for i = 1, #list do Call(list[i], name) end end
end

-- ============================================================
-- THE HUB'S ALL EDGES AS PUBLISHED (the old public names: Skin.glow, Skin.glowColour, Skin.SetGlow, Skin.SetGlowColour;
-- and Spread, 19). (KIT.md 34) There is no Default any more: no element takes these three. They are kept as the hub
-- publishes them, for code that reads the old names (and Edge.Debug's `default`); a change repaints nothing and tells no
-- watcher - it reads the rows again (an All edges compartment shows it).
-- ============================================================
function Skin.SetGlow(strength)
	local was = Skin.glow
	Skin.glow = strength or 0
	if Skin.glow ~= was then RefreshRows() end
end

-- "purple" or "dark" (a name the kit does not know: dark). Returns how many pieces were repainted: none (KIT.md 34).
function Skin.SetGlowColour(name)
	if not Skin.GLOW_ART[name] then name = START.colour end
	if name == Skin.glowColour then return 0 end
	Skin.glowColour = name
	RefreshRows()
	return 0
end

-- 0.2..2 (20 - 200 %; anything else is left alone). Returns how many glows were laid again: none (KIT.md 34).
function Skin.SetGlowSpread(mult)
	if type(mult) ~= "number" or mult ~= mult or mult < SPREAD[1] / 100 or mult > SPREAD[2] / 100 then return 0 end
	if mult == Skin.glowSpread then return 0 end
	Skin.glowSpread = mult
	RefreshRows()
	return 0
end

-- ============================================================
-- AN ELEMENT'S OWN VALUES (KIT.md 20, DESIGN-edges.md 3). The owner's setter and getter: one setting, wherever its rows
-- are (the addon's own page, or - Brief C2 - the hub's Edges page through Edge.Provider), and the hub keeps no copy.
-- ============================================================
-- The hub's Edges page re-reads the rows it draws (HUI Menus 0.7.1, Brief C2: ForeverSuiteOptions.RefreshEdges; nil
-- under an older hub, and with none).
local function TellHub()
	local suite = _G.ForeverSuiteOptions
	if type(suite) == "table" and type(suite.RefreshEdges) == "function" then Call(suite.RefreshEdges) end
end

-- colour, strength (%), spread (%) and own as the element has them (KIT.md 27; 34): its colour as chosen ("dark" |
-- "purple" | "none"); each number its own (saved), else its declared one (KIT.md 25), else the kit's start (40, 100) -
-- whatever the colour; own: true while either number is its own (its rows show Reset). (Brief C2) A shared one under a
-- hub that keeps them: as the hub published it. (KIT.md 44) Then r, g, b: its Custom colour (its own, else CUSTOM_START),
-- whatever colour it is on - what Custom draws and the wheel opens on (a kit before 44 gives none).
function Edge.Get(key)
	local colour = ColourOf(key)
	local s, p = Numbers(key)
	local os, op = OwnNumbers(key)
	local r, g, b = OwnRgb(key)
	if not r then r, g, b = CUSTOM_START[1], CUSTOM_START[2], CUSTOM_START[3] end
	return colour, s, p, (os ~= nil or op ~= nil), r, g, b
end

-- An element's change: its glows repainted (and laid again for a new Spread), its watchers told, the rows refreshed,
-- the hub told.
local function Changed(key)
	local list = byKey[key]
	if list then for i = 1, #list do Paint(list[i]) end end
	TellKey(key)
	for i = 1, #anyWatchers do Call(anyWatchers[i], key) end
	RefreshRows()
	TellHub()
end

-- The owner's setter (KIT.md 27): field "colour" (KIT.md 34: one of the three words - "default" is refused; KIT.md 44:
-- four, "custom" too) writes ONLY the colour, the numbers as they were; (KIT.md 44) "rgb" ({ r, g, b } 0..1, or nil to
-- clear it) writes ONLY the Custom colour, whatever colour is chosen; "strength" (5..100) or "spread" (20..200), rounded to 5 and kept in range, writes
-- that number, the element's own from then on; nil clears it (Reset: Edge.Set(key, "strength", nil) and (key, "spread",
-- nil)), back to its declared one, else the kit's start. A value the element has already writes nothing (no repaint, no
-- tell). Returns whether the value was taken. (Brief C2) A shared element under a hub that keeps them is the hub's to set
-- (its Edges page), never this addon's: refused (its own saved values stay, for a session without that hub).
function Edge.Set(key, field, value)
	if not Edge.Known(key) or Published(key) ~= nil then return false end
	local db = ns.db
	if type(db) ~= "table" then return false end
	local was = ColourOf(key)
	local ws, wp = OwnNumbers(key)
	local wr, wg, wb = OwnRgb(key)
	local colour, strength, spread = was, ws, wp
	local r, g, b = wr, wg, wb
	if field == "colour" then
		if type(value) ~= "string" or not COLOURS[value] then return false end
		colour = value
	elseif field == "rgb" then
		if value == nil then
			r, g, b = nil, nil, nil
		else
			r, g, b = Rgb(value)
			if not r then return false end
		end
	elseif field == "strength" or field == "spread" then
		local n = nil
		if value ~= nil then
			n = Num(value, field == "strength" and STRENGTH or SPREAD)
			if not n then return false end
		end
		if field == "strength" then strength = n else spread = n end
	else
		return false
	end
	if colour == was and strength == ws and spread == wp and r == wr and g == wg and b == wb then
		return true -- (as it is: nothing written, nothing repainted)
	end
	if type(db.edges) ~= "table" then db.edges = {} end
	db.edges[key] = { colour = colour, strength = strength, spread = spread, rgb = r and { r, g, b } or nil }
	Changed(key)
	return true
end

-- An element's row dims (still settable) while its surface cannot show its edge: its declaration's live() says false.
function Edge.State(key)
	local own = Own(key)
	if own and type(own.live) == "function" then
		local ok, live = pcall(own.live)
		if ok and live == false then return "dim" end
	end
	return "live"
end

-- The saved values made well-formed, in place (DESIGN-edges.md 3 "Validation"): an entry that is not a table, or whose
-- key this addon neither declares nor draws (nor keeps: ns.EDGES.keep, KIT.md 23), or whose colour is not one of the
-- three words, is dropped; numbers are put in range on a step of 5, and anything that is not a number (or is NaN) is
-- dropped, as is any other field. (KIT.md 34) A saved "default" becomes "dark", once and quietly (its numbers kept):
-- every edge that took the suite's Default starts Dark now. (KIT.md 44) rgb kept as { r, g, b } in 0..1 (on a step of
-- 1/255), dropped when it is not three numbers.
function Edge.Clean(t)
	if type(t) ~= "table" then return t end
	for key, e in pairs(t) do
		if type(e) == "table" and e.colour == "default" then e.colour = START.colour end
		if type(key) ~= "string" or not (Edge.Known(key) or Kept(key)) or type(e) ~= "table" or type(e.colour) ~= "string"
			or not COLOURS[e.colour] then
			t[key] = nil
		else
			for field in pairs(e) do
				if field ~= "colour" and field ~= "strength" and field ~= "spread" and field ~= "rgb" then e[field] = nil end
			end
			e.strength = Num(e.strength, STRENGTH)
			e.spread = Num(e.spread, SPREAD)
			local r, g, b = Rgb(e.rgb)
			e.rgb = r and { r, g, b } or nil
		end
	end
	return t
end

-- Every glow whose element now resolves to something else repainted, the watchers of every element that changed told,
-- the rows refreshed (Edge.Load; and, Brief C2, after the hub's edge arrives: its shared elements may have moved).
local function Sync()
	for i = 1, #glows do
		if not Current(glows[i]) then Paint(glows[i]) end
	end
	local changed = false
	for k = 1, #watchKeys do
		local name = watchKeys[k]
		local was = told[name]
		local colour, strength, spread, shown = Edge.Resolve(name)
		local r, g, b = Edge.Tint(name)
		if not was or was[1] ~= colour or was[2] ~= strength or was[3] ~= spread or was[4] ~= shown or was[5] ~= r
			or was[6] ~= g or was[7] ~= b then
			TellKey(name)
			changed = true
		end
	end
	if changed then
		for i = 1, #anyWatchers do Call(anyWatchers[i], nil) end
	end
	RefreshRows()
end

-- The saved values read (at ns.OnInit, and after the addon's reset - its nil-key broadcast): cleaned, every glow whose
-- element now resolves to something else repainted, the watchers of every element that changed told, the rows
-- refreshed, the hub told.
function Edge.Load()
	local t = Store()
	if t then Edge.Clean(t) end
	Sync()
	TellHub()
end

-- Every element of this addon back to what it starts at: ns.db.edges emptied, then Load.
function Edge.Reset()
	if type(ns.db) == "table" then ns.db.edges = {} end
	Edge.Load()
end

-- The addon's side of the hub's Edges page (Brief C2, HUI Menus 0.7.1; one line in its spec: `edges =
-- ns.Edge.Provider()`, harmless under an older hub): list() its OWN elements in order (never the shared five), each with
-- what it starts at (KIT.md 25: "purple" or "dark" too; the hub does not read it), get / set / state as above (set is the
-- owner's setter: the hub keeps no copy), reset(). (KIT.md 27: the same shape; get gives a fourth value, own, which a hub
-- before HUI Menus 0.7.4 never reads, and set takes nil for a number - Reset.) (KIT.md 32) An element without Default
-- is listed with noDefault = true (HUI Menus 0.7.8's Edges page builds its Colour < Dark | Purple | None >); (KIT.md 34)
-- that is every element now, and `default` is "dark" or "none". (KIT.md 44) get gives r, g, b after own (the Custom
-- colour) and set takes "colour" "custom" and "rgb" { r, g, b } (a kit before 44 refuses both: its row reads its colour
-- back).
function Edge.Provider()
	return {
		version = 1,
		list = function()
			local out = {}
			local own = Declared().own
			if type(own) == "table" then
				for i = 1, #own do
					local d = own[i]
					if type(d) == "table" and type(d.key) == "string" and not SHARED[d.key] then
						out[#out + 1] = { key = d.key, label = d.label, presentation = d.presentation,
							default = (DeclaredStart(d)), noDefault = true }
					end
				end
			end
			return out
		end,
		get = function(key) return Edge.Get(key) end,
		set = function(key, field, value) return Edge.Set(key, field, value) end,
		state = function(key) return Edge.State(key) end,
		reset = function() Edge.Reset() end,
	}
end

-- ============================================================
-- THE ROWS (KIT.md 20, 27; DESIGN-edges.md 8): an element's rows on a page of either lineage of the kit (page:Section
-- with { column, hideEmpty }, page.current, page:Row, row:SetControl, row:SetRowShown, the shared W.Stepper, W.Slider
-- with min, max, step and unit only, W.Button). Since 27 ONE FORMAT FOR EVERY EDGE (Harry, Oct 2: "single panel changes
-- should come in their own section and have the same options made available, in the same format"; the approved
-- UI/mockups/out/edges-r2.png): each element a compartment of its own, All edges' the same three rows.
--   <LABEL> EDGE                                        ALL EDGES   (Edge.AllSection, the hub's pages: KIT.md 34, it
--   Colour     < Dark | Purple | None >                 Colour     < Dark | Purple >      SETS every element at once)
--   Strength   [5 - 100 %]                              Strength   [5 - 100 %]
--   Spread     [20 - 200 %]                             Spread     [20 - 200 %]
--              [Reset]   while either number is the element's own
-- The sliders show the numbers the element draws with, its own or its start; moving one makes it the element's own,
-- Reset gives both back to its start (declared, else 40 and 100). None hides Strength, Spread and Reset. A compartment
-- whose rows are all hidden (shown() false: HUI Menus' rows that follow the presentation) takes no room (hideEmpty). A
-- row whose surface cannot show its edge now is drawn at 0.45 and stays settable. Rows refresh after every change of an
-- element, on the addon's every option change (its live() and shown() read again) and when their page is shown.
-- (KIT.md 32, 34) No element has Default: Colour < Dark | Purple | None > for every one (NO_DEFAULT_WORDS is WORDS).
-- (KIT.md 44) And Custom: < Dark | Purple | None | Custom >, All edges' < Dark | Purple | Custom >. Stepping onto Custom
-- sets it and opens the suite's colour wheel (ns.ColorPicker: the kit's Kit\ColorPicker.lua, HUI Menus' own) on the
-- element's colour; the wheel paints the edge live, Accept keeps it, Cancel gives back the colour and the Custom colour
-- it had. While Custom is chosen a swatch of it sits left of the stepper, a click opening the wheel again; a folded
-- line's summary has a small one too. All edges' wheel sets nothing until Accept: then every edge takes that colour
-- (its binding's "rgb", then "colour" "custom"); Cancel puts its stepper back.
-- ============================================================
local WORDS = { { "dark", "Dark" }, { "purple", "Purple" }, { "none", "None" }, { "custom", "Custom" } }
local NO_DEFAULT_WORDS = WORDS
local ALL_WORDS = { { "dark", "Dark" }, { "purple", "Purple" }, { "custom", "Custom" } }
local ALL_STRENGTH = STRENGTH -- (KIT.md 34: it sets every element's Strength, 5 - 100; until 34 the Default's, 0 - 100)
Edge.WORDS, Edge.ALL_WORDS, Edge.NO_DEFAULT_WORDS = WORDS, ALL_WORDS, NO_DEFAULT_WORDS
local DIM = 0.45
local RESET_HEIGHT = 28  -- (as the hub's other buttons in a row)
local rows = {}          -- every compartment's record made here (each element's, and All edges'), in the order made
local hookedPages = {}
Edge.rows = rows

local LOCAL = { get = Edge.Get, set = Edge.Set, state = Edge.State }
Edge.LOCAL = LOCAL

local function HubHasEdges()
	local suite = _G.ForeverSuiteOptions
	return type(suite) == "table" and type(suite.host) == "string" and suite.edges == 1
end
Edge.HubHasEdges = HubHasEdges

local function Label(key)
	local own = Own(key)
	if own and type(own.label) == "string" then return own.label end
	return Edge.SHARED_LABELS[key] or tostring(key)
end

-- (KIT.md 43) The line an element FOLDED under (the hub's Edges page, Harry, Oct 11: "make this more of a Click-To-Expand
-- menu because the more edges we have to adjust, the more this is going to look like noise"): a row of the compartment
-- the page is filling - its name, at its right a summary of what it draws ("Dark · 40 % · 100 %", or "None") and a
-- chevron (down while folded, up while open). A click anywhere on it asks to open or close it (want(open)); under the
-- pointer, and while it is open, its name and chevron are white. No box, no fill.
local FOLD_SUMMARY_W, FOLD_CHEV, FOLD_GAP, FOLD_INDENT = 150, 12, 8, 14
local FOLD_REST, FOLD_HOT = { 140 / 255, 140 / 255, 140 / 255 }, { 1, 1, 1 }
local FOLD_LABEL = { 214 / 255, 211 / 255, 222 / 255 } -- (the compartments' row label, Widgets' CP_LABEL)
local FOLD_CHIP, CHIP_GAP = 10, 6
local SWATCH_W, SWATCH_H, SWATCH_GAP = 22, 14, 8 -- (KIT.md 44) the Colour row's swatch, left of the stepper

-- (KIT.md 44) A swatch of a Custom colour: a dark hairline round the colour (no light seam), hidden until painted. A
-- frame, so the Colour row's can take a click (Swatch).
local function Chip(parent, w, h)
	local f = CreateFrame("Frame", nil, parent)
	f:SetSize(w, h)
	f.edge = f:CreateTexture(nil, "ARTWORK", nil, 0)
	f.edge:SetAllPoints(f)
	f.edge:SetColorTexture(0, 0, 0, 0.85)
	f.fill = f:CreateTexture(nil, "ARTWORK", nil, 1)
	f.fill:SetPoint("TOPLEFT", f, "TOPLEFT", 1, -1)
	f.fill:SetPoint("BOTTOMRIGHT", f, "BOTTOMRIGHT", -1, 1)
	f.fill:SetColorTexture(1, 1, 1, 1)
	f:Hide()
	return f
end

-- A chip shown in a colour, or hidden (r nil).
local function PaintChip(chip, r, g, b)
	if not chip then return end
	if type(r) == "number" and type(g) == "number" and type(b) == "number" then
		chip.fill:SetColorTexture(r, g, b, 1)
		chip.rgb = chip.rgb or {}
		chip.rgb[1], chip.rgb[2], chip.rgb[3] = r, g, b
		chip:Show()
	else
		chip:Hide()
	end
end
Edge.PaintChip = PaintChip

-- The Colour row's swatch: a chip that is a Button (a click: onClick), its hairline lit under the pointer.
local function Swatch(parent, onClick)
	local b = CreateFrame("Button", nil, parent)
	b:SetSize(SWATCH_W, SWATCH_H)
	b.edge = b:CreateTexture(nil, "ARTWORK", nil, 0)
	b.edge:SetAllPoints(b)
	b.edge:SetColorTexture(0, 0, 0, 0.85)
	b.fill = b:CreateTexture(nil, "ARTWORK", nil, 1)
	b.fill:SetPoint("TOPLEFT", b, "TOPLEFT", 1, -1)
	b.fill:SetPoint("BOTTOMRIGHT", b, "BOTTOMRIGHT", -1, 1)
	b.fill:SetColorTexture(1, 1, 1, 1)
	b:SetScript("OnEnter", function(self) self.edge:SetColorTexture(1, 1, 1, 0.6) end)
	b:SetScript("OnLeave", function(self) self.edge:SetColorTexture(0, 0, 0, 0.85) end)
	b:SetScript("OnClick", function() onClick() end)
	b:Hide()
	return b
end

local function FoldPaint(rec)
	local hot = rec.hot or rec.open
	local c = hot and FOLD_HOT or FOLD_LABEL
	rec.head.label:SetTextColor(c[1], c[2], c[3], 1)
	c = hot and FOLD_HOT or FOLD_REST
	rec.chevron:SetVertexColor(c[1], c[2], c[3], 1)
	if rec.open then rec.chevron:SetTexCoord(0, 1, 1, 0) else rec.chevron:SetTexCoord(0, 1, 0, 1) end
end

local function FoldHead(page, rec, label, want)
	local head = page:Row(label)
	local shows = CreateFrame("Frame", nil, head)
	shows:SetSize(FOLD_SUMMARY_W + FOLD_GAP + FOLD_CHEV, 20)
	rec.chevron = Skin.Icon(shows, "chevron", FOLD_CHEV, FOLD_REST)
	rec.chevron:SetPoint("RIGHT", shows, "RIGHT", 0, 0)
	rec.summary = Skin.Text(shows, "regular", 12, FOLD_REST, "RIGHT")
	rec.summary:SetPoint("RIGHT", rec.chevron, "LEFT", -FOLD_GAP, 0)
	rec.summary:SetWidth(FOLD_SUMMARY_W)
	-- (KIT.md 44) Custom's colour, a small swatch between the summary and the chevron (FoldSwatch)
	rec.chip = Chip(shows, FOLD_CHIP, FOLD_CHIP)
	rec.chip:SetPoint("RIGHT", rec.chevron, "LEFT", -FOLD_GAP, 0)
	head:SetControl(shows)
	-- the click: the whole line (under its words, which take no mouse)
	local hit = CreateFrame("Button", nil, head)
	hit:SetAllPoints(head)
	hit.cover = true -- (a click area under the row's own words, not a piece over them: _tools/lua-harness/hub_audit.lua)
	hit:SetScript("OnClick", function() want(not rec.open) end)
	hit:SetScript("OnEnter", function() rec.hot = true FoldPaint(rec) end)
	hit:SetScript("OnLeave", function() rec.hot = false FoldPaint(rec) end)
	rec.head, rec.hit, rec.shows = head, hit, shows
	head.onFind = function() want(true) end
	return head
end

-- One compartment in the one format: its title (pinned to `column` when given; no room while its rows are all hidden),
-- Colour, Strength, Spread and, with reset, the Reset row. set(field, value) is what a control calls. Returns its record:
-- section, note (its title line's note), row and stepper (Colour), strengthRow and strength, spreadRow and spread,
-- resetRow and reset. (KIT.md 43) fold = { label, where, want }: no compartment of its own - the element's line (FoldHead)
-- in the compartment the page is filling, its rows folded under it (their labels a little in), each row's Search place
-- `where` and its onFind opening it; rec.head, rec.summary (also rec.note), rec.chevron, rec.open (false).
local function Compartment(page, title, column, items, strengthRange, set, reset, fold)
	local W = ns.Widgets
	local rec = { page = page }
	if fold then
		FoldHead(page, rec, fold.label, fold.want)
		rec.note, rec.section, rec.open = rec.summary, page.current, false
	else
		local _, note = page:Section(title, { column = column, hideEmpty = true })
		rec.note, rec.section = note, page.current
	end
	rec.row = page:Row("Colour")
	rec.stepper = W.Stepper(rec.row, { items = items, onChange = function(value) set("colour", value) end })
	rec.row:SetControl(rec.stepper)
	-- (KIT.md 44) Custom's swatch, left of the stepper's left chevron (it follows the word's width)
	rec.swatch = Swatch(rec.row, function() set("wheel") end)
	rec.swatch:SetPoint("RIGHT", rec.stepper.left or rec.stepper, "LEFT", -SWATCH_GAP, 0)
	rec.strengthRow = page:Row("Strength")
	rec.strength = W.Slider(rec.strengthRow, { min = strengthRange[1], max = strengthRange[2], step = STEP, unit = "%" },
		function(value) set("strength", value) end)
	rec.strengthRow:SetControl(rec.strength)
	rec.spreadRow = page:Row("Spread")
	rec.spread = W.Slider(rec.spreadRow, { min = SPREAD[1], max = SPREAD[2], step = STEP, unit = "%" },
		function(value) set("spread", value) end)
	rec.spreadRow:SetControl(rec.spread)
	if reset then
		rec.resetRow = page:Row("")
		rec.reset = W.Button(rec.resetRow, "Reset", reset)
		rec.reset:SetHeight(RESET_HEIGHT)
		rec.resetRow:SetControl(rec.reset)
	end
	if fold then
		for _, row in ipairs({ rec.row, rec.strengthRow, rec.spreadRow, rec.resetRow }) do
			row.label:ClearAllPoints()
			row.label:SetPoint("LEFT", row, "LEFT", FOLD_INDENT, 0)
			row.label:SetWidth(math.max((row.label:GetWidth() or 0) - FOLD_INDENT, 40))
			row.where = fold.where
			row.onFind = rec.head.onFind
			row:SetFolded(true)
		end
		FoldPaint(rec)
	end
	return rec
end

-- (KIT.md 43) A folded element opened or closed: its rows shown under its line, or put away (Search finds them either way).
local function SetOpen(rec, open)
	if not rec.head then return end
	open = open and true or false
	rec.open = open
	for _, row in ipairs({ rec.row, rec.strengthRow, rec.spreadRow, rec.resetRow }) do row:SetFolded(not open) end
	FoldPaint(rec)
end
Edge.SetOpen = SetOpen

-- (KIT.md 44) The Colour row's swatch: shown in the Custom colour while the row shows and Custom is chosen.
local function PaintSwatch(rec, on, r, g, b)
	if not on or type(r) ~= "number" or type(g) ~= "number" or type(b) ~= "number" then
		rec.swatch:Hide()
		return
	end
	rec.swatch.fill:SetColorTexture(r, g, b, 1)
	rec.swatch.rgb = rec.swatch.rgb or {}
	rec.swatch.rgb[1], rec.swatch.rgb[2], rec.swatch.rgb[3] = r, g, b
	rec.swatch:Show()
end

-- All edges' rows: what its owner last set (binding.get() -> colour, strength %, spread %; KIT.md 44: then r, g, b, its
-- Custom colour). While its wheel is open its stepper and swatch are the wheel's (rec.picking).
local function RefreshAll(rec)
	local ok, colour, strength, spread, r, g, b = Call(rec.binding.get)
	if not ok then return end
	if rec.picking then return end
	if colour ~= nil then rec.stepper:SetValue(colour) end
	if type(strength) == "number" and not rec.strength.dragging then rec.strength:SetValue(strength) end
	if type(spread) == "number" and not rec.spread.dragging then rec.spread:SetValue(spread) end
	if type(r) ~= "number" then r, g, b = CUSTOM_START[1], CUSTOM_START[2], CUSTOM_START[3] end
	PaintSwatch(rec, colour == "custom", r, g, b)
end

local function RefreshRow(rec)
	if rec.all then return RefreshAll(rec) end
	local b = rec.binding
	local ok, colour, strength, spread, own, cr, cg, cb = Call(b.get, rec.key)
	if not ok then return end
	if type(cr) ~= "number" then cr, cg, cb = CUSTOM_START[1], CUSTOM_START[2], CUSTOM_START[3] end -- (a kit before 44)
	if colour == "default" then colour = START.colour end -- (KIT.md 34: a provider's kit before 34)
	rec.stepper:SetValue(colour)
	if type(strength) == "number" and not rec.strength.dragging then rec.strength:SetValue(strength) end
	if type(spread) == "number" and not rec.spread.dragging then rec.spread:SetValue(spread) end
	local shown = true
	if type(rec.shown) == "function" then
		local ok2, v = Call(rec.shown)
		shown = not ok2 or v ~= false
	end
	local numbers = shown and colour ~= "none"
	if rec.head then
		rec.head:SetRowShown(shown)
		local word = colour
		for _, w in ipairs(WORDS) do if w[1] == colour then word = w[2] end end
		if colour ~= "none" and type(strength) == "number" and type(spread) == "number" then
			word = string.format("%s \194\183 %d %% \194\183 %d %%", tostring(word), strength, spread)
		end
		rec.summary:SetText(tostring(word or ""))
		-- (KIT.md 44) Custom: its swatch between the summary and the chevron, the summary moved left of it
		local custom = colour == "custom"
		if custom ~= rec.chipOn then
			rec.chipOn = custom
			rec.summary:ClearAllPoints()
			if custom then
				rec.summary:SetPoint("RIGHT", rec.chip, "LEFT", -CHIP_GAP, 0)
				rec.summary:SetWidth(FOLD_SUMMARY_W - FOLD_CHIP - CHIP_GAP)
			else
				rec.summary:SetPoint("RIGHT", rec.chevron, "LEFT", -FOLD_GAP, 0)
				rec.summary:SetWidth(FOLD_SUMMARY_W)
			end
		end
		PaintChip(rec.chip, custom and cr, cg, cb)
	end
	PaintSwatch(rec, shown and colour == "custom", cr, cg, cb)
	rec.row:SetRowShown(shown)
	rec.strengthRow:SetRowShown(numbers)
	rec.spreadRow:SetRowShown(numbers)
	rec.resetRow:SetRowShown(numbers and own == true)
	local dim = false
	if type(b.state) == "function" then
		local ok3, state = Call(b.state, rec.key)
		dim = ok3 and state == "dim"
	end
	local a = dim and DIM or 1
	if rec.head then rec.head:SetAlpha(a) end
	rec.row:SetAlpha(a)
	rec.strengthRow:SetAlpha(a)
	rec.spreadRow:SetAlpha(a)
	rec.resetRow:SetAlpha(a)
end
Edge.RefreshRow = RefreshRow

RefreshRows = function()
	for i = 1, #rows do RefreshRow(rows[i]) end
end
Edge.RefreshRows = RefreshRows

local function RefreshPage(page)
	for i = 1, #rows do
		if rows[i].page == page then RefreshRow(rows[i]) end
	end
end

local function Keep(rec)
	rows[#rows + 1] = rec
	local page, frame = rec.page, rec.page.frame
	if frame and not hookedPages[page] and frame.HookScript then
		hookedPages[page] = true
		frame:HookScript("OnShow", function() RefreshPage(page) end)
	end
	RefreshRow(rec)
	return rec
end

-- One element's compartment on any page, bound to any owner: binding = { get, set, state } (nil: this addon's own -
-- Edge.Get, Set, State; the hub's Edges page binds another addon's provider, whose get may give no fourth value - a kit
-- before 27: no Reset); def = { label, title (default "<label> edge"), column = 1 | 2 (pinned), shown = fn } (all
-- optional: shown() false hides the whole compartment - HUI Menus' rows that follow the presentation; (KIT.md 32)
-- def.noDefault is accepted and, since 34, unread: every compartment's Colour is < Dark | Purple | None >). (KIT.md 43)
-- def.fold = true on a page in compartments whose rows fold (page.folds: HUI Menus' Kit\Widgets.lua since its 0.13.0,
-- the hub's Edges page): no compartment of its own but one line in the one the page is filling - the label (def.label,
-- else the element's; no " edge"), a summary and a chevron - its rows folded under it (elsewhere def.fold is unread); def.where is its rows' Search place (default "<label> edge"); def.onToggle(rec, open) is asked when its line
-- is clicked or Search finds one of its rows (nil: it opens and closes itself; Edge.SetOpen(rec, open) does it). An
-- addon's own page leaves fold out and keeps its compartment. Every control reads the owner's answer back after it
-- sets. Returns the record (Compartment's, and key, binding, shown, noDefault - true).
function Edge.Rows(page, binding, key, def)
	binding = binding or LOCAL
	def = def or {}
	local rec
	-- (KIT.md 44) The wheel on the element's Custom colour; stepped = it was opened by stepping onto Custom (which it
	-- sets first): Cancel then gives the colour back too - unless it is no longer Custom, or the click that cancelled it
	-- is on the stepper itself (it steps on from Custom: Dark < Custom > None, never back and forth). Live: each move of
	-- the wheel sets the colour.
	local function Wheel(stepped)
		local ok, colour, _, _, _, r, g, b = Call(binding.get, key)
		if not ok then return end
		if colour == "default" then colour = START.colour end
		local own = type(r) == "number" and not (r == CUSTOM_START[1] and g == CUSTOM_START[2] and b == CUSTOM_START[3])
		if type(r) ~= "number" then r, g, b = CUSTOM_START[1], CUSTOM_START[2], CUSTOM_START[3] end
		local wr, wg, wb = r, g, b
		if stepped then Call(binding.set, key, "colour", "custom") end
		RefreshRow(rec)
		local picker = ns.ColorPicker
		if not (picker and picker.Open) then return end
		local function Take(nr, ng, nb)
			Call(binding.set, key, "rgb", { nr, ng, nb })
			RefreshRow(rec)
		end
		rec.wheel = true
		picker.Open({ owner = rec.swatch, title = def.title or ((def.label or Label(key)) .. " edge"), r = r, g = g, b = b,
			onChange = Take,
			onAccept = function(nr, ng, nb)
				rec.wheel = nil
				Take(nr, ng, nb)
			end,
			onCancel = function()
				rec.wheel = nil
				Call(binding.set, key, "rgb", own and { wr, wg, wb } or nil)
				if stepped and colour ~= "custom" then
					local ok2, now = Call(binding.get, key)
					local st = rec.stepper
					local over = st.IsMouseOver and st:IsMouseOver()
					if ok2 and now == "custom" and not over then Call(binding.set, key, "colour", colour) end
				end
				RefreshRow(rec)
			end })
	end
	local function Set(field, value)
		if field == "wheel" then return Wheel(false) end
		if field == "colour" and value == "custom" then return Wheel(true) end
		-- (KIT.md 44) a step off Custom while its wheel is open: the wheel closed (its colour given back), then the step
		if rec.wheel and ns.ColorPicker and ns.ColorPicker.Close then ns.ColorPicker.Close() end
		rec.wheel = nil
		Call(binding.set, key, field, value)
		RefreshRow(rec)
	end
	local function Reset()
		Call(binding.set, key, "strength", nil)
		Call(binding.set, key, "spread", nil)
		RefreshRow(rec)
	end
	local fold
	if def.fold and page.folds then
		local label = def.label or Label(key)
		fold = { label = label, where = def.where or (label .. " edge"), want = function(open)
			if type(def.onToggle) == "function" then Call(def.onToggle, rec, open) else SetOpen(rec, open) end
		end }
	end
	rec = Compartment(page, def.title or ((def.label or Label(key)) .. " edge"), def.column, WORDS, STRENGTH, Set, Reset, fold)
	rec.key, rec.binding, rec.shown, rec.noDefault = key, binding, def.shown, true
	return Keep(rec)
end

-- (KIT.md 27; 34) ALL EDGES (Harry, Oct 2: "edge strength should be able to be applied to everything"), in the same
-- format: Colour < Dark | Purple >, Strength 5 - 100, Spread 20 - 200. Since 34 nothing follows it: it is the hub's
-- control that SETS every element at once - its binding = { get = function() return colour, strength %, spread % end,
-- set = function(field, value) end } ("colour", "strength", "spread") writes each element's own value through its owner
-- (HUI Menus' Options.lua, ns.ALL_EDGES), and get gives what it last set (shown here). Every place that shows it binds
-- the same owner (one setting), and the rows read it again whenever it changes. opts.column pins it. Returns the record.
function Edge.AllSection(page, binding, opts)
	opts = opts or {}
	local rec
	-- (KIT.md 44) All edges' wheel: nothing is set until Accept - then every edge takes the colour, Custom (the binding's
	-- "rgb", then "colour" "custom"); Cancel reads the binding again (its stepper back to what it last set).
	local function Wheel()
		local ok, _, _, _, r, g, b = Call(binding.get)
		if not ok then return end
		if type(r) ~= "number" then r, g, b = CUSTOM_START[1], CUSTOM_START[2], CUSTOM_START[3] end
		local picker = ns.ColorPicker
		if not (picker and picker.Open) then
			Call(binding.set, "rgb", { r, g, b })
			Call(binding.set, "colour", "custom")
			RefreshRow(rec)
			return
		end
		rec.picking = true
		rec.stepper:SetValue("custom")
		PaintSwatch(rec, true, r, g, b)
		picker.Open({ owner = rec.swatch, title = "All edges", r = r, g = g, b = b,
			onChange = function(nr, ng, nb) PaintSwatch(rec, true, nr, ng, nb) end,
			onAccept = function(nr, ng, nb)
				rec.picking = nil
				Call(binding.set, "rgb", { nr, ng, nb })
				Call(binding.set, "colour", "custom")
				RefreshRow(rec)
			end,
			onCancel = function()
				rec.picking = nil
				RefreshRow(rec)
				-- (a click on the stepper itself cancelled it: it steps on from Custom, as the element's rows do)
				local st = rec.stepper
				if st.IsMouseOver and st:IsMouseOver() then st:SetValue("custom") end
			end })
	end
	local function Set(field, value)
		if field == "wheel" or (field == "colour" and value == "custom") then return Wheel() end
		if rec.picking and ns.ColorPicker and ns.ColorPicker.Close then ns.ColorPicker.Close() end
		rec.picking = nil
		Call(binding.set, field, value)
		RefreshRow(rec)
	end
	rec = Compartment(page, "All edges", opts.column, ALL_WORDS, ALL_STRENGTH, Set, nil)
	rec.all, rec.binding = true, binding
	return Keep(rec)
end

-- (Brief C2) A page whose rows are gone (the hub's Edges page, built again for an addon that registered late): its
-- records dropped, so nothing reads them again. Returns how many there were.
function Edge.Forget(page)
	local n = 0
	for i = #rows, 1, -1 do
		if rows[i].page == page then
			table.remove(rows, i)
			n = n + 1
		end
	end
	return n
end

-- An element's page: one compartment per element (KIT.md 27; until then one "Edge" compartment for all), keys in order,
-- each a key or { key, shown = fn }; opts.shared = true (the addon's first page) adds the shared elements it draws while
-- no hub that lists them is there (DESIGN-edges.md 8; such a hub publishes ForeverSuiteOptions.edges = 1, Brief C2);
-- opts.column = 1 | 2 pins every one of them to a column of the hub's compartments. No element: nothing. Returns the
-- records.
function Edge.Section(page, keys, opts)
	opts = opts or {}
	local list = {}
	if type(keys) == "table" then
		for i = 1, #keys do
			local k = keys[i]
			if type(k) == "table" then
				local key = k.key or k[1]
				if type(key) == "string" then list[#list + 1] = { key = key, shown = k.shown } end
			elseif type(k) == "string" then
				list[#list + 1] = { key = k }
			end
		end
	end
	if opts.shared and not HubHasEdges() then
		local uses = Declared().uses
		if type(uses) == "table" then
			for i = 1, #uses do
				if SHARED[uses[i]] then list[#list + 1] = { key = uses[i] } end
			end
		end
	end
	if #list == 0 then return nil end
	local recs = {}
	for i = 1, #list do recs[i] = Edge.Rows(page, nil, list[i].key, { shown = list[i].shown, column = opts.column }) end
	return recs
end

-- The addon's saved values arrive with its ns.OnInit, and come back after its reset through its nil-key broadcast (every
-- kit addon's ns.OnOption tells its listeners (nil) then); any other change of its options may change a row's live() or
-- shown(): its own rows read again, and (KIT.md 23, the review's #4) the hub told, whose Edges page draws this addon's
-- rows too and reads them again only when told (at once while it shows: `/hquests vendor blizzard` typed with it open
-- dims the Vendor row there). The host's own kit is not told twice: its rows - the Edges page's among them - are the
-- ones it reads again. Lua tables only: no frame, no event (HUI Assign on another class stays dormant).
if type(ns.OnInit) == "function" then
	ns.OnInit(function() Edge.Load() end)
end
if type(ns.OnOption) == "function" then
	ns.OnOption(function(path)
		if path == nil then
			Edge.Load()
		else
			if #rows > 0 then RefreshRows() end
			if not IsHost() then TellHub() end
		end
	end)
end

-- ============================================================
-- THE SUITE'S EDGE, FOLLOWED (KIT.md 17, 19, 20; 34). The HUI hub (HUI Menus) publishes ForeverSuiteOptions.edge = {
-- strength = 0..1, colour = "purple" | "dark", spread = 0.2..2 (HUI Menus 0.7.0; since KIT.md 34 what its All edges last
-- set - no element takes them), elements = { the five shared elements, each { colour, strength, spread } } (0.7.1, with
-- ForeverSuiteOptions.edges = 1) } and calls the functions given to ForeverSuiteOptions.OnEdgeChanged on every change
-- (fn(strength, colour, spread); the protocol is in UI/ForeverMenus/Hub.lua). This kit takes any call as "read .edge
-- again". The kit follows it BY ITSELF in every addon that carries it, so no addon has code of its own for it. It starts
-- with the first glow the addon draws (an addon that draws none - HUI Assign on another class - makes nothing and hears
-- nothing), the way Blizzard's EventUtil.ContinueOnPlayerLogin waits: logged in already (IsLoggedIn is true from the
-- moment PLAYER_LOGIN begins to be signalled), at once; else at PLAYER_LOGIN, on one small frame that lets the event go
-- when it comes. Either way every addon's ADDON_LOADED has run, so either load order works. Then it takes the hub's edge
-- and listens for its changes: the three kept under the old names (Skin.glow, glowColour, glowSpread), and (Brief C2)
-- the glows of the shared elements the hub keeps repainted as it published them (Sync). The host's own kit
-- (ns.KIT.edgeHost, HUI Menus) follows nothing and makes no frame. Skin.FollowSuite() is what it runs (a test may call
-- it).
-- ============================================================
local function TakeEdge(strength, colour, spread)
	local suite = _G.ForeverSuiteOptions
	local edge = type(suite) == "table" and suite.edge
	if type(edge) == "table" then strength, colour, spread = edge.strength, edge.colour, edge.spread end
	if type(strength) == "number" and strength >= 0 and strength <= 1 and strength ~= Skin.glow then Skin.SetGlow(strength) end
	if colour == "purple" or colour == "dark" then Skin.SetGlowColour(colour) end
	if spread == nil then spread = 1 end
	Skin.SetGlowSpread(spread)
	-- (Brief C2) a hub that keeps the shared elements publishes them (.edge.elements): every glow whose element now
	-- resolves to something else repainted, its watchers told, the rows read again (an older hub: nothing moves)
	Sync()
end

-- Returns true when there was a hub's edge to take or to listen to.
function Skin.FollowSuite()
	local suite = _G.ForeverSuiteOptions
	if type(suite) ~= "table" or type(suite.host) ~= "string" or suite.host == ADDON then return false end
	local edge = suite.edge
	if type(edge) == "table" then TakeEdge(edge.strength, edge.colour, edge.spread) end
	if type(suite.OnEdgeChanged) ~= "function" then return type(edge) == "table" end
	suite.OnEdgeChanged(TakeEdge)
	return true
end

local function RunFollow()
	if ns.Safe then ns.Safe(Skin.FollowSuite) else pcall(Skin.FollowSuite) end
end

-- (Skin.Glow and Skin.EdgeGlow ask this first, so a glow is made with the edge as the hub has it.) (KIT.md 33) Also
-- Edge.Follow: an addon that draws an edge of its own (Edge.Watch, Skin.GlowTexture) and may draw no kit glow at all -
-- HUI Cooldowns' tiles inside the hub, whose settings live on the hub's page - starts following the hub's edge itself,
-- once, when it first paints; as the first glow would. Calling it again (or a glow made later) does nothing more.
Follow = function()
	if following then return end
	following = true
	if IsHost() then return end
	if IsLoggedIn and IsLoggedIn() then
		RunFollow()
		return
	end
	local frame = CreateFrame("Frame")
	frame:RegisterEvent("PLAYER_LOGIN")
	frame:SetScript("OnEvent", function(self)
		self:UnregisterEvent("PLAYER_LOGIN")
		RunFollow()
	end)
end
function Edge.Follow() Follow() end
function Edge.Following() return following end

-- ============================================================
-- THE REGISTRY (DESIGN-edges.md 5, 12): what the addon declares and what it drew, for its /debug and the tests.
--   keys      the declared elements, in order: own, the shared ones it uses, and (the host) the rest of the shared five
--   glows     [key] = how many glows carry it        drawn    [key] = how many draw it themselves (Edge.Watch)
--   untagged  the owners of glows with no key        unknown  [key] = glows whose key is not this addon's
--   noReason  glow = false panels with neither glowBy nor glowWhy    badBy  glowBy naming a key not this addon's
--   missing   declared elements with no glow and no one drawing them, PENDING aside (once every surface was opened)
--   pending   the PENDING ones                        off      pieces hidden by their owner (ShowGlow) or a side
--   setAlpha  SetAlpha calls on a glow piece, as the offline mock counts them (nil in the game)
--   default   the hub's All edges as published (KIT.md 34: nothing takes it): strength, colour, spread
--   saved     [key] = the colour saved for it (ns.db.edges)
--   rows      how many edge compartments this addon has made (KIT.md 27: each element's, and All edges')
--   refused   (KIT.md 25; 34) own elements whose declared start was refused, in order: a word other than "dark" or
--             "none" ("default", "purple": each starts Dark), or a Strength or Spread that is no number (the kit's)
--   noDefault (KIT.md 32; 34) own elements without Default, in order: every one
-- ============================================================
local function Name(f)
	if type(f) ~= "table" then return tostring(f) end
	local ok, name = pcall(function() return f:GetName() end)
	if ok and type(name) == "string" then return name end
	return tostring(f)
end

function Edge.Debug()
	local d = { addon = ADDON, host = IsHost(), keys = {}, glows = {}, drawn = {}, untagged = {}, unknown = {},
		noReason = {}, badBy = {}, missing = {}, pending = {}, off = 0, count = #glows, unlit = #unlit,
		default = { strength = Skin.glow, colour = Skin.glowColour, spread = Skin.glowSpread }, saved = {}, rows = #rows,
		refused = {}, noDefault = {} }
	local seen = {}
	local function Add(key)
		if type(key) == "string" and not seen[key] then
			seen[key] = true
			d.keys[#d.keys + 1] = key
		end
	end
	local decl = Declared()
	if type(decl.own) == "table" then
		for i = 1, #decl.own do
			local o = decl.own[i]
			Add(type(o) == "table" and o.key)
			if DeclaredRefused(o) then d.refused[#d.refused + 1] = tostring(o.key) end
			if type(o) == "table" then d.noDefault[#d.noDefault + 1] = tostring(o.key) end
		end
	end
	if type(decl.uses) == "table" then for i = 1, #decl.uses do Add(decl.uses[i]) end end
	local drawsShared = {}
	if type(decl.uses) == "table" then for i = 1, #decl.uses do drawsShared[decl.uses[i]] = true end end
	if IsHost() then for i = 1, #Edge.SHARED do Add(Edge.SHARED[i]) end end
	for i = 1, #glows do
		local glow = glows[i]
		local key = glow.key
		if key == nil then
			d.untagged[#d.untagged + 1] = Name(glow.owner)
		else
			d.glows[key] = (d.glows[key] or 0) + 1
			if not Edge.Known(key) then d.unknown[key] = (d.unknown[key] or 0) + 1 end
		end
		for j = 1, #glow do
			if glow.off or not SideOn(glow, j) then d.off = d.off + 1 end
		end
	end
	for i = 1, #unlit do
		local f = unlit[i]
		if f.skinGlowBy == nil and f.skinGlowWhy == nil then
			d.noReason[#d.noReason + 1] = Name(f)
		elseif f.skinGlowBy ~= nil and not Edge.Known(f.skinGlowBy) then
			d.badBy[#d.badBy + 1] = tostring(f.skinGlowBy)
		end
	end
	for i = 1, #watchKeys do d.drawn[watchKeys[i]] = #watchers[watchKeys[i]] end
	for i = 1, #d.keys do
		local key = d.keys[i]
		-- (the host's shared keys it does not draw itself are its to keep for the others: not missing)
		local owes = Own(key) ~= nil or drawsShared[key]
		if Edge.PENDING[key] then
			d.pending[#d.pending + 1] = key
		elseif owes and not d.glows[key] and not d.drawn[key] then
			d.missing[#d.missing + 1] = key
		end
	end
	local t = Store()
	if t then for key, e in pairs(t) do if type(e) == "table" then d.saved[tostring(key)] = e.colour end end end
	local counted = _G.MOCK_GLOW_SETALPHA
	d.setAlpha = type(counted) == "table" and #counted or nil
	return d
end
