local ADDON, ns = ...

-- ============================================================
-- THE WINDOW, in HUI's look: the kit's panel (Skin.Panel: the black glass, its lit edge, its shadow, the purple edge -
-- Dark, as every HUI edge starts), Arial Narrow, the head in tracked capitals, the purple accent for the state word. A
-- plain frame: nothing protected, it opens and closes in a fight too (Apply waits for the fight's end by itself).
--
--   MAIN   what this character has: the preset applied (its name, class and race, when) and where it stands - "Train
--          N" (0.1.2: the spells to buy at the trainer now, listed by name and rank on the row's hover - the window's one
--          tooltip, plain), "Up to date", "All placed", or "Updated" with Apply beside it; every preset of this class,
--          each with Apply; a box to paste a string ("Import From String") and Load it; Export (0.1.2): the bars now
--          as a string, in a box below, selected for Ctrl+C.
--   ASK    (Apresets.lua P.Ask) the presets that match, the first picked (a click picks another), and Apply | Not now |
--          Never. Escape, the close cross and Not now all mean Not now: asked again at the next login.
--   TIDY   (0.1.8, /presets tidy) the duplicate character macros on no bar (Apply.lua P.TidyList): each by its name (a
--          nameless one by its spell), the spell beside it; Remove, then "Remove N?" Yes | No. None: "None".
-- One or two plain words a label, no lines that explain, no pills; a refusal in the suite's pink (226, 120, 186).
-- ============================================================

local Skin, W = ns.Skin, ns.Widgets
local NAMES = ns.NAMES

local Win = {}
ns.Window = Win
Win.W, Win.PAD, Win.ROW = 300, 14, 24
Win.ACCENT = { 176 / 255, 132 / 255, 240 / 255 }          -- the HUI purple lifted for text
Win.PINK = { 226 / 255, 120 / 255, 186 / 255 }
Win.status = { opens = 0, mode = nil, picked = nil, message = nil }

local f
local rows = {}

local RACE_WORDS = { Scourge = "Undead", NightElf = "Night Elf", BloodElf = "Blood Elf", HighmountainTauren = "Highmountain",
	LightforgedDraenei = "Lightforged", ZandalariTroll = "Zandalari", KulTiran = "Kul Tiran", DarkIronDwarf = "Dark Iron",
	MagharOrc = "Mag'har", VoidElf = "Void Elf" }
function Win.RaceWord(race)
	if type(race) ~= "string" then return nil end
	return RACE_WORDS[race] or (string.gsub(race, "(%l)(%u)", "%1 %2"))
end

local function Who(l)
	local class = NAMES.classes[l.class] or l.class
	local race = Win.RaceWord(l.race)
	return race and (race .. " " .. class) or class
end

-- ------------------------------------------------------------
-- The parts
-- ------------------------------------------------------------
local function Row(i)
	if rows[i] then return rows[i] end
	local r = CreateFrame("Button", nil, f)
	r:SetHeight(Win.ROW)
	r.plate = Skin.Fill(r, Skin.A.plate)
	r.plate:Hide()
	r.name = Skin.Text(r, "regular", 13, Skin.C.body)
	r.name:SetPoint("LEFT", r, "LEFT", 8, 0)
	r.who = Skin.Text(r, "regular", 12, Skin.C.mut)
	r.who:SetPoint("LEFT", r.name, "RIGHT", 6, 0)
	r.apply = Skin.Button(r, NAMES.apply, function() if r.entry then ns.Presets.Apply(r.entry.layout) end end)
	r.apply:SetPoint("RIGHT", r, "RIGHT", -2, 0)
	r:SetScript("OnClick", ns.Wrap(function()
		if Win.status.mode == "ask" then
			Win.status.picked = r.index
			Win.Refresh()
		end
	end))
	rows[i] = r
	return r
end

local function Build()
	if f then return f end
	f = CreateFrame("Frame", NAMES.framePrefix .. "Window", UIParent)
	f:Hide()
	f:SetFrameStrata("DIALOG")
	f:SetToplevel(true)
	f:EnableMouse(true)
	f:SetMovable(true)
	f:SetWidth(Win.W)
	f:SetPoint("CENTER", UIParent, "CENTER", 0, 80)
	Skin.Panel(f, { glowReach = 16, glowKey = "window" })
	f.head = Skin.Tracked(f, NAMES.head, "medium", 11, Skin.C.text, 3)
	f.head:SetPoint("LEFT", f, "TOPLEFT", Win.PAD, -(Win.PAD + 6))
	f.close = Skin.IconButton(f, "close", 20, function() f:Hide() end)
	f.close:SetPoint("TOPRIGHT", f, "TOPRIGHT", -8, -8)
	-- the preset applied
	f.name = Skin.Text(f, "regular", 15, Skin.C.text)
	f.who = Skin.Text(f, "regular", 12, Skin.C.mut)
	f.when = Skin.Text(f, "regular", 11, Skin.C.faint)
	f.state = Skin.Text(f, "regular", 12, Win.ACCENT, "RIGHT")
	f.again = Skin.Button(f, NAMES.apply, function()
		local a = ns.Presets.Applied()
		local e = a and ns.Presets.Find(a.class, a.name)
		if e then ns.Presets.Apply(e.layout) end
	end)
	f.rule = Skin.Fill(f, Skin.A.rule)
	f.rule:SetHeight(1)
	-- (0.1.2) the row's hover while there is something to buy: the spells by name and rank, plain
	f.trainHit = CreateFrame("Frame", nil, f)
	f.trainHit:SetHeight(20)
	f.trainHit:EnableMouse(true)
	f.trainHit:Hide()
	f.trainHit:SetScript("OnEnter", ns.Wrap(function(self) Win.ShowTrain(self) end))
	f.trainHit:SetScript("OnLeave", function(self) if GameTooltip:GetOwner() == self then GameTooltip:Hide() end end)
	-- the paste box
	f.paste = Skin.SearchBox(f, function() Win.status.message = nil; if f.msg then f.msg:SetText("") end end,
		{ hint = NAMES.paste, icon = false })
	f.paste.edit:SetMaxLetters(0)
	f.load = Skin.Button(f, NAMES.load, function() Win.LoadPasted() end)
	-- (0.1.2) Export, and the box that holds its string (selected, ready for Ctrl+C; typing never changes it)
	f.export = Skin.Button(f, NAMES.export, function() Win.Export() end)
	f.out = Skin.SearchBox(f, nil, { hint = "", icon = false })
	f.out.edit:SetMaxLetters(0)
	f.out.edit:SetScript("OnTextChanged", function(self, user)
		local str = Win.status.exported
		if user and str and self:GetText() ~= str then
			self:SetText(str)
			self:HighlightText()
		end
	end)
	f.out.edit:SetScript("OnEditFocusGained", function(self) self:HighlightText() end)
	f.out.edit:SetScript("OnEscapePressed", function(self) self:ClearFocus() end)
	f.out:SetScript("OnMouseDown", function() f.out.edit:SetFocus() end)
	f.msg = Skin.Text(f, "regular", 12, Win.PINK)
	-- the ask's three
	f.yes = W.Button(f, NAMES.apply, function() Win.ApplyPicked() end, "primary")
	f.notNow = W.Button(f, NAMES.notNow, function() ns.Presets.NotNow() end)
	f.never = W.Button(f, NAMES.never, function() ns.Presets.Never() end)
	-- (0.1.8) tidy: Remove, then its confirm
	f.remove = W.Button(f, NAMES.remove, function() Win.status.confirm = true; Win.Refresh() end)
	f.ask = Skin.Text(f, "regular", 13, Skin.C.text)
	f.yesTidy = W.Button(f, NAMES.yes, function() Win.TidyYes() end, "primary")
	f.noTidy = W.Button(f, NAMES.no, function() Win.status.confirm = nil; Win.Refresh() end)
	f.none = Skin.Text(f, "regular", 13, Skin.C.mut)
	f:SetScript("OnHide", ns.Wrap(function() Win.status.mode = nil; Win.status.confirm = nil end))
	ns.Drag.Attach(f, { point = "TOPLEFT" })
	table.insert(UISpecialFrames, f:GetName())
	Win.frame = f
	return f
end

-- ------------------------------------------------------------
-- Laying it out
-- ------------------------------------------------------------
local function List()
	if Win.status.mode == "ask" then return ns.Presets.Matches() end
	return ns.Presets.ForClass(ns.LayoutEngine.MyClass())
end

function Win.Refresh()
	if not f or not f:IsShown() then return end
	local tidy = Win.status.mode == "tidy"
	f.head:SetText(tidy and NAMES.tidyHead or NAMES.head)
	for _, part in ipairs({ f.remove, f.ask, f.yesTidy, f.noTidy, f.none }) do part:Hide() end
	if tidy then return Win.RefreshTidy() end
	local ask = Win.status.mode == "ask"
	local P = ns.Presets
	local y = -(Win.PAD + 22)
	local a = P.Applied()
	-- the preset applied (the main window only)
	local showTop = not ask
	for _, part in ipairs({ f.name, f.who, f.when, f.state, f.rule }) do part:SetShown(showTop) end
	f.again:Hide()
	f.trainHit:Hide()
	if showTop then
		f.name:ClearAllPoints()
		f.name:SetPoint("TOPLEFT", f, "TOPLEFT", Win.PAD, y)
		f.name:SetText(a and a.name or NAMES.none)
		f.name:SetTextColor(a and Skin.C.text[1] or Skin.C.mut[1], a and Skin.C.text[2] or Skin.C.mut[2],
			a and Skin.C.text[3] or Skin.C.mut[3])
		f.who:ClearAllPoints()
		f.who:SetPoint("LEFT", f.name, "RIGHT", 6, 0)
		f.who:SetText(a and Who(a) or "")
		f.state:ClearAllPoints()
		f.state:SetPoint("TOPRIGHT", f, "TOPRIGHT", -Win.PAD, y - 2)
		f.state:SetText(P.StateWords())
		local state = P.State()
		if state == "updated" then
			f.again:ClearAllPoints()
			f.again:SetPoint("RIGHT", f.state, "LEFT", -8, 0)
			f.again:Show()
		elseif state == "train" then
			f.trainHit:ClearAllPoints()
			f.trainHit:SetPoint("TOPLEFT", f, "TOPLEFT", Win.PAD, y + 2)
			f.trainHit:SetPoint("TOPRIGHT", f, "TOPRIGHT", -Win.PAD, y + 2)
			f.trainHit:Show()
		end
		y = y - 20
		f.when:ClearAllPoints()
		f.when:SetPoint("TOPLEFT", f, "TOPLEFT", Win.PAD, y)
		local at = a and ns.Num(a.at)
		f.when:SetText(at and at > 0 and (ns.Call(date, "%d %b %Y", at) or "") or "")
		y = y - 22
		f.rule:ClearAllPoints()
		f.rule:SetPoint("TOPLEFT", f, "TOPLEFT", Win.PAD, y)
		f.rule:SetPoint("TOPRIGHT", f, "TOPRIGHT", -Win.PAD, y)
		y = y - 8
	end
	-- the list
	local list = List()
	if ask and (not Win.status.picked or not list[Win.status.picked]) then Win.status.picked = 1 end
	for i, e in ipairs(list) do
		local r = Row(i)
		r.entry, r.index = e, i
		r:ClearAllPoints()
		r:SetPoint("TOPLEFT", f, "TOPLEFT", Win.PAD - 8, y)
		r:SetPoint("TOPRIGHT", f, "TOPRIGHT", -Win.PAD + 8, y)
		r.name:SetText(e.layout.name)
		r.who:SetText(Who(e.layout))
		local picked = ask and Win.status.picked == i
		local mine = not ask and a and a.class == e.layout.class and a.name == e.layout.name
		r.plate:SetShown(picked and true or false)
		local c = (picked or mine) and Skin.C.text or Skin.C.body
		r.name:SetTextColor(c[1], c[2], c[3])
		if mine then r.name:SetTextColor(Win.ACCENT[1], Win.ACCENT[2], Win.ACCENT[3]) end
		r.apply:SetShown(not ask)
		r:Show()
		y = y - Win.ROW
	end
	for i = #list + 1, #rows do rows[i]:Hide(); rows[i].entry = nil end
	y = y - 10
	-- the foot
	f.paste:SetShown(not ask)
	f.load:SetShown(not ask)
	f.export:SetShown(not ask)
	f.out:SetShown(not ask and Win.status.exported ~= nil)
	f.msg:SetShown(not ask)
	f.yes:SetShown(ask)
	f.notNow:SetShown(ask)
	f.never:SetShown(ask)
	if ask then
		f.never:ClearAllPoints()
		f.never:SetPoint("TOPRIGHT", f, "TOPRIGHT", -Win.PAD, y)
		f.notNow:ClearAllPoints()
		f.notNow:SetPoint("RIGHT", f.never, "LEFT", -6, 0)
		f.yes:ClearAllPoints()
		f.yes:SetPoint("RIGHT", f.notNow, "LEFT", -6, 0)
		y = y - 32
	else
		f.load:ClearAllPoints()
		f.load:SetPoint("TOPRIGHT", f, "TOPRIGHT", -Win.PAD, y)
		f.paste:ClearAllPoints()
		f.paste:SetPoint("TOPLEFT", f, "TOPLEFT", Win.PAD, y)
		f.paste:SetPoint("RIGHT", f.load, "LEFT", -6, 0)
		y = y - 30
		-- Export under Load, its string's box beside it once made
		f.export:ClearAllPoints()
		f.export:SetPoint("TOPRIGHT", f, "TOPRIGHT", -Win.PAD, y)
		f.out:ClearAllPoints()
		f.out:SetPoint("TOPLEFT", f, "TOPLEFT", Win.PAD, y)
		f.out:SetPoint("RIGHT", f.export, "LEFT", -6, 0)
		y = y - 24
		f.msg:ClearAllPoints()
		f.msg:SetPoint("TOPLEFT", f, "TOPLEFT", Win.PAD, y - 6)
		f.msg:SetText(Win.status.message or "")
		if Win.status.message then y = y - 20 end
	end
	f:SetHeight(-y + Win.PAD)
end

-- (0.1.8) /presets tidy: the twins, Remove, its confirm
function Win.RefreshTidy()
	local y = -(Win.PAD + 22)
	for _, part in ipairs({ f.name, f.who, f.when, f.state, f.rule, f.again, f.trainHit, f.paste, f.load, f.export, f.out, f.msg,
		f.yes, f.notNow, f.never }) do part:Hide() end
	local list = ns.Presets.TidyList()
	Win.status.tidy = #list
	if #list == 0 then Win.status.confirm = nil end
	for i, m in ipairs(list) do
		local r = Row(i)
		r.entry, r.index = nil, i
		r:ClearAllPoints()
		r:SetPoint("TOPLEFT", f, "TOPLEFT", Win.PAD - 8, y)
		r:SetPoint("TOPRIGHT", f, "TOPRIGHT", -Win.PAD + 8, y)
		local named = string.find(m.name, "%S") ~= nil
		r.name:SetText(named and m.name or (m.spellWord or m.name))
		r.name:SetTextColor(Skin.C.body[1], Skin.C.body[2], Skin.C.body[3])
		r.who:SetText(named and (m.spellWord or "") or "")
		r.plate:Hide()
		r.apply:Hide()
		r:Show()
		y = y - Win.ROW
	end
	for i = #list + 1, #rows do rows[i]:Hide(); rows[i].entry = nil end
	if #list == 0 then
		f.none:ClearAllPoints()
		f.none:SetPoint("TOPLEFT", f, "TOPLEFT", Win.PAD, y - 4)
		f.none:SetText(NAMES.none)
		f.none:Show()
		y = y - 28
	else
		y = y - 10
		if Win.status.confirm then
			f.noTidy:ClearAllPoints()
			f.noTidy:SetPoint("TOPRIGHT", f, "TOPRIGHT", -Win.PAD, y)
			f.yesTidy:ClearAllPoints()
			f.yesTidy:SetPoint("RIGHT", f.noTidy, "LEFT", -6, 0)
			f.ask:ClearAllPoints()
			f.ask:SetPoint("LEFT", f, "TOPLEFT", Win.PAD, y - 16)
			f.ask:SetText(string.format(NAMES.removeAsk, #list))
			f.ask:Show()
			f.yesTidy:Show()
			f.noTidy:Show()
		else
			f.remove:ClearAllPoints()
			f.remove:SetPoint("TOPRIGHT", f, "TOPRIGHT", -Win.PAD, y)
			f.remove:Show()
		end
		y = y - 32
	end
	f:SetHeight(-y + Win.PAD)
end

function Win.TidyYes()
	Win.status.confirm = nil
	ns.Presets.Tidy()
	Win.Refresh()
end

-- ------------------------------------------------------------
-- What the buttons do
-- ------------------------------------------------------------
function Win.ApplyPicked()
	local e = ns.Presets.Matches()[Win.status.picked or 1]
	if not e then return end
	if f then f:Hide() end
	ns.Presets.Apply(e.layout)
end

function Win.LoadPasted()
	local text = f and f.paste.edit:GetText() or ""
	local s, why = ns.Presets.Load(text)
	if s or why == "waiting" then
		Win.status.message = nil
		f.paste.edit:SetText("")
		f.paste.edit:ClearFocus()
	else
		Win.status.message = why
	end
	Win.Refresh()
end

-- (0.1.2) the row's tooltip: the spells to buy now, one line each, plain
function Win.ShowTrain(owner)
	local list = ns.Presets.TrainList()
	if #list == 0 then return end
	GameTooltip:SetOwner(owner, "ANCHOR_BOTTOMRIGHT")
	GameTooltip:ClearLines()
	for _, buy in ipairs(list) do GameTooltip:AddLine(ns.Presets.TrainWords(buy), 1, 1, 1) end
	GameTooltip:Show()
end

-- (0.1.2) Export: the bars now as a string, in the box, selected for Ctrl+C.
function Win.Export()
	Build()
	local str, why = ns.Presets.Export()
	Win.status.exported = str
	Win.status.message = not str and why or nil
	Win.Refresh()
	if not str then return end
	f.out.edit:SetText(str)
	f.out.edit:SetCursorPosition(0)
	f.out.edit:SetFocus()
	f.out.edit:HighlightText()
end

function Win.Open(mode)
	Build()
	Win.status.mode = mode or "main"
	Win.status.picked = nil
	Win.status.message = nil
	Win.status.exported = nil
	Win.status.confirm = nil
	if f.out.edit:GetText() ~= "" then f.out.edit:SetText("") end
	Win.status.opens = Win.status.opens + 1
	f:Show()
	f:Raise()
	Win.Refresh()
end

function Win.Hide()
	if f then f:Hide() end
end

function Win.IsShown()
	return f ~= nil and f:IsShown()
end

function Win.Toggle()
	if Win.IsShown() then Win.Hide() else Win.Open("main") end
end
