-- HUI kit (kit/ at the repo root; its change log is kit/KIT.md). Every addon's Kit\ holds a byte-identical copy made
-- by _tools/sync_kit.py: change kit/ and run the sync, never a copy in place.
local ADDON, ns = ...

-- ============================================================
-- Dragging a window without the client's StartMoving.
--
-- WHY. StartMoving keeps the cursor-to-frame offset it had when the drag began.
-- Once the frame has been held at the screen edge by SetClampedToScreen while
-- the cursor kept going, the cursor has to travel all the way back before the
-- frame follows again: the window feels magnetised to the edge. Here the frame
-- is placed by this file every frame of the drag, clamped by this file, and
-- whenever the clamp changed the result the grab offset is RE-BASED on that
-- axis, so the frame comes away from the edge the moment the cursor turns back.
--
-- Generic: needs nothing from the host addon. If ns.Safe / ns.ForgetClientPlacement
-- exist they are used. Meant to move into the shared library unchanged.
--
--   ns.Drag.Attach(frame, opts)     once per window. opts (all optional):
--       point    = "TOPLEFT" (default) | "TOP" | "TOPRIGHT" | "LEFT" | "CENTER" | "RIGHT" |
--                  "BOTTOMLEFT" | "BOTTOM" | "BOTTOMRIGHT" (KIT.md 26: the nine points; the
--                  four corners until then; a word that is none of them: TOPLEFT)
--                  the point the window is anchored by; positions are that point's
--                  offset from the same point of UIParent, in UIParent units
--                  (so they survive a change of the window's own scale). The frame keeps
--                  it (frame.dragState.point): Drag never re-chooses it on its own - only
--                  when the caller asks (Drag.SetPoint, or a point handed to Drag.Place)
--       canStart = function(frame) return true end      veto (locked, combat ...)
--       onStart  = function(frame) end
--       onStop   = function(frame, x, y) end            save x, y here
--     Attach turns the client's own clamping OFF for the frame (this file clamps),
--     makes the frame itself a drag handle (dead space drags the window) and sets
--     frame.dragging = false. It hooks the frame's OnHide (a hidden window lets go of
--     a drag), so call it AFTER the frame's own SetScript("OnHide", ...).
--   ns.Drag.Handle(handle, frame)   another mouse-enabled frame (a header) that drags `frame`
--   ns.Drag.Place(frame, x, y, point)  anchors the frame at a saved position, clamped to the
--                                   screen; does nothing while that frame is being dragged.
--                                   point (optional, KIT.md 26): a saved { point, x, y }'s own
--                                   point, which the frame takes first (a word that is no point:
--                                   the frame keeps its own)
--   ns.Drag.SetPoint(frame, point)  (KIT.md 26) the anchor re-chosen, the frame left where it is:
--                                   one of the nine, or "nearest" (the one whose third of the
--                                   screen, across and up, the frame's middle is in). Returns its
--                                   offsets by the new point; nil, the point unchanged, for a word
--                                   that is no point or during a drag (and nil for a frame with
--                                   no place yet: a named point is taken all the same)
--   ns.Drag.POINTS                  the nine, in reading order
--   ns.Drag.Start(frame[, snap]) / ns.Drag.Stop(frame)  for callers with their own handlers (snap, KIT.md 36: this
--                                   drag snaps to the suite's grid)
--   frame.dragging                  true between Start and Stop: never re-anchor it then
--
-- (KIT.md 36) THE UNLOCK'S PLATES: the snap grid and right-click to settings (UI/BUILD-unlock-mode.md; Harry, Oct 7).
--   ns.Drag.Plate(plate, frame, page[, onPage])   a purple plate of the unlock over `frame` (the Attach'd frame it
--                                   moves; the plate itself when it is that frame): left-drag moves the frame, SNAPPING
--                                   to the suite's grid while HUI Menus' unlock shows it; right-click opens `page`
--                                   (Drag.SetPage). Call it after the plate's own SetScript("OnMouseUp", ...), if any.
--   ns.Drag.SetPage(plate, page[, onPage])   the settings page a right-click on the plate opens: page = { addon,
--                                   category, tab } (tab optional) or a function(plate) returning the three (read at
--                                   the click: a raid tier names its own). onPage(plate) runs first (optional: a bar
--                                   chosen). For a plate with a drag of its own (HUI Bars' movers).
--   ns.Drag.PageOf(plate)           addon, category, tab: what a right-click opens (nil: none declared)
--   ns.Drag.OpenPage(plate)         opens it - the hub (ForeverSuiteOptions.Open(addon, category, tab); the unlock
--                                   stays on), else the addon's own window (ns.OpenOptions(category, tab)). true if asked
--   ns.Drag.SnapGrid()              the grid's step in UIParent units while snapping is on (HUI Menus' unlock showing
--                                   its grid with Snap ticked: ForeverSuiteOptions.SnapGrid()), else nil
--   ns.Drag.Snapped(left, bottom, w, h)   a box (UIParent units, its bottom left corner) moved onto the grid: on each
--                                   axis the nearest of its two edges and its middle to a grid line (the lines run
--                                   from the screen's middle, every step), the screen's thirds or middle, within
--                                   SNAP_REACH units, takes it there. Unchanged with no grid or with Shift held
--   ns.Drag.Ticks(left, bottom, w, h)     the snap's marks for a box where it is now: for each axis with an edge or the
--                                   middle on a line, two short ticks of light on that line just outside the box (no
--                                   glow, no line along it). Ticks() with no box hides them. A drag of the kit's own
--                                   does both; a drag of its own (HUI Bars) calls them
--   ns.Drag.Ticks(left, bottom, w, h, atX, atY)   (KIT.md 37) the same marks on the lines given (either may be nil),
--                                   not the grid's, with or without a grid (HUI Bars: a bar clamped to another)
--
-- (KIT.md 40) THE BEAMS AND A FIRMER SNAP (UI/BUILD-unlock-guides.md; Harry, Oct 11).
--   Every plate (Drag.Plate, Drag.SetPage) is listed in the suite's shared table (ForeverSuiteOptions.plates, a set),
--   so a plate of any addon sees every other. While a plate is dragged with the grid's snap on, each OTHER plate shown
--   is a candidate (not the one held - the one whose OnDragStart ran, the frame being dragged, a plate or frame marked
--   .dragging, one inside the frame being moved): the dragged box's left, right, bottom and top line up with its same
--   or opposite edge, its middle with its middle. Drag.Snapped pulls onto those lines, and onto the screen's centre
--   lines, the grid's major lines (every 4th, as the Stage draws them), the thirds and the screen's edges, from
--   FIRM_REACH units - the nearest of those wins; else the ordinary lines from SNAP_REACH as before. Drag.Ticks also draws a BEAM for each
--   line the box sits on with another plate: one pixel, the suite's purple, across both plates; gone with Ticks().
--   Drag.SnapGrid() returns the step and the major lines' spacing in steps (ForeverSuiteOptions.SnapGrid()'s second
--   answer, 4 when it gives none).
--
-- The OnUpdate exists only between Start and Stop, and allocates nothing.
-- Nothing here may be used on a protected frame in combat (canStart is the place to say no).
-- ============================================================

local Drag = {}
ns.Drag = Drag

local function Safe(fn, ...)
	if not fn then return end
	if ns.Safe then return ns.Safe(fn, ...) end
	return pcall(fn, ...)
end

local driver = CreateFrame("Frame")
driver:Hide()

-- State of the one drag in progress. Plain upvalues: nothing is allocated per frame.
local active          -- the frame being dragged
local snapping        -- (KIT.md 36) this drag snaps to the suite's grid (a plate's)
local grabX, grabY    -- cursor minus the frame's bottom left corner, UIParent units
local width, height   -- the frame's size, UIParent units
local lastLeft, lastBottom
local EndSession              -- (KIT.md 40) below: the other plates read for this drag, let go

local function Ratio(frame)
	local own, base = frame:GetEffectiveScale(), UIParent:GetEffectiveScale()
	if own and base and base > 0 then return own / base end
	return 1
end

-- The cursor in UIParent units. GetCursorPosition is in screen pixels.
local function Cursor()
	local x, y = GetCursorPosition()
	local scale = UIParent:GetEffectiveScale()
	if not x or not scale or scale <= 0 then return nil end
	return x / scale, y / scale
end

-- (KIT.md 26) The nine points, and where each sits on a box: a fraction of its width from its left (x), of its height
-- from its bottom (y).
Drag.POINTS = { "TOPLEFT", "TOP", "TOPRIGHT", "LEFT", "CENTER", "RIGHT", "BOTTOMLEFT", "BOTTOM", "BOTTOMRIGHT" }
local POINT_X = { TOPLEFT = 0, LEFT = 0, BOTTOMLEFT = 0, TOP = 0.5, CENTER = 0.5, BOTTOM = 0.5, TOPRIGHT = 1, RIGHT = 1,
	BOTTOMRIGHT = 1 }
local POINT_Y = { BOTTOMLEFT = 0, BOTTOM = 0, BOTTOMRIGHT = 0, LEFT = 0.5, CENTER = 0.5, RIGHT = 0.5, TOPLEFT = 1, TOP = 1,
	TOPRIGHT = 1 }

-- The point a frame is anchored by: its dragState's, or TOPLEFT for anything there that is not one of the nine.
local function PointOf(st)
	local point = st.point
	if POINT_X[point] then return point end
	return "TOPLEFT"
end

-- Along one axis, in UIParent units: a point's offset from the same point of UIParent, from the box's near edge (its
-- left or its bottom), its size and UIParent's; f is where the point sits (0 the near edge, 0.5 the middle, 1 the far
-- edge). A corner's sums are written as they always were, so its numbers are the old ones to the last bit.
local function Offset(near, size, parent, f)
	if f == 0 then return near end
	if f == 1 then return near + size - parent end
	return near + (size - parent) / 2
end

-- And back: the box's near edge for a point's offset.
local function NearEdge(offset, size, parent, f)
	if f == 0 then return offset end
	if f == 1 then return offset + parent - size end
	return offset + (parent - size) / 2
end

-- Anchors the frame so that its bottom left corner is at (left, bottom) in UIParent units.
local function Anchor(frame, left, bottom)
	local st = frame.dragState
	local ratio = Ratio(frame)
	local parentWidth, parentHeight = UIParent:GetWidth(), UIParent:GetHeight()
	local point = PointOf(st)
	local x = Offset(left, st.w, parentWidth, POINT_X[point])
	local y = Offset(bottom, st.h, parentHeight, POINT_Y[point])
	st.x, st.y = x, y
	frame:ClearAllPoints()
	frame:SetPoint(point, UIParent, point, x / ratio, y / ratio)
end

-- Keeps a rectangle of w x h on the screen. Returns left, bottom, clampedX, clampedY.
local function Clamp(left, bottom, w, h)
	local parentWidth, parentHeight = UIParent:GetWidth(), UIParent:GetHeight()
	local cx, cy = false, false
	local maxLeft, maxBottom = parentWidth - w, parentHeight - h
	if maxLeft < 0 then maxLeft = 0 end
	if maxBottom < 0 then maxBottom = 0 end
	if left < 0 then left, cx = 0, true elseif left > maxLeft then left, cx = maxLeft, true end
	if bottom < 0 then bottom, cy = 0, true elseif bottom > maxBottom then bottom, cy = maxBottom, true end
	return left, bottom, cx, cy
end

local function Update()
	local frame = active
	if not frame then
		driver:SetScript("OnUpdate", nil)
		driver:Hide()
		return
	end
	-- The button was released somewhere that did not tell us (another window, a loading screen).
	if IsMouseButtonDown and not IsMouseButtonDown("LeftButton") then
		Drag.Stop(frame)
		return
	end
	local cx, cy = Cursor()
	if not cx then return end
	local left, bottom = cx - grabX, cy - grabY
	if snapping then left, bottom = Drag.Snapped(left, bottom, width, height) end
	local clampedX, clampedY
	left, bottom, clampedX, clampedY = Clamp(left, bottom, width, height)
	-- Held at an edge: forget how far past it the cursor went, so the way back has no dead zone.
	if clampedX then grabX = cx - left end
	if clampedY then grabY = cy - bottom end
	if left ~= lastLeft or bottom ~= lastBottom then
		lastLeft, lastBottom = left, bottom
		Anchor(frame, left, bottom)
		if snapping then Drag.Ticks(left, bottom, width, height) end
	end
end

local function OnUpdate()
	Safe(Update)
end

function Drag.Start(frame, snap)
	local st = frame.dragState
	if not st or active then return end
	if st.canStart and not st.canStart(frame) then return end
	local cx, cy = Cursor()
	local left, bottom = frame:GetLeft(), frame:GetBottom()
	if not cx or not left or not bottom then return end

	local ratio = Ratio(frame)
	st.w, st.h = frame:GetWidth() * ratio, frame:GetHeight() * ratio
	width, height = st.w, st.h
	left, bottom = left * ratio, bottom * ratio
	grabX, grabY = cx - left, cy - bottom
	lastLeft, lastBottom = left, bottom

	EndSession()
	active = frame
	snapping = snap and true or false
	frame.dragging = true
	-- a plate picked up where it already sits on a line shows its ticks at once (not only once it moves)
	if snapping then Drag.Ticks(left, bottom, width, height) end
	if st.onStart then Safe(st.onStart, frame) end
	driver:SetScript("OnUpdate", OnUpdate)
	driver:Show()
end

function Drag.Stop(frame)
	if active ~= frame then return end
	if snapping then Drag.Ticks() end
	EndSession()
	active = nil
	snapping = false
	driver:SetScript("OnUpdate", nil)
	driver:Hide()
	frame.dragging = false
	if ns.ForgetClientPlacement then ns.ForgetClientPlacement(frame) end
	local st = frame.dragState
	-- The position comes from what was last set, not from GetLeft: a frame anchored
	-- this very frame may not have a resolved rectangle yet.
	if st.onStop and st.x then Safe(st.onStop, frame, st.x, st.y) end
end

function Drag.IsDragging(frame)
	return active ~= nil and (frame == nil or active == frame)
end

-- x, y: the saved offsets of the frame's anchor point (see Attach); point (KIT.md 26, optional): the point they were
-- saved by, which the frame takes first. Clamped to the screen, so a position saved at a larger resolution cannot put
-- the window out of reach.
function Drag.Place(frame, x, y, point)
	local st = frame.dragState
	if not st or frame.dragging then return end
	if POINT_X[point] then st.point = point end
	local ratio = Ratio(frame)
	st.w, st.h = frame:GetWidth() * ratio, frame:GetHeight() * ratio
	local parentWidth, parentHeight = UIParent:GetWidth(), UIParent:GetHeight()
	point = PointOf(st)
	local left = NearEdge(x, st.w, parentWidth, POINT_X[point])
	local bottom = NearEdge(y, st.h, parentHeight, POINT_Y[point])
	left, bottom = Clamp(left, bottom, st.w, st.h)
	Anchor(frame, left, bottom)
end

-- (KIT.md 26) The anchor re-chosen - only ever when a caller asks: the frame stays where it is, anchored by `point` now
-- (one of the nine, or "nearest": the one whose third of the screen, across and up, the frame's middle is in). Where it
-- is comes from its last place (what this file last set, as Drag.Stop has it), else from the client. Returns its offsets
-- by the new point; nil (the point unchanged) for a word that is no point or during a drag; nil for a frame with no
-- place yet (a named point taken all the same).
function Drag.SetPoint(frame, point)
	local st = frame and frame.dragState
	if not st or frame.dragging then return nil end
	if point ~= "nearest" and not POINT_X[point] then return nil end
	local ratio = Ratio(frame)
	local w, h = frame:GetWidth() * ratio, frame:GetHeight() * ratio
	local parentWidth, parentHeight = UIParent:GetWidth(), UIParent:GetHeight()
	local left, bottom
	if st.x and st.y then
		local was = PointOf(st)
		left = NearEdge(st.x, w, parentWidth, POINT_X[was])
		bottom = NearEdge(st.y, h, parentHeight, POINT_Y[was])
	else
		left, bottom = frame:GetLeft(), frame:GetBottom()
		if left and bottom then left, bottom = left * ratio, bottom * ratio end
	end
	if point == "nearest" then
		if not left or not bottom or parentWidth <= 0 or parentHeight <= 0 then return nil end
		local cx, cy = (left + w / 2) / parentWidth, (bottom + h / 2) / parentHeight
		local across = (cx < 1 / 3 and "LEFT") or (cx > 2 / 3 and "RIGHT") or ""
		local up = (cy < 1 / 3 and "BOTTOM") or (cy > 2 / 3 and "TOP") or ""
		point = up .. across
		if point == "" then point = "CENTER" end
	end
	st.point = point
	if not left or not bottom then return nil end
	st.w, st.h = w, h
	Anchor(frame, left, bottom)
	return st.x, st.y
end

local function HandleDragStart(self)
	Safe(Drag.Start, self.dragTarget, self.dragSnap)
end

local function HandleDragStop(self)
	Safe(Drag.Stop, self.dragTarget)
end

function Drag.Handle(handle, frame)
	handle.dragTarget = frame
	handle:EnableMouse(true)
	handle:RegisterForDrag("LeftButton")
	handle:SetScript("OnDragStart", HandleDragStart)
	handle:SetScript("OnDragStop", HandleDragStop)
end

function Drag.Attach(frame, opts)
	opts = opts or {}
	frame.dragState = {
		point = POINT_X[opts.point] and opts.point or "TOPLEFT",
		canStart = opts.canStart, onStart = opts.onStart, onStop = opts.onStop,
		w = 0, h = 0, x = nil, y = nil,
	}
	frame.dragging = false
	-- This file clamps. The client's clamp is what causes the friction, and the two must not both act.
	frame:SetClampedToScreen(false)
	if ns.ForgetClientPlacement then ns.ForgetClientPlacement(frame) end
	Drag.Handle(frame, frame)
	-- A window that is hidden in the middle of a drag (Escape) must let go.
	frame:HookScript("OnHide", function(self) Safe(Drag.Stop, self) end)
end

-- ============================================================
-- (KIT.md 36) THE UNLOCK'S PLATES: the snap grid, its ticks, right-click to the settings page.
-- The grid is HUI Menus': its unlock (the Stage) draws it and says, through ForeverSuiteOptions.SnapGrid(), the step
-- while it shows it with Snap ticked. Every kit copy snaps by the same rule, so a plate of any addon lands on the lines
-- Menus draws. Without the hub, or with its grid down, nothing snaps (no lines to see).
-- ============================================================
local SNAP_REACH = 5          -- UIParent units: an edge or the middle this near a line goes onto it
local FIRM_REACH = 10         -- (KIT.md 40) and this near a firm line: the centre lines, the major lines, the thirds,
                              -- another plate's edge or middle (Harry, Oct 11: "a bit of a firmer snap. not much")
local MAJOR = 4               -- (KIT.md 40) every MAJOR-th line from the middle is a major one, when the hub says none
local TICK = 18               -- a tick's length, units, from the box's edge outward
local TICK_ALPHA = 0.5        -- at the box; fading to nothing at its far end
local TICK_COLOUR = { 241 / 255, 236 / 255, 246 / 255 }   -- pearl
local ON_LINE = 0.51          -- a box's edge this near a line is on it (for a caller that rounds to whole units)
local BEAM_COLOUR = { 190 / 255, 120 / 255, 255 / 255 }  -- (KIT.md 40) the suite's purple, lit
local BEAM_ALPHA = 0.95
local MAX_BEAMS = 12
Drag.SNAP_REACH, Drag.TICK, Drag.TICK_ALPHA = SNAP_REACH, TICK, TICK_ALPHA
Drag.FIRM_REACH, Drag.MAJOR, Drag.BEAM_COLOUR, Drag.BEAM_ALPHA = FIRM_REACH, MAJOR, BEAM_COLOUR, BEAM_ALPHA

-- The step, and (KIT.md 40) the major lines' spacing in steps.
function Drag.SnapGrid()
	local suite = _G.ForeverSuiteOptions
	local fn = type(suite) == "table" and suite.SnapGrid
	if type(fn) ~= "function" then return nil end
	local ok, step, major = pcall(fn)
	if ok and type(step) == "number" and step >= 2 then
		if type(major) ~= "number" or major < 1 or major ~= math.floor(major) then major = MAJOR end
		return step, major
	end
	return nil
end

-- The lines of one axis near a place: the nearest grid line (the grid runs from the screen's middle, every step) and
-- the nearer of the two thirds. Returns the nearest of them and the distance to it.
local function NearestLine(f, screen, step)
	local mid = screen / 2
	local line = mid + math.floor((f - mid) / step + 0.5) * step
	local d = line - f
	for t = 1, 2 do
		local third = screen * t / 3
		if math.abs(third - f) < math.abs(d) then line, d = third, third - f end
	end
	return line, d
end

-- (KIT.md 40) The nearest FIRM line of the grid to a place: a major line (the middle one is the centre), a third, or
-- the screen's own edge (a plate held against the edge stays there, as it did, and is not pulled off it onto a major
-- line). Returns the distance to it.
local function NearestFirm(f, screen, step, major)
	local mid, every = screen / 2, step * major
	local d = mid + math.floor((f - mid) / every + 0.5) * every - f
	for t = 0, 3 do
		local line = screen * t / 3 - f
		if math.abs(line) < math.abs(d) then d = line end
	end
	return d
end

local function Nearer(d, best)
	if not best or math.abs(d) < math.abs(best) then return d end
	return best
end

-- ------------------------------------------------------------
-- (KIT.md 40) The other plates: every plate of every addon is in the suite's shared set; a drag reads the ones shown
-- once, at its first snap or mark (a SESSION), and lets them go with the marks (Ticks() with no box).
-- ------------------------------------------------------------
local pressed                 -- the plate whose OnDragStart ran last (this kit's): never its own candidate
local session = false
local cN = 0                  -- the candidates: their boxes in UIParent units, left / bottom / right / top
local cL, cB, cR, cT = {}, {}, {}, {}
Drag.candidates = { L = cL, B = cB, R = cR, T = cT }

local function Plain(v)
	if issecretvalue and issecretvalue(v) then return nil end
	if type(v) ~= "number" then return nil end
	return v
end

-- Does this plate move with the drag (or is it the one held)?
local function Moving(c, held)
	if c == active or c == pressed or c.dragging then return true end
	local t = c.dragTarget
	if t and (t == active or t.dragging or (held and t == held)) then return true end
	local p = c.GetParent and c:GetParent()
	for _ = 1, 8 do
		if not p or p == UIParent then break end
		if p == active or p == pressed or (held and p == held) or p.dragging then return true end
		p = p.GetParent and p:GetParent()
	end
	return false
end

local function Begin()
	session, cN = true, 0
	local suite = _G.ForeverSuiteOptions
	local set = type(suite) == "table" and type(suite.plates) == "table" and suite.plates
	if not set then return end
	local held = pressed and pressed.dragTarget
	for c in pairs(set) do
		local ok, l, b, w, h = pcall(function()
			if type(c) ~= "table" or not c.IsVisible or not c:IsVisible() or Moving(c, held) then return nil end
			return Plain(c:GetLeft()), Plain(c:GetBottom()), Plain(c:GetWidth()), Plain(c:GetHeight())
		end)
		if ok and l and b and w and h and w > 0 and h > 0 then
			local k = Ratio(c)
			cN = cN + 1
			cL[cN], cB[cN], cR[cN], cT[cN] = l * k, b * k, (l + w) * k, (b + h) * k
		end
	end
end

EndSession = function()
	session, cN, pressed = false, 0, nil
end

local function Candidates()
	if not session then Begin() end
	return cN
end
Drag.Candidates = Candidates

-- One axis: the box's near edge, its size, the screen's size along it; lo / hi: the candidates' near and far edges on
-- it. A firm line (KIT.md 40) within FIRM_REACH of its near edge, its middle or its far edge takes it there, the
-- nearest; else the nearest line of the grid within SNAP_REACH (in that order on a tie). Returns the near edge.
local function SnapAxis(near, size, screen, step, major, lo, hi)
	local anyD, firmD
	for i = 0, 2 do
		local f = near + size * i / 2
		local _, d = NearestLine(f, screen, step)
		anyD = Nearer(d, anyD)
		firmD = Nearer(NearestFirm(f, screen, step, major), firmD)
	end
	local far, mid = near + size, near + size / 2
	for k = 1, cN do
		local a, z = lo[k], hi[k]
		firmD = Nearer(a - near, firmD)
		firmD = Nearer(z - near, firmD)
		firmD = Nearer(a - far, firmD)
		firmD = Nearer(z - far, firmD)
		firmD = Nearer((a + z) / 2 - mid, firmD)
	end
	if firmD and math.abs(firmD) <= FIRM_REACH then return near + firmD end
	if anyD and math.abs(anyD) <= SNAP_REACH then return near + anyD end
	return near
end

function Drag.Snapped(left, bottom, w, h)
	local step, major = Drag.SnapGrid()
	if not step or not left or not bottom then return left, bottom end
	if IsShiftKeyDown and IsShiftKeyDown() then return left, bottom end
	Candidates()
	left = SnapAxis(left, w, UIParent:GetWidth(), step, major, cL, cR)
	bottom = SnapAxis(bottom, h, UIParent:GetHeight(), step, major, cB, cT)
	return left, bottom
end

-- The line an edge or the middle of a box lies on now (nil: none), for the ticks.
local function OnLineAxis(near, size, screen, step)
	for i = 0, 2 do
		local line, d = NearestLine(near + size * i / 2, screen, step)
		if math.abs(d) <= ON_LINE then return line end
	end
	return nil
end

-- One screen pixel in UIParent units (SharedXML\PixelUtil.lua's rule: the screen is 768 units high at scale 1), and a
-- place in units put on the nearest pixel.
local function PixelUnit()
	local ph
	if GetPhysicalScreenSize then
		local _, h = GetPhysicalScreenSize()
		ph = h
	end
	local scale = UIParent:GetEffectiveScale()
	if ph and ph > 0 and scale and scale > 0 then return 768 / ph / scale end
	return 1
end
Drag.PixelUnit = PixelUnit

local function OnPixel(v, px)
	return math.floor(v / px + 0.5) * px
end

local ticks                   -- the four ticks' frame (made at the first snap)

-- A tick: one pixel across, TICK long, lit at the box and nothing at its far end (a gradient where the client has
-- one; flat and fainter where it has not). outward: "up" | "down" | "left" | "right", the way it runs from the box.
local function Tick(f, outward)
	local t = f:CreateTexture(nil, "OVERLAY")
	t:SetColorTexture(1, 1, 1, 1)
	local c = TICK_COLOUR
	local ok = false
	if CreateColor and t.SetGradient then
		local lit, none = CreateColor(c[1], c[2], c[3], TICK_ALPHA), CreateColor(c[1], c[2], c[3], 0)
		-- the first colour is the bottom's (VERTICAL) or the left's (HORIZONTAL)
		local vertical = outward == "up" or outward == "down"
		local litFirst = outward == "up" or outward == "right"
		ok = pcall(t.SetGradient, t, vertical and "VERTICAL" or "HORIZONTAL", litFirst and lit or none,
			litFirst and none or lit)
	end
	if not ok then t:SetVertexColor(c[1], c[2], c[3], TICK_ALPHA * 0.6) end
	t.gradient = ok
	t:Hide()
	return t
end

local function Ticks()
	if ticks then return ticks end
	local f = CreateFrame("Frame", nil, UIParent)
	f:SetFrameStrata("FULLSCREEN")
	f:SetAllPoints(UIParent)
	f.up, f.down, f.left, f.right = Tick(f, "up"), Tick(f, "down"), Tick(f, "left"), Tick(f, "right")
	f.beams, f.beamCount = {}, 0                 -- (KIT.md 40) made as they are first needed
	ticks = f
	Drag.ticks = f
	return f
end

local function PlaceTick(t, x, y, w, h)
	t:ClearAllPoints()
	t:SetPoint("BOTTOMLEFT", UIParent, "BOTTOMLEFT", x, y)
	t:SetSize(w, h)
	t:Show()
end

-- (KIT.md 40) The beams: one pixel, the suite's purple, on a line the dragged box shares with other plates, from the
-- far side of the one to the far side of the other (one beam per line, as long as every plate on it needs).
local nBeams = 0
local bAxis, bAt, bFrom, bTo = {}, {}, {}, {}

local function Beam(f, i)
	local list = f.beams
	local t = list[i]
	if not t then
		t = f:CreateTexture(nil, "OVERLAY", nil, 1)
		t:SetColorTexture(1, 1, 1, 1)
		t:SetVertexColor(BEAM_COLOUR[1], BEAM_COLOUR[2], BEAM_COLOUR[3], BEAM_ALPHA)
		t:Hide()
		list[i] = t
	end
	return t
end

local function AddBeam(axis, at, from, to)
	for i = 1, nBeams do
		if bAxis[i] == axis and math.abs(bAt[i] - at) <= ON_LINE then
			if from < bFrom[i] then bFrom[i] = from end
			if to > bTo[i] then bTo[i] = to end
			return
		end
	end
	if nBeams >= MAX_BEAMS then return end
	nBeams = nBeams + 1
	bAxis[nBeams], bAt[nBeams], bFrom[nBeams], bTo[nBeams] = axis, at, from, to
end

-- One axis of one candidate: the box's near and far edges against its own, its middle against its middle. Each line
-- shared is a beam across the other axis's span of the two (oLo..oHi the box's, cLo..cHi the candidate's).
local function AlignAxis(axis, near, far, a, z, oLo, oHi, cLo, cHi)
	local from, to = math.min(oLo, cLo), math.max(oHi, cHi)
	if math.abs(near - a) <= ON_LINE or math.abs(far - a) <= ON_LINE then AddBeam(axis, a, from, to) end
	if math.abs(near - z) <= ON_LINE or math.abs(far - z) <= ON_LINE then AddBeam(axis, z, from, to) end
	if math.abs((near + far) / 2 - (a + z) / 2) <= ON_LINE then AddBeam(axis, (a + z) / 2, from, to) end
end

local function HideBeams(f)
	for i = 1, #f.beams do f.beams[i]:Hide() end
	f.beamCount = 0
end

local function Beams(f, left, bottom, w, h, px)
	nBeams = 0
	local right, top = left + w, bottom + h
	for k = 1, Candidates() do
		AlignAxis("x", left, right, cL[k], cR[k], bottom, top, cB[k], cT[k])
		AlignAxis("y", bottom, top, cB[k], cT[k], left, right, cL[k], cR[k])
	end
	for i = 1, nBeams do
		local t = Beam(f, i)
		local at, from, to = OnPixel(bAt[i], px), bFrom[i], bTo[i]
		if bAxis[i] == "x" then PlaceTick(t, at, from, px, to - from) else PlaceTick(t, from, at, to - from, px) end
		t.axis, t.at, t.from, t.to = bAxis[i], bAt[i], from, to
	end
	for i = nBeams + 1, #f.beams do f.beams[i]:Hide() end
	f.beamCount = nBeams
end

-- Returns the lines the ticks mark (x, y; nil for an axis with none).
-- (KIT.md 37) atX, atY: the lines to mark instead of the grid's (either may be nil), grid or none - HUI Bars' bar
-- clamped to another bar, the edge they line up on.
-- (KIT.md 40) And with the grid's snap on, the beams to every other plate the box lines up with. Ticks() with no box:
-- all of it hidden, the other plates let go (the drag is over).
function Drag.Ticks(left, bottom, w, h, atX, atY)
	local given = atX ~= nil or atY ~= nil
	local grid, major = nil, nil
	if left and bottom and w and h then grid, major = Drag.SnapGrid() end
	local step = left and bottom and w and h and (given or grid)
	if not step then
		if ticks then
			ticks.up:Hide(); ticks.down:Hide(); ticks.left:Hide(); ticks.right:Hide()
			ticks.lineX, ticks.lineY = nil, nil
			HideBeams(ticks)
		end
		if not left then EndSession() end
		return nil, nil
	end
	local f = Ticks()
	local px = PixelUnit()
	local lx, ly
	if given then
		lx, ly = atX, atY
	else
		lx = OnLineAxis(left, w, UIParent:GetWidth(), step)
		ly = OnLineAxis(bottom, h, UIParent:GetHeight(), step)
	end
	f.lineX, f.lineY = lx, ly
	if lx then
		local x = OnPixel(lx, px)
		PlaceTick(f.up, x, bottom + h, px, TICK)
		PlaceTick(f.down, x, bottom - TICK, px, TICK)
	else
		f.up:Hide(); f.down:Hide()
	end
	if ly then
		local y = OnPixel(ly, px)
		PlaceTick(f.right, left + w, y, TICK, px)
		PlaceTick(f.left, left - TICK, y, TICK, px)
	else
		f.left:Hide(); f.right:Hide()
	end
	if grid then Beams(f, left, bottom, w, h, px) else HideBeams(f) end
	return lx, ly
end

-- ------------------------------------------------------------
-- Right-click: the plate's own settings page.
-- ------------------------------------------------------------
function Drag.PageOf(plate)
	local page = plate and plate.settingsPage
	if type(page) == "function" then
		local ok, addon, category, tab = pcall(page, plate)
		if ok then return addon, category, tab end
		return nil
	end
	if type(page) == "table" then return page[1], page[2], page[3] end
	return nil
end

function Drag.OpenPage(plate)
	local addon, category, tab = Drag.PageOf(plate)
	if type(addon) ~= "string" then return false end
	if plate.settingsOnPage then Safe(plate.settingsOnPage, plate) end
	local suite = _G.ForeverSuiteOptions
	if type(suite) == "table" and suite.host and type(suite.Open) == "function" then
		Safe(suite.Open, addon, category, tab)
		return true
	end
	if ns.OpenOptions then
		Safe(ns.OpenOptions, category, tab)
		return true
	end
	return false
end

local function PlateMouseUp(self, button)
	if button == "RightButton" then Safe(Drag.OpenPage, self) end
end

-- (KIT.md 40) The plate whose drag starts is never its own candidate (hooked after its own OnDragStart script).
local function PlateDragStart(self)
	pressed = self
end

-- (KIT.md 40) Every plate in the suite's shared set, so the other addons' drags see it.
local function Register(plate)
	local suite = _G.ForeverSuiteOptions
	if type(suite) ~= "table" then return end
	if type(suite.plates) ~= "table" then suite.plates = {} end
	suite.plates[plate] = true
end
Drag.Register = Register

function Drag.SetPage(plate, page, onPage)
	plate.settingsPage = page
	plate.settingsOnPage = onPage
	if not plate.settingsHooked then
		plate.settingsHooked = true
		plate:EnableMouse(true)
		plate:HookScript("OnMouseUp", PlateMouseUp)
		plate:HookScript("OnDragStart", PlateDragStart)
	end
	Register(plate)
end

function Drag.Plate(plate, frame, page, onPage)
	Drag.Handle(plate, frame or plate)
	plate.dragSnap = true
	if page then Drag.SetPage(plate, page, onPage) else Register(plate) end
end
