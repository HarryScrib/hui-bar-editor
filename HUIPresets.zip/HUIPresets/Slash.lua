local ADDON, ns = ...

-- ============================================================
-- /presets (and /hpresets): the window opened or closed. "/presets debug" prints where things stand, for a bug report.
-- (0.1.8) "/presets tidy": the window lists the duplicate macros to remove (Window.lua TIDY).
-- ============================================================

for i, cmd in ipairs(ns.NAMES.slash) do _G["SLASH_" .. ns.NAMES.slashKey .. i] = cmd end

function ns.Debug()
	local P = ns.Presets
	local a = P.Applied()
	local store = ns.db and ns.db.store or {}
	local out = { version = ns.VERSION, presets = #P.All(), mine = #P.Matches(), applied = a and a.name or nil,
		state = P.State(), never = ns.db and ns.db.never or nil, waiting = 0, lists = 0, errors = #ns.errors }
	for _ in pairs(store.layoutWaiting or {}) do out.waiting = out.waiting + 1 end
	for _ in pairs(store.layoutMounts or {}) do out.lists = out.lists + 1 end
	for k, v in pairs(P.status) do out[k] = v end
	return out
end

SlashCmdList[ns.NAMES.slashKey] = function(msg)
	ns.Safe(function()
		msg = string.lower((string.gsub(msg or "", "^%s*(.-)%s*$", "%1")))
		if msg == "debug" then
			local d = ns.Debug()
			local keys = {}
			for k in pairs(d) do keys[#keys + 1] = k end
			table.sort(keys)
			for _, k in ipairs(keys) do ns.Print(k .. " = " .. tostring(d[k])) end
			return
		end
		if msg == "tidy" then
			ns.Window.Open("tidy")
			return
		end
		ns.Window.Toggle()
	end)
end
